<x-app-layout title="home">
    <x-success class="mt-4" />


    <div>
        @if (config('settings::home_page_text'))
            <div class="content">
                <div class="content-box">
                    <div class="prose dark:prose-invert min-w-full">
                        @markdownify(config('settings::home_page_text'))
                    </div>
                </div>
            </div>
            <div class="s-separator"></div>
        @endif

        @if (config('settings::theme:sions-section-categories'))
            @if ($categories->count() > 0)
                <div class="content">
                    <h2 class="font-semibold text-4xl mb-8 text-primary-400 text-center">
                        {{ config('settings::theme:sions-section-categories-title') }}
                    </h2>
                    <div class="sions-welcome-div">
                        @foreach ($categories as $category)
                            @if($category->image)
                                <style>
                                    {{ ".sions-catimage_" . $category->id }}
                                        {
                                        background-color: var(--secondary-100);
                                        background: url("/storage/categories/{{ $category->image }}") no-repeat center center;
                                        background-size: cover;
                                        border-radius: 12px;
                                        overflow: hidden;
                                    }
                                </style>
                            @endif
                            @if (($category->products()->where('hidden', false)->count() > 0 && !$category->category_id) || $category->children()->count() > 0)
                                <div class="sions-welcome-content">
                                    <div class="{{ "sions-catimage_" . $category->id }} h-full flex flex-col">
                                        <div class="sions-welcome-flex">
                                            <div class="gap-x-3 items-center mb-2">
                                                <div class="sions-welcome-headline">
                                                    <h3 class="font-semibold text-lg">{{ $category->name }}</h3>
                                                </div>
                                            </div>

                                            <div class="sions-welcome-description prose dark:prose-invert">
                                                @markdownify($category->description)
                                            </div>

                                            <div class="pt-3 mt-auto">
                                                <a href="{{ route('products', $category->slug) ?? "w" }}"
                                                    class="button button-secondary w-full">{{ __('Browse Category') }}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
                <div class="s-separator"></div>
            @endif
        @endif

        @if (config('settings::theme:sions-section-features'))
            <div class="content sions-welcome-features">
                <h2 class="font-semibold text-4xl mb-8 text-primary-400 text-center">
                    {{ config('settings::theme:sions-section-features-title') }}
                </h2>
                <div class="sions-features-grid">
                    <div class="sions-feature-box big-feature"
                        style="--color:{{ config('settings::theme:sions-features-1-color') }};">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-1-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-1-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-1-text') }}</p>
                    </div>
                    <div class="sions-feature-box" style="--color:{{ config('settings::theme:sions-features-2-color') }};">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-2-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-2-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-2-text') }}</p>
                    </div>
                    <div class="sions-feature-box" style="--color:{{ config('settings::theme:sions-features-3-color') }};">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-3-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-3-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-3-text') }}</p>
                    </div>
                    <div class="sions-feature-box" style="--color:{{ config('settings::theme:sions-features-4-color') }};">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-4-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-4-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-4-text') }}</p>
                    </div>
                    <div class="sions-feature-box" style="--color:{{ config('settings::theme:sions-features-5-color') }};">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-5-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-5-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-5-text') }}</p>
                    </div>
                    <div class="sions-feature-box big-feature"
                        style="--color:{{ config('settings::theme:sions-features-6-color') }}">
                        <div class="icon-box">
                            <i class="{{ config('settings::theme:sions-features-6-icon') }}"></i>
                        </div>
                        <h3>{{ config('settings::theme:sions-features-6-headline') }}</h3>
                        <p>{{ config('settings::theme:sions-features-6-text') }}</p>
                    </div>
                </div>
            </div>
            <div class="s-separator"></div>
        @endif

        @if (config('settings::theme:sions-section-media'))
                @php
                    $settings = \App\Models\Setting::all()->keyBy('key');
                @endphp
                @if (isset($settings))
                    <div class="sions-mediacard sions-section-media bg-primary-100 p-6 sm:p-8 rounded-lg shadow-md">
                        <h2 class="font-semibold text-3xl sm:text-4xl mb-4 sm:mb-8 text-primary-400 text-center">
                            {{ config('settings::theme:sions-section-media-title') }}
                        </h2>
                        <p class="text-base sm:text-lg text-gray-700 text-center mb-4 sm:mb-6">
                            {{ config('settings::theme:sions-section-media-text') }}
                        </p>
                        <div>
                            <ul class="flex flex-wrap justify-center space-x-4 sm:space-x-6">
                                @foreach ($settings as $setting)
                                        @if (str_contains($setting->key, "social") && $setting->value)
                                                @php
                                                    $value = last(explode('-', $setting->key))
                                                @endphp
                                                <li>
                                                    <a class="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-secondary-100 rounded-full transition-transform transform hover:scale-110 hover:bg-secondary-200 duration-300"
                                                        href="{{ $setting->value }}" target="_blank" rel="noopener noreferrer">
                                                        <i class="ri-{{ $value }}-line text-primary-800 text-lg sm:text-xl"></i>
                                                    </a>
                                                </li>
                                        @endif
                                @endforeach
                            </ul>
                        </div>
                    </div>
                @endif
                <div class="s-separator"></div>
        @endif


        @if (config('settings::theme:sions-section-uptime') || config('settings::theme:sions-section-hardware'))
            <div class="content flex flex-col md:flex-row justify-center">
                @if (config('settings::theme:sions-section-uptime'))
                        @php
                            $uptimeHours = (int) config('settings::theme:sions-uptime-runtime');
                            $serverStatus = config('settings::theme:sions-uptime-status');
                            $uptimeDays = floor($uptimeHours / 24);
                            $uptimeRemainingHours = $uptimeHours % 24;

                            $statusClasses = [
                                'online' => [
                                    'ping' => 'bg-green-400'
                                ],
                                'offline' => [
                                    'ping' => 'bg-red-400'
                                ],
                                'maintenance' => [
                                    'ping' => 'bg-orange-400'
                                ]
                            ];

                            $currentStatus = $statusClasses[$serverStatus] ?? "none";
                        @endphp


                        <div class="sions-uptimecard p-6 flex-none">
                            <h2 class="font-semibold text-4xl mb-2 text-primary-400 text-center">
                                {{ config('settings::theme:sions-section-uptime-title') }}
                            </h2>
                            <p class="text-md text-center mb-4">
                                {{ config('settings::theme:sions-uptime-text') }}
                            </p>
                            @if ($currentStatus !== "none")
                                <div class="flex items-center mb-4">
                                    <span class="relative flex h-10 w-10">
                                        <span
                                            class="animate-ping absolute inline-flex h-full w-full rounded-full {{ $currentStatus['ping'] }} opacity-75"></span>
                                        <span class="relative inline-flex rounded-full h-10 w-10 {{ $currentStatus['ping'] }}"></span>
                                    </span>
                                    <span class="ml-2 text-lg font-semibold">{{ ucfirst($serverStatus) }}</span>
                                </div>
                            @endif
                            @if ($uptimeHours)
                                <div class="text-center mt-4">
                                    <div class="font-bold text-3xl text-primary-800">
                                        {{ $uptimeDays }}d {{ $uptimeRemainingHours }}h
                                    </div>
                                </div>
                            @endif
                        </div>
                @endif


                @if (config('settings::theme:sions-section-hardware'))
                        @php
                            $hardwareSpecs = [
                                'ri-cpu-line' => config('settings::theme:sions-hardware-cpu'),
                                'ri-computer-line' => config('settings::theme:sions-hardware-ram'),
                                'ri-hard-drive-2-line' => config('settings::theme:sions-hardware-storage'),
                                'ri-wifi-line' => config('settings::theme:sions-hardware-network')
                            ];
                        @endphp

                        <div class="sions-hardwarecard p-6 flex-none">
                            <h2 class="font-semibold text-4xl mb-2 text-primary-400 text-center">
                                {{ config('settings::theme:sions-section-hardware-title') }}
                            </h2>
                            <p class="text-md text-center mb-4">
                                {{ config('settings::theme:sions-hardware-text') }}
                            </p>
                            <div class="flex justify-center gap-5">
                                @foreach ($hardwareSpecs as $icon => $spec)
                                    @if($spec)
                                        <div class="flex flex-col items-center">
                                            <i class="{{ $icon }} text-primary-400 text-3xl mb-1"></i>
                                            <span class="text-sm">{{ $spec }}</span>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                @endif
            </div>
            <div class="s-separator"></div>
        @endif

        @if (config('settings::theme:sions-section-announcements'))
            @if ($announcements->count() > 0)
                <div class="content">
                    <h2 class="font-semibold text-4xl mb-8 text-primary-400 text-center">
                        {{ config('settings::theme:sions-section-announcements-title') }}
                    </h2>
                    <div class="sions-welcome-announcements-swiper-container">
                        <div class="swiper-wrapper">
                            @foreach ($announcements->sortByDesc('created_at') as $announcement)
                                <div class="swiper-slide sions-welcome-announcements-swiper-slide">
                                    <div class="sions-welcome-announcements-content-box">
                                        <h3 class="font-semibold text-lg">{{ $announcement->title }}</h3>
                                        <div class="prose dark:prose-invert">
                                            @markdownify(strlen($announcement->announcement) > 100 ? substr($announcement->announcement, 0, 100) . '...' : $announcement->announcement)
                                        </div>
                                        <div class="flex justify-between items-center mt-3">
                                            <span class="text-sm text-secondary-600">{{ __('Published') }}
                                                {{ $announcement->created_at->diffForHumans() }}</span>
                                            <a href="{{ route('announcements.view', $announcement->id) }}"
                                                class="button button-secondary">{{ __('Read More') }}</a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="s-separator"></div>
            @endif
        @endif

        @if (config('settings::theme:sions-section-image'))
            <div class="sions-section-image"></div>
            <div class="s-separator"></div>
        @endif

        @if (config('settings::theme:sions-section-pay'))
                @php
                    $paymentMethods = \App\Models\Extension::where('type', 'gateway')
                        ->where('enabled', true)
                        ->get();
                @endphp

                <div class="content flex flex-col md:flex-row items-center justify-evenly">
                    <h2 class="font-semibold text-4xl text-primary-400 mb-4 md:mr-10 text-center md:text-left">
                        {{ config('settings::theme:sions-section-pay-title') }}
                    </h2>
                    <div class="flex flex-wrap items-center justify-center gap-10">
                        @foreach ($paymentMethods as $method)
                            <div class="content-box p-6 border border-gray-300 rounded-md shadow-md flex flex-col items-center">
                                <h3 class="text-xl font-bold text-center">{{ $method->display_name }}</h3>
                                <p class="text-center">{{ $method->description }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="s-separator"></div>
        @endif
    </div>
</x-app-layout>