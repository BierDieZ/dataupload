<x-app-layout title="{{ $announcement->title }}"
    description='{{ strip_tags(Str::markdown(nl2br(Stevebauman\Purify\Facades\Purify::clean($announcement->announcement)))) }}'>

    @php
        $otherAnnouncements = \App\Models\Announcement::where('id', '!=', $announcement->id)
            ->orderBy('created_at', 'desc')
            ->take(7)
            ->get();
    @endphp





    <div class="content">
        <div class="mt-8 mb-8 flex flex-wrap gap-4 mb-10">
            <a href="{{ route('announcements.index') }}"
                class="bg-secondary-500 text-white rounded-md px-4 py-2 inline-block">
                {{ config('settings::theme:sions-announcements-back') }}
            </a>

            @foreach ($otherAnnouncements as $other)
                @if ($other->id !== $announcement->id)
                    <a href="{{ route('announcements.view', $other->id) }}"
                        class="bg-primary-400 text-white rounded-md px-4 py-2 text-center hover:underline">
                        {{ $other->title }}
                    </a>
                @endif
            @endforeach
        </div>


        <div class="content-box max-w-6xl mx-auto">
            <div class="flex justify-between">
                <h1 class="text-2xl font-bold">{{ $announcement->title }}</h1>
                <div class="flex items-center gap-x-5">
                    <p class="text-secondary-600 flex items-center gap-x-2">
                        <i class="ri-calendar-line"></i>
                        {{ $announcement->created_at->format('d/m/Y') }}
                    </p>
                    <p class="text-secondary-600 flex items-center gap-x-2">
                        <i class="ri-time-line ml-1"></i>
                        {{ $announcement->created_at->format('H:i') }}
                    </p>
                </div>
            </div>

            <div class="prose dark:prose-invert max-w-full mt-4">
                @markdownify($announcement->announcement)
            </div>
        </div>
    </div>

</x-app-layout>