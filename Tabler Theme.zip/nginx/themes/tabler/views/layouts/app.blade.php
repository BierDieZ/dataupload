<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge"/>
@empty($title)
<title>{{ config('app.name', 'Paymenter') }}</title>
@else
<title>{{ config('app.name', 'Paymenter') . ' - ' . ucfirst($title) }}</title>
@endempty
<!--  @vite('resources/js/app.js')-->
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<link href="/tabler/css/tabler.min.css?1692870487" rel="stylesheet"/>
<link href="/tabler/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
<link href="/tabler/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
<link href="/tabler/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
<link href="/tabler/css/demo.min.css?1692870487" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

<meta name="title" content="{{ config('app.name', 'Paymenter') . ' - ' . config('settings::seo_title') }}" />
<meta name="description" content="{{ $description ?? config('settings::seo_description') }}" />
<meta name="keywords" content="{{ config('settings::seo_keywords') }}" />
<meta name="theme-color" content="#5270FD">
<meta name="twitter:title" content="{{ config('app.name', 'Paymenter') . ' - ' . config('settings::seo_title') }}" />
@if (config('settings::seo_twitter_card') == 1)
<meta name="twitter:card" content="summary_large_image" />
@endif
<meta name="twitter:url" content="{{ url('/') }}" />
<meta name="twitter:description" content="{{ $description ?? config('settings::seo_description') }}" />

<meta name="og:title" content="{{ config('app.name', 'Paymenter') . ' - ' . config('settings::seo_title') }}" />
<meta name="og:description" content="{{ $description ?? config('settings::seo_description') }}" />
<meta name="og:locale" content="{{ str_replace('_', '-', app()->getLocale()) }}" />
<meta name="og:site_name" content="{{config('app.name', 'Paymenter')  }}" />
<meta name="og:url" content="{{ url('/') }}" />
<link type="application/json+oembed"href="{{ url('/') }}/manifest.json?title={{ config('app.name', 'Paymenter') }}&author_url={{ url('/') }}&author_name={{ config('app.name', 'Paymenter') }}" />
 

 
<style>
@import url('https://rsms.me/inter/inter.css');
:root {
--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
}
body {
font-feature-settings: "cv03", "cv04", "cv11";
}
</style>
</head>
<body >
<script src="/tabler/js/demo-theme.min.js?1692870487"></script>
<div class="page">
 
@if (config('settings::sidebar') == 1)
	@include('layouts.sidenavigation')
@else
	@include('layouts.navigation')
@endif
 
<div class="page-wrapper">
<div class="page-header ">
<div class="@if (config('settings::sidebar') == 1) container-fluid @else container-xl @endif">
 
{{ $slot }}
</div>
</div>
<x-footer />
</div>
</div>