@if(config('settings::theme:custom-notification-topbar-checkbox') == 1)
<x-notification-topbar />
@endif
<header class="navbar navbar-expand-md d-print-none" >
	<div class="container-xl">
	  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu" aria-controls="navbar-menu" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <h1 class="navbar-brand d-none-navbar-horizontal pe-0 pe-md-3">
		<a href="@auth {{ route('clients.home') }} @else {{ route('index') }} @endif" class="text-decoration-none">
			<x-application-logo  />
			@if(config('settings::theme:website-title-checkbox') == 1)
				{{ config('app.name', 'Paymenter') }}
			@endif
		</a>
	  </h1>
		<div class="navbar-nav flex-row order-md-last">
			@if(config('settings::theme:darkmode-checkbox') == 1)
			<a href="?theme=dark" class="nav-link px-0 hide-theme-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Enable dark mode" data-bs-original-title="Enable dark mode">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"></path></svg>
			</a>
			  <a href="?theme=light" class="nav-link px-0 hide-theme-light" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Enable light mode" data-bs-original-title="Enable light mode">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path><path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path></svg>
			</a>
			@endif
			@if (count(session()->get('cart', [])) > 0)
			<div class="nav-item d-none d-md-flex me-3"> 
				<a href="{{ route('checkout.index') }}" class="nav-link px-0">
						<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-cart" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
					   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
					   <path d="M6 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
					   <path d="M17 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
					   <path d="M17 17h-11v-14h-2"></path>
					   <path d="M6 5l14 1l-1 7h-13"></path>
					</svg>
					<h6><span class="badge bg-blue text-white">{{ count(session()->get('cart')) }}</span></h6>
				</a>
			</div>
			@endif		
			@auth
			<div class="nav-item dropdown">
				<a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu">
					<span class="avatar avatar-sm" style="background-image: url(https://www.gravatar.com/avatar/{{md5(Auth::user()->email)}}?s=200&d=mp"></span>
					<div class="d-xl-block ps-2 mt-1">
						<div> {{ Auth::user()->first_name . '   ' . Auth::user()->last_name}}</div>
						<div class="mt-1 small text-secondary"></div>
					</div>
				</a>
				<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
					<a href="{{ route('clients.profile') }}" class="dropdown-item">{{__('Profile')}}</a>
					@if (Auth::user()->has('ADMINISTRATOR'))
						<a href="{{ route('admin.index') }}" class="dropdown-item">{{ __('Admin area') }}</a>
						<a href="{{ route('clients.api.index') }}" class="dropdown-item">{{ __('Account API') }}</a>
					@endif
					<div class="dropdown-divider"></div>
					<a href="{{ route('logout') }}" class="dropdown-item" onclick="event.preventDefault();document.getElementById('logout-form').submit();"> 
						<svg xmlns="http://www.w3.org/2000/svg" class="icon dropdown-item-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" /><path d="M9 12h12l-3 -3" /><path d="M18 15l3 -3" /></svg>
                    {{ __('Log Out') }}</a>
					<form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">@csrf</form>
				</div>
			</div>
			@else
			<div class="nav-item">
				 
				<a href="{{ route('login') }}" class="btn">
					{{ __('Log In') }}
				</a>
			</div>
			@endauth
		</div>
	</div>
</header>
<header class="navbar-expand-md">
	<div class="collapse navbar-collapse" id="navbar-menu">
		<div class="navbar">
			<div class="container-xl">
			@auth
				<ul class="navbar-nav">
					<li class="nav-item @if (request()->routeIs('clients.home')) active @endif">
						<a class="nav-link" href="{{ route('clients.home') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>
							<span class="nav-link-title">{{ __('Dashboard') }}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('clients.invoice*')) active @endif">
						<a class="nav-link" href="{{ route('clients.invoice.index') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-description" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
								   <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path>
								   <path d="M9 17h6"></path>
								   <path d="M9 13h6"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Invoices') }}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('clients.tickets*')) active @endif">
						<a class="nav-link" href="{{ route('clients.tickets.index') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-messages" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10"></path>
								   <path d="M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Tickets') }}</span>
						</a>
					</li>
					@if(config('settings::theme:display-categories-dropdown-checkbox') == 0)
					@foreach (App\Models\Category::withCount('products')->get() as $category)
						@if ($category->products_count > 0)
					<li class="nav-item {{ route('products', $category->slug) == url()->current() ? 'active' : '' }}">
						<a class="nav-link" href="{{ route('products', $category->slug) }}" >
							<!--<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>!-->
							<span class="nav-link-title">{{ $category->name }}</span>
						</a>
					</li>
						@endif
					@endforeach
					@else
					<li class="nav-item @if (request()->routeIs('products')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-bag" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M6.331 8h11.339a2 2 0 0 1 1.977 2.304l-1.255 8.152a3 3 0 0 1 -2.966 2.544h-6.852a3 3 0 0 1 -2.965 -2.544l-1.255 -8.152a2 2 0 0 1 1.977 -2.304z"></path>
								   <path d="M9 11v-5a3 3 0 0 1 6 0v5"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Shop') }}</span>
						</a>
						
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
								@foreach (App\Models\Category::withCount('products')->get() as $category)
									@if ($category->products_count > 0)
										<a href="{{ route('products', $category->slug) }}" class="dropdown-item">{{ $category->name }}</a> <!-- Future <span class="badge badge-sm bg-green-lt text-uppercase ms-auto">New</span> !-->
									@endif
								 @endforeach
								</div>
							</div>
						</div>
					</li>
					@endif
				</ul>
				@else
				<ul class="navbar-nav">
					<li class="nav-item @if (request()->routeIs('index')) active @endif">
						<a class="nav-link" href="{{ route('index') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>
							<span class="nav-link-title">{{ __('Home') }}</span>
						</a>
					</li>
					 
					@if(config('settings::theme:display-categories-dropdown-checkbox') == 0)
					@foreach (App\Models\Category::withCount('products')->get() as $category)
						@if ($category->products_count > 0)
					<li class="nav-item {{ route('products', $category->slug) == url()->current() ? 'active' : '' }}">
						<a class="nav-link" href="{{ route('products', $category->slug) }}" >
							<!--<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>!-->
							<span class="nav-link-title">{{ $category->name }}</span>
						</a>
					</li>
						@endif
					@endforeach
					@else
					<li class="nav-item @if (request()->routeIs('products')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-bag" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M6.331 8h11.339a2 2 0 0 1 1.977 2.304l-1.255 8.152a3 3 0 0 1 -2.966 2.544h-6.852a3 3 0 0 1 -2.965 -2.544l-1.255 -8.152a2 2 0 0 1 1.977 -2.304z"></path>
								   <path d="M9 11v-5a3 3 0 0 1 6 0v5"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Shop') }}</span>
						</a>
						
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
								@foreach (App\Models\Category::withCount('products')->get() as $category)
									@if ($category->products_count > 0)
										<a href="{{ route('products', $category->slug) }}" class="dropdown-item">{{ $category->name }}</a> <!-- Future <span class="badge badge-sm bg-green-lt text-uppercase ms-auto">New</span> !-->
									@endif
								 @endforeach
								</div>
							</div>
						</div>
					</li>
					@endif
				</ul>
				@endauth
				<div class="my-2 my-md-0 flex-grow-1 flex-md-grow-0 order-first order-md-last">
				 
				</div>
			</div>
		</div>
	</div>
</header>