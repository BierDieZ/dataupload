<aside class="navbar navbar-vertical navbar-expand-lg d-print-none" @if(config('settings::theme:enable-dark-sidenavigation-checkbox') == 1) data-bs-theme="white" @else data-bs-theme="dark" @endif">
        <div class="container-fluid">
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu" aria-controls="sidebar-menu" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<h1 class="navbar-brand ">
				<a href="@auth {{ route('admin.index') }} @else {{ route('index') }} @endif" class="text-decoration-none">
					<x-application-logo  />
					@if(config('settings::theme:website-title-checkbox') == 1)
						{{ config('app.name', 'Paymenter') }}
					@endif
				</a>
			</h1>
 
			<div class="collapse navbar-collapse" id="sidebar-menu">
            @auth
				<ul class="navbar-nav">
					<li class="nav-item @if (request()->routeIs('admin.index')) active @endif">
						<a class="nav-link" href="{{ route('admin.index') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>
							<span class="nav-link-title">{{ __('Dashboard') }}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.clients*')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users-group" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
								   <path d="M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1"></path>
								   <path d="M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
								   <path d="M17 10h2a2 2 0 0 1 2 2v1"></path>
								   <path d="M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
								   <path d="M3 13v-1a2 2 0 0 1 2 -2h2"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Clients') }}</span>
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
									<a href="{{ route('admin.clients') }}" class="@if (request()->routeIs('admin.clients')) active @endif dropdown-item">{{ __('All Clients') }}</a>
									<a href="{{ route('admin.clients.create') }}" class="@if (request()->routeIs('admin.clients.create')) active @endif dropdown-item">{{__('Create Client')}}</a>
								
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.orders')) active @endif">
						<a class="nav-link" href="{{ route('admin.orders') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-article" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M3 4m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z"></path>
								   <path d="M7 8h10"></path>
								   <path d="M7 12h10"></path>
								   <path d="M7 16h10"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Orders') }}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.invoices*')) active @endif">
						<a class="nav-link" href="{{ route('admin.invoices') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-description" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
								   <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path>
								   <path d="M9 17h6"></path>
								   <path d="M9 13h6"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{__('Invoices')}}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.products*')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-cart-cog" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M4 19a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
								   <path d="M12 17h-6v-14h-2"></path>
								   <path d="M6 5l14 1l-.79 5.526m-3.21 1.474h-10"></path>
								   <path d="M19.001 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
								   <path d="M19.001 15.5v1.5"></path>
								   <path d="M19.001 21v1.5"></path>
								   <path d="M22.032 17.25l-1.299 .75"></path>
								   <path d="M17.27 20l-1.3 .75"></path>
								   <path d="M15.97 17.25l1.3 .75"></path>
								   <path d="M20.733 20l1.3 .75"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Products') }}</span>
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
									<a href="{{ route('admin.products') }}" class=" @if (request()->routeIs('admin.products')) active @endif dropdown-item">{{ __('All Products') }}</a>
									<a href="{{ route('admin.products.create') }}" class="@if (request()->routeIs('admin.products.create')) active @endif dropdown-item">{{ __('Add Product') }}</a>  
									<div class="dropdown-divider"></div>
									<a href="{{ route('admin.categories') }}" class="@if (request()->routeIs('admin.categories')) active @endif dropdown-item">{{ __('Categories') }}</a>
									<a href="{{ route('admin.configurable-options')}}" class="@if (request()->routeIs('admin.configurable-options*')) active @endif dropdown-item">{{ __('Configurable Options') }}</a>
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.tickets*')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-messages" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10"></path>
								   <path d="M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Support') }}</span>
							 
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
								@php $unread = App\Models\Ticket::where('status', 'open')->count(); @endphp
									<a href="{{ route('admin.tickets') }}" class="@if (request()->routeIs('admin.tickets')) active @endif dropdown-item">{{ __('All Tickets') }} 
									@if ($unread > 0)<span class="badge badge-sm bg-red text-white ms-auto">{{ $unread }}</span>@endif</a>
									<a href="{{ route('admin.tickets.create') }}" class="@if (request()->routeIs('admin.tickets.create')) active @endif dropdown-item">{{ __('Add Ticket') }}</a>
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.email*')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M3 7a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10z"></path>
								   <path d="M3 7l9 6l9 -6"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Emails') }}</span>
							 
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
									<a href="{{ route('admin.email') }}" class="@if (request()->routeIs('admin.email')) active @endif dropdown-item">{{ __('Email Logs') }}</a>
									<a href="{{ route('admin.email.templates') }}" class="@if (request()->routeIs('admin.email.templates')) active @endif dropdown-item">{{ __('Email Templates') }}</a>
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item @if (request()->routeIs('admin.settings')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-settings" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z"></path>
								   <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Settings') }}</span>
							 
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
									<a href="{{ route('admin.announcements')}}" class="@if (request()->routeIs('admin.announcements*')) active @endif dropdown-item">{{ __('Announcements') }}</a>
									<a href="{{ route('admin.coupons') }}" class="@if (request()->routeIs('admin.coupons*')) active @endif dropdown-item">{{ __('Coupons') }}</a>
									<a href="{{ route('admin.extensions') }}" class="@if (request()->routeIs('admin.extensions*')) active @endif dropdown-item" id="menu-item-1">{{ __('Extensions') }}</a>  
									<a href="{{ route('admin.roles') }}" class="@if (request()->routeIs('admin.roles*')) active @endif dropdown-item">{{ __('Roles') }}</a>
									<a href="{{ route('admin.settings') }}" class="@if (request()->routeIs('admin.settings*')) active @endif dropdown-item">{{ __('Settings') }}</a>                       
								</div>
							</div>
						</div>
					</li>
				</ul>
				@else
				<ul class="navbar-nav">
					<li class="nav-item @if (request()->routeIs('index')) active @endif">
						<a class="nav-link" href="{{ route('index') }}" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
							</span>
							<span class="nav-link-title">{{ __('Home') }}</span>
						</a>
					</li>
					<li class="nav-item @if (request()->routeIs('products')) active @endif dropdown">
						<a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" >
							<span class="nav-link-icon d-md-none d-lg-inline-block">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-bag" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M6.331 8h11.339a2 2 0 0 1 1.977 2.304l-1.255 8.152a3 3 0 0 1 -2.966 2.544h-6.852a3 3 0 0 1 -2.965 -2.544l-1.255 -8.152a2 2 0 0 1 1.977 -2.304z"></path>
								   <path d="M9 11v-5a3 3 0 0 1 6 0v5"></path>
								</svg>
							</span>
							<span class="nav-link-title">{{ __('Shop') }}</span>
						</a>
						<div class="dropdown-menu">
							<div class="dropdown-menu-columns">
								<div class="dropdown-menu-column">
								@foreach (App\Models\Category::withCount('products')->get() as $category)
									@if ($category->products_count > 0)
										<a href="{{ route('products', $category->slug) }}" class="dropdown-item">{{ $category->name }}</a> <!-- Future <span class="badge badge-sm bg-green-lt text-uppercase ms-auto">New</span> !-->
									@endif
								@endforeach
								</div>
							</div>
						</div>
					</li>
				</ul>
			@endauth
			</div>
        </div>
      </aside>
	  <header class="navbar navbar-expand-md d-none d-lg-flex d-print-none">
        <div class="@if (config('settings::sidebar') == 1) container-fluid @else container-xl @endif">
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu" aria-controls="navbar-menu" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="navbar-nav flex-row order-md-last">
            <div class="d-none d-md-flex">
				@if(config('settings::theme:darkmode-checkbox') == 1)
				<a href="?theme=dark" class="nav-link px-0 hide-theme-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Enable dark mode" data-bs-original-title="Enable dark mode">
					<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"></path></svg>
				</a>
				<a href="?theme=light" class="nav-link px-0 hide-theme-light" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Enable light mode" data-bs-original-title="Enable light mode">
					<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path><path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path></svg>
				</a>
				@endif
                @if (count(session()->get('cart', [])) > 0)
				<div class="nav-item d-none d-md-flex me-3" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Enable light mode" data-bs-original-title="Shoppingcart"> 
					<a href="{{ route('checkout.index') }}" class="nav-link px-0">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-cart" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
						   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
						   <path d="M6 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
						   <path d="M17 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
						   <path d="M17 17h-11v-14h-2"></path>
						   <path d="M6 5l14 1l-1 7h-13"></path>
						</svg>
						<h6><span class="badge bg-blue text-white">{{ count(session()->get('cart')) }}</span></h6>
					</a>
				</div>
				@endif
            </div>
           @auth
			<div class="nav-item dropdown">
				<a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu">
					<span class="avatar avatar-sm" style="background-image: url(https://www.gravatar.com/avatar/{{md5(Auth::user()->email)}}?s=200&d=mp"></span>
					<div class="d-xl-block ps-2 mt-1">
						<div> {{ Auth::user()->first_name . '   ' . Auth::user()->last_name}}</div>
						<div class="mt-1 small text-secondary"></div>
					</div>
				</a>
				<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
					<a href="{{ route('clients.profile') }}" class="dropdown-item">{{__('Profile')}}</a>
					@if (Auth::user()->has('ADMINISTRATOR'))
						<a href="{{ route('clients.home') }}" class="dropdown-item">{{ __('Client area') }}</a>
						<a href="{{ route('clients.api.index') }}" class="dropdown-item">{{ __('Account API') }}</a>
					@endif
					<div class="dropdown-divider"></div>
					<a href="{{ route('logout') }}" class="dropdown-item" onclick="event.preventDefault();document.getElementById('logout-form').submit();">{{ __('Log Out') }}</a>
					<form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">@csrf</form>
				</div>
			</div>
			@else
			<div class="nav-item">
				<a href="{{ route('login') }}" class="btn btn-outline-primary">{{ __('Log In') }}</a>
			</div>
			@endauth
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            
          </div>
        </div>
      </header>