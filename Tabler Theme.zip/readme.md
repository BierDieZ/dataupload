Thank you for purchasing Tabler Theme for Paymenter..

This theme will be updated always to the latest stable version of Paymenter Feel free to DM me for questions Discord: Wolf.Moreno

Be aware that the extension pages are not included yet in the theme.

Latest Theme Update 24-11-2023
Paymenter Version 0.8.2