<x-app-layout clients title="{{ __('Home') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Welcome back') }} 
		</div>
		<h2 class="page-title">
			{{ Auth::user()->name }}
		</h2>
	</div>
	<div class="col-xl-3 col-md-4 col-sm-12 mb-2">
	@if (count($invoices) > 1)
	@foreach ($invoices as $invoice)
		<div class="card card-sm mb-2">
			<div class="card-body">
				<div class="row align-items-center">
					<div class="col-auto">
						<span class="bg-primary text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/currency-dollar -->
						<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-description" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							   <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
							   <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path>
							   <path d="M9 17h6"></path>
							   <path d="M9 13h6"></path>
							</svg>
						</span>
					</div>
					<div class="col" >
						<div class="font-weight-medium">
						#{{ $invoice->id }}
						</div>
						<div class="text-secondary">
						{{__('Amount to pay')}} - <x-money :amount="$invoice->total()" />
						</div>
					</div>
					<div class="col-auto">
						<a href="{{ route('clients.invoice.show', $invoice->id) }}" class="btn">
						{{__('View')}}
						</a>
					</div>
					
				</div>
			</div>
		</div>
	@endforeach
	@else
		<div class="card card-sm mb-2">
			<div class="card-body">
				<div class="row align-items-center">
				<div class="col-auto">
						<span class="bg-primary text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/currency-dollar -->
						<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-description" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							   <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
							   <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path>
							   <path d="M9 17h6"></path>
							   <path d="M9 13h6"></path>
							</svg>
						</span>
					</div>
					<div class="col">
						<div class="text-success">
						 {{__('Hurray! No invoices to pay')}}
						</div>
					</div>
				</div>
			</div>
		</div>	
	@endif
	</div>
	<div class="col-xl-9 col-md-8 col-sm-12 mb-2">
		<div class="card">
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('Product/Service') }}</th>
							<th>{{ __('Cost') }}</th>
							<th>{{ __('Active until') }}</th>
							<th>{{ __('Status') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody>
					@php
						$i = 0
					@endphp
						@if (count($services) > 0)
							@foreach ($services as $service)
								@foreach ($service->products as $product2)
									@php
										$product = $product2->product;
										$i++
									@endphp
									@if($product2->status === 'cancelled')
										@continue
									@endif
						
						<tr>
							<td data-label="{{ __('Product/Service') }}">
								<div class="d-flex py-1 align-items-center">
									<!-- future <span class="avatar me-2" style="background-image: url({{ $product->image }})"></span>!-->
									<div class="flex-fill">
										<div class="font-weight-medium">{{ ucfirst($product->name) }}</div>
									</div>
								</div>
							</td>
							<td data-label="{{ __('Cost') }}">
								<div> <x-money :amount="$product2->price" /></div>
								<!-- future<div class="text-secondary"></div>!-->
							</td>
							<td class="text-secondary" data-label="{{ __('Active until') }}">
								  {{ $product2->expiry_date ? $product2->expiry_date->toDateString() : __('Doesn\'t Expire') }}
							</td>
							<td class="text-secondary" data-label="{{ __('Status') }}">
								<div class="font-bold rounded-md text-left">
									@if ($product2->status === 'paid')
									<span class="badge bg-green text-green-fg">{{__('Active')}}</span>
									@elseif($product2->status === 'pending')
									<span class="badge bg-orange text-orange-fg">{{ __('Pending') }}</span>
									@elseif($product2->status === 'cancelled')
									<span class="badge bg-red text-red-fg">{{ __('Expired') }}</span>
									@elseif($product2->status === 'suspended')
									<span class="badge bg-red text-red-fg">{{ __('Suspended') }}</span>
									@else
										<span class="badge bg-red text-red-fg">{{ $product2->status }}</span>
									@endif
								</div>
							</td>
							<td data-label="{{ __('Actions') }}">
							 <span class="relative flex ml-2">
								<a class="button @if($product2->status !== 'pending' || $product2->status !== 'suspended') cursor-pointer bg-secondary-200 hidden @else button-secondary @endif" @if($product2->status === 'pending' || $product2->status === 'suspended') href='{{ route('clients.invoice.index') }}'@endif><i class="ri-money-dollar-circle-line"></i></a>
								@if($product2->status === 'pending' || $product2->status === 'suspended')
									<span class="animate-ping -top-1 -right-1 absolute inline-flex h-3 w-3 rounded-full bg-red-400 opacity-75"></span>
									<span class="absolute inline-flex -top-1 -right-1 rounded-full h-3 w-3 bg-red-500"></span>
								@endif
							</span>
							 
							<a class="btn btn-outline-primary" @if($product2->status === 'cancelled' || $product2->status === 'suspended') style="opacity: 0.5; cursor: not-allowed;" @else href="{{ route('clients.active-products.show', $product2->id) }}" @endif>
							{{ __('View') }}
							</a>
							</td>
						</tr>
						@endforeach
						@endforeach
						@elseif (count($services) <= 0)
							<tr>

							</tr>
							<tr class="w-full">
								<td colspan="4" class="w-full dark:text-primary-400 font-bold text-lg text-center dark:bg-secondary-100">
									{{ __('No services found.') }}
								</td>
							</tr>
						@endif

					</tbody>
				</table>
			</div>
		</div>
	</div>
 
</div>
</x-app-layout>
