<x-app-layout title="{{ __('API') }}" clients>
<div class="page-body">
	<div class="container-xl">
	 <x-success />
		<div class="card">
			<div class="row g-0">
				<div class="col-12 col-md-3 border-end">
					<div class="card-body">
						<h4 class="subheader">{{ __('Profile Settings') }}</h4>
						<div class="list-group list-group-transparent">
							<a href="{{ route('clients.profile') }}" class="list-group-item list-group-item-action d-flex align-items-center">{{ __('Profile') }}</a>
							@if (config('settings::credits'))
                            <a href="{{ route('clients.credits') }}" class="list-group-item list-group-item-action d-flex align-items-center">
                                {{ __('Credits') }}
                            </a>
							@endif
							<a href="{{ route('clients.api.index') }}" class="list-group-item list-group-item-action d-flex align-items-center active">
								{{ __('Account API') }}
							</a>
							@if (config('settings::affiliate'))
								<a href="{{ route('clients.affiliate') }}" class="list-group-item list-group-item-action d-flex align-items-center">
									{{ __('Affiliate') }}
								</a>
							@endif
						</div>
					</div>
				</div>
				<div class="col-12 col-md-9 d-flex flex-column">
					<div class="row">
						<div class="col-sm-12">
							<form method="POST" action="{{ route('clients.api.create') }}">
							@csrf
								<div class="card-body">
								<h4 class="subheader">{{ __('Create Api Token') }}</h4>
									<div class="row">
										<div class="col-sm-12">
											<x-input type="text" placeholder="{{ __('Token') }}" name="name" id="name" label="{{ __('Token Name') }}" />
										</div>
										@foreach($permissions as $permission)
										<div class="col-md-4 col-sm-6">
											<x-input type="checkbox"  name="permissions[{{ $permission }}]" id="{{ $permission }}" label="{{ $permission }}"/>
										</div>
										@endforeach
									</div>
								</div> 
								<div class="card-footer text-end">
									 <button type="submit" class="btn btn-outline-green ms-auto">{{ __('Create') }}</button>
								</div>
							</form>
						</div>
						<div class="col-sm-12 px-2">
							<div class="hr-text">
								<span>{{ __('Manage Api Token') }}</span>
							</div>
					
							@if ($tokens->isEmpty())
                            <div class="row">
								<div class="col-sm-12 text-danger text-center mb-4">
									You have not tokens created yet!
								</div>
							</div>
							@endif

							@foreach($tokens as $token)
                            <form  method="POST" action="{{ route('clients.api.delete', $token->id) }}">
                                @csrf
                                @method('DELETE')
								<div class="card-body">
									<div class="row align-items-center">
										<div class="col">
											<h2 class="h3">{{ $token->name }} <small>@if ($token->last_used_at) {{ __('Last used') }} {{ $token->last_used_at->diffForHumans() }} @endif</small> </h2>
											<!--<p class="m-0 text-secondary">future option</p>!-->
										</div>
										<div class="col-auto">
											<button class="btn btn-outline-danger" type="submit">{{ __('Delete') }}</button>
										</div>
									</div>
								</div>
                            </form>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</x-app-layout>