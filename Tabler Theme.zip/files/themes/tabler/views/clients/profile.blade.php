<x-app-layout title="{{ __('Edit profile') }}" clients>
<div class="page-body">
	<div class="container-xl">
	<x-success />
		<div class="card">
			<div class="row g-0">
				<div class="col-12 col-md-3 border-end">
					<div class="card-body">
						<h4 class="subheader">{{ __('Profile Settings') }}</h4>
						<div class="list-group list-group-transparent">
							<a href="{{ route('clients.profile') }}" class="list-group-item list-group-item-action d-flex align-items-center active">{{ __('Profile') }}</a>
							@if (config('settings::credits'))
                            <a href="{{ route('clients.credits') }}" class="list-group-item list-group-item-action d-flex align-items-center">
                                {{ __('Credits') }}
                            </a>
							@endif
							<a href="{{ route('clients.api.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
								{{ __('Account API') }}
							</a>
							@if (config('settings::affiliate'))
								<a href="{{ route('clients.affiliate') }}" class="list-group-item list-group-item-action d-flex align-items-center">
									{{ __('Affiliate') }}
								</a>
							@endif
						</div>
					</div>
				</div>
				
				<div class="col-12 col-md-9 d-flex flex-column">
				 
					<div class="card">
						<div class="card-header">
							<ul class="nav nav-tabs card-header-tabs nav-fill" data-bs-toggle="tabs">
								<li class="nav-item">
									<a href="#tab-1" class="nav-link active" data-bs-toggle="tab">{{ __('My Details') }}</a>
								</li>
								<li class="nav-item">
									<a href="#tab-2" class="nav-link" data-bs-toggle="tab">{{ __('2FA') }}</a>
								</li>
								<li class="nav-item">
									<a href="#tab-3" class="nav-link" data-bs-toggle="tab">{{ __('Browser Sessions') }}</a>
								</li>
							</ul>
						</div>
						<div class="card-body">
							<div class="tab-content">
								<div class="tab-pane active show" id="tab-1">
									<div class="subheader">{{ __('My Details') }}</div>
									<div>
										<form method="POST" action="{{ route('clients.profile.update') }}">
										@csrf
											<div class="card-body">
												<div class="row">
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('First name') }}" name="first_name" id="first_name" label="{{ __('Name') }}" value="{{ Auth::user()->first_name }}" />
													</div>
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('Last name') }}" name="last_name" id="last_name" label="{{ __('Name') }}" value="{{ Auth::user()->last_name }}" />
													</div>
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('Address') }}" name="address" id="address" label="{{ __('Address') }}" value="{{ Auth::user()->address }}" />
													</div>
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('City') }}" name="city" id="city" label="{{ __('City') }}" value="{{ Auth::user()->city }}" />
													</div>
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('Country') }}" name="country" id="country" label="{{ __('Country') }}" value="{{ Auth::user()->country }}" />
													</div>
													<div class="col-md-6 col-sm-12">
														<x-input type="text" class="mt-4" placeholder="{{ __('Phone') }}" name="phone" id="phone" label="{{ __('Phone') }}" value="{{ Auth::user()->phone }}" />
													</div>
												</div>
											</div>											 
											<div class="btn-list justify-content-end">
												<button type="submit" class="btn btn-outline-green">
													{{ __('Update') }}
												</button>
											</div>
										</form>
									</div>
								</div>
								<div class="tab-pane" id="tab-2">
									<div class="subheader">{{ __('2FA') }}</div>
									<h4>{{ __('Two factor authentication adds an extra layer of security to your account. Once enabled, you will be prompted to enter a code from your authenticator app when logging in.') }}</h4>
									<div>
										@isset($secret)
										<button class="btn" data-bs-toggle="modal" data-bs-target="#modal-tfa-setup">{{ __('Setup Two Factor Authentication') }}</button>
											<div class="modal modal-blur fade" id="modal-tfa-setup" tabindex="-1" role="dialog" aria-hidden="true">
												<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
													<form method="POST" action="{{ route('clients.profile.tfa') }}">
													@csrf
													<input type="hidden" name="secret" value="{{ $secret }}">
														<div class="modal-content">
															<div class="modal-header">
																<h5 class="modal-title">{{ __('Two Factor Authentication') }}</h5>
																<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
															</div>
															<div class="modal-body text-center">
																<div class="mb-3">
																	<p>
																		 {{ __('Scan the QR code below with your authenticator app. If you do not have an authenticator app, you can use the code below to manually enter it.') }}
																	</p>
																	<img src="{{ $qr }}" alt="QR Code" />
																	<p>
																		{{ __('Or enter this code manually:') }}
																	</p>
																	<p>
																		{{ $secret }}
																	</p>
																</div>
															</div>
															<div class="modal-body">
																<div class="row">
																	<div class="mb-3 col-md-6">
																	  
																		<x-input id="code" label="{{ __('Code') }}" name="code" required type="text" />
																	</div>
																	<div class="mb-3 col-md-6">												
																		<x-input id="password" label="{{ __('Password') }}" name="password" required type="password" />
																	</div>
																</div>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn me-auto" data-bs-dismiss="modal">{{ __('Close') }}</button>
																<button type="submit" class="btn btn-primary ms-auto">{{ __('Submit') }}</button>
															</div>
														</div>
													</form>
												</div>
											</div>
										@else
											<button class="btn" data-bs-toggle="modal" data-bs-target="#modal-tfa">{{ __('Disable Two Factor Authentication') }}</button>
											<div class="modal modal-blur fade" id="modal-tfa" tabindex="-1" role="dialog" aria-hidden="true">
												<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
													<form method="POST" action="{{ route('clients.profile.tfa') }}">
													@csrf
													<input type="hidden" name="disable" value="true">
														<div class="modal-content">
															<div class="modal-header">
																<h5 class="modal-title">{{ __('Two Factor Authentication') }}</h5>
																<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
															</div>
															<div class="modal-body">
																<div class="mb-3">
																<p>
																	{{ __('Please enter your password to disable two factor authentication.') }}
																	{{ __('This will remove the two factor authentication from your account. Making your account more vulnerable.') }}
																</p>
																	<label class="form-label">{{ __('Password') }}</label>
																	<input type="password" class="form-control" name="password" required type="password">
																</div>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn me-auto" data-bs-dismiss="modal">{{ __('Close') }}</button>
																<button type="submit" class="btn btn-primary ms-auto">{{ __('Submit') }}</button>
															</div>
														</div>
													</form>
												</div>
											</div>
										@endisset
									</div>
								</div>
								<div class="tab-pane" id="tab-3">
									<div class="subheader">{{ __('Browser Sessions') }}</div>
									<h4>{{ __('Manage and logout your active sessions on other browsers and devices.') }}</h4>
									<div>
									@foreach (Auth::user()->sessions as $session)
										<div class="datagrid mb-4">
											 
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('Device') }}</div>
											@if($session->is_mobile)
												<div class="datagrid-content"><i class="ti ti-device-mobile"></i> {{ $session->formatted_device }}</div>
											@else
												<div class="datagrid-content"><i class="ti ti-device-desktop"></i> {{ $session->formatted_device }}</div> 
											@endif
											 
											 
											</div>
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('IP Address') }}</div>
												<div class="datagrid-content">{{ $session->ip_address }}</div>
											</div>
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('Session') }}</div>
											@if($session->is_current_device)
												<div class="datagrid-content">{{ __('This device.') }}</div>
											@else
												<div class="datagrid-content">{{ $session->formatted_last_active }}</div>
											@endif
											</div>
										</div>
										<hr>
										@endforeach
									 
										 
										<form action="{{ route('clients.profile.sessions') }}" method="POST">
											@csrf
											@method('DELETE')
											<button class="btn btn-outline-danger">
												{{ __('Logout Other Browser Sessions') }}
											</button>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</x-app-layout>