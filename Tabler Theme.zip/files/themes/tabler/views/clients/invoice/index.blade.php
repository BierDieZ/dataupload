<x-app-layout title="{{ __('Invoices') }}" clients>
    <x-success class="mt-4" />
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Invoices') }}</h3>
			</div>
			@if (count($invoices) > 0)
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('ID')}}</th>
							<th>{{ __('Total') }}</th>
							<th>{{ __('Created Date') }}</th>
							<th >{{ __('Status') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody>
					 @foreach ($invoices->sortByDesc('status') as $invoice)
                        @if ($invoice->items->count() == 0)
                            @continue
                        @endif
						<tr>
							<td>
								<div class="d-flex py-1 align-items-center">
									<div class="flex-fill">
										<div class="font-weight-medium">{{ $invoice->id }}</div>
									</div>
								</div>
							</td>
							<td>
								<div><x-money :amount="$invoice->total()" /></div>
							</td>
							<td class="text-secondary" >
								{{ $invoice->created_at }}
							</td>
							<td class="text-secondary">
								<div class="font-bold rounded-md text-left">
									@if (ucfirst($invoice->status) == 'Pending')
									<span class="badge bg-orange text-orange-fg">{{__('Pending')}}</span>
									 @elseif (ucfirst($invoice->status) == 'Paid')
									<span class="badge bg-green text-green-fg">{{ __('Paid') }}</span>
									 @elseif (ucfirst($invoice->status) == 'Cancelled')
									<span class="badge bg-red text-red-fg">{{ __('Cancelled') }}</span>
									 @else
										<span class="badge bg-red text-red-fg">{{ ucfirst($invoice->status) }}</span>
									@endif
								</div>
							</td>
							<td>
							 
							<a class="btn"  href="{{ route('clients.invoice.show', $invoice->id) }}">
							 {{ __('View') }}
							</a>
							</td>
						</tr>
					  @endforeach	                                                                    
					</tbody>
				</table>
			</div>
			@else 			   
			<div class="text-center p-4">
				{{ __('No Invoices Found.') }}
			</div>
			@endif
		</div>
	</div>
</x-app-layout>
