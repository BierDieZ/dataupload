<x-app-layout clients title="{{ __('Invoice') }}">   
		<div class="card d-print-none mb-4">
			<div class="card-body">	
				<div class="row g-2 align-items-center">
					<div class="col">
						<button type="button" class="btn btn-primary" onclick="javascript:window.print();">
						<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M17 17h2a2 2 0 0 0 2 -2v-4a2 2 0 0 0 -2 -2h-14a2 2 0 0 0 -2 2v4a2 2 0 0 0 2 2h2" /><path d="M17 9v-4a2 2 0 0 0 -2 -2h-6a2 2 0 0 0 -2 2v4" /><path d="M7 13m0 2a2 2 0 0 1 2 -2h6a2 2 0 0 1 2 2v4a2 2 0 0 1 -2 2h-6a2 2 0 0 1 -2 -2z" /></svg>
						{{ __('Invoice') }}
						</button>
					</div>
					<div class="col-auto ms-auto d-print-none">
						@if ($invoice->status == 'pending')                                    
						<form action="{{ route('clients.invoice.pay', $invoice->id) }}" method="post">
							@csrf
							 
							<select id="payment_method" name="payment_method" type="select" class="form-select" autocomplete="payment_method">
								@if (config('settings::credits'))
									<option value="credits">
										{{__('Pay with credits')}}
									</option>
								@endif
								@foreach (App\Models\Extension::where('type', 'gateway')->where('enabled', true)->get() as $gateway)
									<option class="dark:bg-darkmode dark:text-darkmodetext"
											value="{{ $gateway->id }}">
										{{ isset($gateway->display_name) ? $gateway->display_name : $gateway->name }}
									</option>
								@endforeach
							</select>
							<button type="submit" class="btn btn-outline-success mt-3 w-100">
								{{__('Pay')}}
							</button>
						</form>        
						@endif
					</div>
				</div>
			</div>
		</div>
 
		<div class="card card-lg ">
		<div class="card-title">
		 @if ($invoice->status == 'pending')
			<div class="ribbon ribbon-start bg-red">{{__('Invoice Not Paid')}}</div>
		@elseif($invoice->status == 'cancelled')
			<div class="ribbon ribbon-start bg-orange">{{__('Invoice Cancelled')}}</div>
		@else
			<div class="ribbon ribbon-start bg-green ">{{__('Invoice Paid')}} {{ $invoice->paid_at }}</div>		 
		@endif
		</div> 
			<div class="card-body mt-4">
				<div class="row">
					<div class="col-6">
						<p class="h3">{{ auth()->user()->first_name }} {{ auth()->user()->last_name }}</p>
						<address>
						{{ auth()->user()->address }}<br>
						{{ auth()->user()->zip }}, {{ auth()->user()->city }}<br>
						{{ auth()->user()->country }}
						</address>
					</div>
					<div class="col-6 text-end">
						<p class="h3">{{ config('settings::company_name')??config('app.name', 'Paymenter') }}</p>
						<address>
						{{ config('settings::company_address') }}<br>
						{{ config('settings::company_zip') }} {{ config('settings::company_city') }}<br>
						{{ config('settings::company_country') }}<br>
						{{ __('TIN') }}: {{ config('settings::company_tin') }}
						</address>
					</div>
					<div class="col-12 my-5 text-muted">
						{{ __('Invoice Number') }}: {{ $invoice->id }} <br>
						{{ __('Date of Issue') }}: {{ $invoice->created_at }}<br>
						@if ($invoice->status == 'pending')
							{{ __('Due Date') }}: {{ $invoice->due_at ?? "N/A" }} <br>
						@elseif($invoice->status == 'cancelled')
							{{__('Cancellation Date')}}: {{ $invoice->cancelled_at ?? "N/A" }}<br>
							 
						@endif
					</div>
				</div>
				<table class="table table-transparent table-responsive">
					<thead>
						<tr>
							<th class="text-center" style="width: 1%"></th>
							<th> {{ __('Description') }}</th>
							<th class="text-center" style="width: 1%">{{ __('Quantity') }}</th>
							<th class="text-end" style="width: 1%">{{ __('Rate') }}</th>
							<th class="text-end" style="width: 1%">{{ __('Amount') }}</th>
						</tr>
					</thead>
					@php $discount = 0.00; @endphp
					@foreach ($products as $product)
						@php
						if ($product->original_price > $product->price) {
							$discount += $product->original_price - $product->price;
						}
						@endphp
					<tr>
						<td></td>
						<td><div class="text-secondary">{{ $product->name ?? $product2->description }}</div></td>
						<td class="text-center">{{ $product->quantity ?? $product2->quantity }}</td>
						@if ($product->discount)
							<td class="text-end"><x-money :amount="number_format((float) $product->original_price, 2, '.', '')" /> </td>
							<td class="text-end"> <x-money :amount="number_format((float) $product->price, 2, '.', '')" /></td>
						@else
							<td class="text-end"><x-money :amount="number_format((float) $product->price / $product->quantity, 2, '.', '')" /></td>
							<td class="text-end"><x-money :amount="number_format((float) ($product->price * $product->quantity), 2, '.', '')" /></td>
						@endif
						  
						 
					</tr>
					 @endforeach
					 
					<tr>
						 
						<td colspan="4" class="strong text-end">{{__('Discount')}}</td>
						<td class="text-end"><x-money :amount="number_format((float) ($discount), 2, '.', '')" /> </td>
					</tr>
					<tr>
						 
						<td colspan="4" class="strong text-end">{{ __('Total') }}</td>
						<td class="text-end"><x-money :amount="number_format((float) $total, 2, '.', '')" /></td>
					</tr>
				</table>
				<p class="text-secondary text-center mt-5">{{ __('Thanks for choosing us. We hope you enjoy your purchase.') }}</p>
			</div>
		</div>
	</div>
</div>

</x-app-layout>
