<x-app-layout title="{{ __('Affiliate') }}" clients>
<div class="page-body">
	<div class="container-xl">
	 <x-success />
		<div class="card">
			<div class="row g-0">
				<div class="col-12 col-md-3 border-end">
					<div class="card-body">
						<h4 class="subheader">{{ __('Profile Settings') }}</h4>
						<div class="list-group list-group-transparent">
							<a href="{{ route('clients.profile') }}" class="list-group-item list-group-item-action d-flex align-items-center">{{ __('Profile') }}</a>
							@if (config('settings::credits'))
                            <a href="{{ route('clients.credits') }}" class="list-group-item list-group-item-action d-flex align-items-center">
                                {{ __('Credits') }}
                            </a>
							@endif
							<a href="{{ route('clients.api.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
								{{ __('Account API') }}
							</a>
							@if (config('settings::affiliate'))
								<a href="{{ route('clients.affiliate') }}" class="list-group-item list-group-item-action d-flex align-items-center active">
									{{ __('Affiliate') }}
								</a>
							@endif
						</div>
					</div>
				</div>
				<div class="col-12 col-md-9 d-flex flex-column">
					 <div class="row ">
						<div class="col-sm-12">
							<div class="card-body">
							@isset($affiliate)
								<div class="row align-items-center">
									<div class="col-sm-12">
										<div class="datagrid mb-4">
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('Visitors') }}</div>
												<div class="datagrid-content">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-eye" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
													   <path d="M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6"></path>
													</svg>
													{{ __('Total visitors') }} <b>{{ $affiliate->visitors }}</b>
												</div>
											</div>
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('Signups') }}</div>
												<div class="datagrid-content">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user-plus" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
													   <path d="M16 19h6"></path>
													   <path d="M19 16v6"></path>
													   <path d="M6 21v-2a4 4 0 0 1 4 -4h4"></path>
													</svg>
													{{ __('Total signups') }} <b>{{ $affiliate->affiliateUsers->count() }}</b>
												</div>
											</div>
											<div class="datagrid-item">
												<div class="datagrid-title">{{ __('Earnings') }}</div>
												<div class="datagrid-content">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-coin" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"></path>
													   <path d="M14.8 9a2 2 0 0 0 -1.8 -1h-2a2 2 0 1 0 0 4h2a2 2 0 1 1 0 4h-2a2 2 0 0 1 -1.8 -1"></path>
													   <path d="M12 7v10"></path>
													</svg>
													{{ __('Total earnings') }} <b> <x-money :amount="$affiliate->earnings()" /></b>
												</div>
											</div>
											 
										</div>
									</div>
									<div class="col-sm-12">
										<div class="row">
											 
												<div class="input-group mb-2">
													<input type="text" value="{{ url('/') }}?ref={{ $affiliate->code }}" name="ref" label="{{ __('Your affiliate link') }}" class="form-control"/>
													<button class="btn btn-outline-primary" id="copy" onclick="copyToClipboard('{{ url('/?ref=' . $affiliate->code) }}')">{{ __('Copy') }}</button>
												</div>
											 
										</div>
									</div>
								</div>
							 
								<script>
									function copyToClipboard(text) {
										var $temp = $("<input>");
										$("body").append($temp);
										$temp.val(text).select();
										document.execCommand("copy");
										$temp.remove();

										$('#copy').html('Loading...');
										setTimeout(function() {
											$('#copy').html('Copied');
										}, 1500);
									}
								</script>
							@else
								<div class="row align-items-center">
									<span class="subheader">{{ __('Affiliate') }}</span>
									<h4>{{ __('Signup for affiliate') }}</h4>
									<form action="{{ route('clients.affiliate.store') }}" method="POST">
										@csrf
										@if (config('settings::affiliate_type') == 'custom')
											<x-input type="text" name="code" :label="__('Affiliate Code')" required class="mt-2 w-full" />
										@endif
										<button type="submit" class="btn btn-outline-green">{{ __('Signup') }}</button>
									</form>
								</div>
							@endisset
							</div>
						</div> 
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</x-app-layout>