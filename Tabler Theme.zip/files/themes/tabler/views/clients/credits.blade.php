<x-app-layout title="{{ __('Credits') }}" clients>
<div class="page-body">
	<div class="container-xl">
	 <x-success />
		<div class="card">
			<div class="row g-0">
				<div class="col-12 col-md-3 border-end">
					<div class="card-body">
						<h4 class="subheader">{{ __('Profile Settings') }}</h4>
						<div class="list-group list-group-transparent">
							<a href="{{ route('clients.profile') }}" class="list-group-item list-group-item-action d-flex align-items-center">{{ __('Profile') }}</a>
							@if (config('settings::credits'))
                            <a href="{{ route('clients.credits') }}" class="list-group-item list-group-item-action d-flex align-items-center active">
                                {{ __('Credits') }}
                            </a>
							@endif
							<a href="{{ route('clients.api.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
								{{ __('Account API') }}
							</a>
							@if (config('settings::affiliate'))
								<a href="{{ route('clients.affiliate') }}" class="list-group-item list-group-item-action d-flex align-items-center">
									{{ __('Affiliate') }}
								</a>
							@endif
						</div>
					</div>
				</div>
				
				<div class="col-12 col-md-9 d-flex flex-column">
				 
					<div class="card">
						<div class="card-body">
								<div class="subheader">{{ __('Credits') }}</div>
								<h4>{{ __('Current Balance') }} <x-money :amount="Auth::user()->credits" /></h4>
							@if (count($gateways) == 0)
								<div class="alert alert-warning">
									{{ __('No payment gateway found.') }}
								</div>
							@else
								<form action="{{ route('clients.credits.add') }}" method="POST">
									@csrf
									<div class="row">
										<div class="col-md-6 col-sm-12">
											<x-input type="text" class="flex-1" placeholder="{{ __('Amount') }}" label="{{ __('Amount') }}" name="amount" id="amount"  />
										</div>
										<div class="col-md-6 col-sm-12">
										<x-input type="select" class="flex-1 ml-2" placeholder="{{ __('Payment Method') }}" id="gateway_id" name="gateway" label="{{ __('Payment Method') }}">
											<option value="" selected disabled>{{ __('Select Gateway') }}</option>
											@foreach ($gateways as $gateway)
												<option value="{{ $gateway->id }}">{{ isset($gateway->display_name) ? $gateway->display_name : $gateway->name }}</option>
											@endforeach
										</x-input>
										</div>
										<button class="btn btn-primary ">
											{{ __('Add') }}
										</button>
									</div>
								</form>
							@endif								 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</x-app-layout>