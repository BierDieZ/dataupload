<x-app-layout clients title="{{ __('Create Ticket') }}">
 <div class="page page-center">
 <div class="container container-narrow py-4">
<div class="row row-cards">
<x-success class="mb-4" />
	<div class="col-sm-12">
		<form method="POST" class="card" action="{{ route('clients.tickets.store') }}">
		@csrf
			<div class="card-header">
				<h3 class="card-title">{{ __('Create a new ticket.') }}</h3>
			</div> 
			<div class="card-body">
				<div class="row row-cards">
					<div class="col-sm-12">
						<div class="mb-3">
							<label class="form-label">{{ __('Title') }}</label>
							<input type="text" class="form-control" id="title" type="text" name="title" value="{{ old('title') }}" required autofocus />
						</div>
					</div>
					<div class="col-md-4">
						<div class="mb-3">
							<label class="form-label">{{ __('Category') }}</label>
							<select id="priority" name="priority" class="form-control form-select">
								<option value="low" @if (old('priority') == 1) selected @endif>
									{{ __('Support') }}</option>
								<option value="medium" @if (old('priority') == 2) selected @endif>
									{{ __('Sales') }}</option>
								<option value="high" @if (old('priority') == 3) selected @endif>
									{{ __('Other') }}</option>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="mb-3">
							<label class="form-label">{{ __('Related service') }}</label>
							<select id="service" name="service" class="form-control form-select">
								@if (count($services) > 0)
									<option value="low"
											@if (old('service') == 1) selected @endif>
										{{__('Select Product/Service')}} {{ __('(Optional)')}}
									</option>
									@foreach ($services as $service)
										@foreach ($service->products()->get() as $product2)
											@php
												$product = $product2->product()->get()->first();
												$status = '';
												switch ($product2->status) {
													case 'paid':
														$status = __('Active');;
														break;
													case 'cancelled':
														$status = __('Cancelled');
														break;
													case 'suspended':
														$status = __('Suspended');
														break;
													case 'deleted':
														$status = __('Deleted');
														break;
													default:
														$status = __('Unknown');
												}
											@endphp
											<option value="low"
													@if (old('service') == 1) selected @endif>
												<!-- Check if $product->name exists without calling it -->
												@if (isset($product->name))
													{{ ucfirst($product->name) }} -
													[#{{ $service->id }}] ({{ ucfirst($status) }})
												@else
													{{ __('Unknown -') }} [#{{ $service->id }}] ({{ ucfirst($status) }})
												@endif
											</option>
										@endforeach
									@endforeach
								@else
									<option value="low"
											@if (old('service') == 1) selected @endif>
										{{ __('None') }}
									</option>
								@endif
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="mb-3">
							<label class="form-label">{{ __('Priority') }}</label>
							 <select id="priority" name="priority" class="form-control form-select">
								<option value="low" @if (old('priority') == 1) selected @endif>
									{{ __('Low Priority') }}</option>
								<option value="medium" @if (old('priority') == 2) selected @endif>
									{{ __('Normal Priority') }}</option>
								<option value="high" @if (old('priority') == 3) selected @endif>
									{{ __('High Priority') }}</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="mb-3 mb-0">
							<label class="form-label">{{ __('Description') }}</label>
							<textarea rows="5" class="form-control" id="description" name="description" required>{{ old('description') }}</textarea>
						</div>
					</div>
					<div class="col-md-12">
						<div class="mb-3 mb-0">
							@if (config('settings::recaptcha') == 1)
								<div class="g-recaptcha mt-4" data-sitekey="{{ config('settings::recaptcha_site_key') }}"></div>
							@endif
						</div>
					</div>
				</div>
			</div>
			<div class="card-footer text-end">
				<button type="submit" class="btn btn-outline-primary">{{ __('Create') }}</button>
			</div>
		</form>
	</div>
</div>
</x-app-layout>
