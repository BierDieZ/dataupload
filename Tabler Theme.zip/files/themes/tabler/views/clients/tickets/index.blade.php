 
<x-app-layout clients title="{{ __('Tickets') }}">
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Tickets') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-primary" href="{{ route('clients.tickets.create') }}">
					{{ __('New Ticket') }}
					</a>
				</div>
			</div>
			@if (count($tickets) > 0)
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('Ticket') }}</th>
							<th>{{__('Title')}}</th>
							<th >{{__('Priority')}}</th>
							<th >{{__('Status')}}</th>
							<th>{{ __('Last Updated:') }}</th>
							<th class="w-1">Acties</th>
						</tr>
					</thead>
					<tbody>
					@foreach ($tickets as $ticket)
					<tr>
							<td>
								<div class="d-flex py-1 align-items-center">
									<div class="flex-fill">
										<div class="font-weight-medium">{{ $ticket->id }}</div>
									</div>
								</div>
							</td>
							<td>{{ Str::limit($ticket->title, 36) }}</td>
							<td><span class="badge bg-info text-white">{{ ucwords(str_replace('-', ' ', $ticket->priority)) }}</span></td>
							<td><span class="badge bg-info text-white">{{ ucwords(str_replace('-', ' ', $ticket->status)) }}</span></td>
							<td><span class="badge bg-secondary text-white">{{ $ticket->updated_at->diffForHumans() }}</span></td>
							<td>
								<a class="btn btn-outline-primary"  href="{{ route('clients.tickets.show', $ticket->id) }}">{{ __('View') }}</a>
							</td>
						</tr>
                     @endforeach
                                             	                                                                    
					</tbody>
				</table>
			</div>
			@else 			   
			<div class="text-center p-4">
				{{ __('No tickets found.') }}
			</div>
			@endif
		</div>
	</div>
	 
</x-app-layout>
