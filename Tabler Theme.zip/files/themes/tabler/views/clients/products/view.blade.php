<x-app-layout clients title="{{ __('Product') }}">
<div class="row">
	<div class="col-md-10 mb-4">
		<div class="page-pretitle">
			{{ __('Product: ') }}
		</div>
		<h2 class="page-title">
			{{ $product->name }}
		</h2>
	</div>
	<div class="col-md-2 text-end">
		@if ($link)		 
		<a href="{{ $link }}" class="btn btn-outline-green" target="_blank">
			{{ __('Login to Product') }}
		</a>
	@endif
	@if ($orderProduct->getOpenInvoices()->count() > 0)		 
		<a href="{{ route('clients.invoice.show', $orderProduct->getOpenInvoices()->first()->id) }}"class="btn btn-outline-primary">
			{{ __('View open Invoice') }}
		</a>
	@endif
	</div>
	<div class="col-sm-12 mb-2">
		<div class="card">
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('Product Name') }}</th>
							<th>{{ __('Product Price') }}</th>
							@if ($orderProduct->expiry_date)
							<th>{{ __('Due Date') }}</th>
							<th>{{ __('Status') }}</th>
							<th class="w-1"> {{ __('Billing Cycle') }}</th>
							@endif
						</tr>
					</thead>
					<tbody>
						<tr>
							<td data-label="{{ __('Product Name') }}">
								<div class="d-flex py-1 align-items-center">
									<!-- future <span class="avatar me-2" style="background-image: url({{ $product->image }})"></span>!-->
									<div class="flex-fill">
										<div class="font-weight-medium">{{ ucfirst($product->name) }}</div>
									</div>
								</div>
							</td>
							<td data-label="{{ __('Product Description') }}"><x-money :amount="$product->price()" showFree="true" /></td>
							@if ($orderProduct->expiry_date)
							<td data-label="{{ __('Product Description') }}">{{ $orderProduct->expiry_date }}</td>
							<td data-label="{{ __('Product Description') }}">{{ $orderProduct->status == 'paid' ? __('Active') : ucfirst($orderProduct->status) }}</td>
							<td data-label="{{ __('Product Description') }}">{{ ucfirst($orderProduct->billing_cycle) }}</td>
							@endif
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="col-sm-12">
		<div class="card">
			@isset($views['pages'])
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
				 @foreach ($views['pages'] as $page)
					<li class="nav-item">
						<a href="{{ route('clients.active-products.show', [$orderProduct->id]) }}/{{ $page['url'] }}" class="nav-link" > {{ $page['name'] }}</a>
					</li>
				 @endforeach
				 
				</ul>
			</div>
			@endisset
			<div class="card-body">
			@isset($extensionLink)
				@isset($views['pages'])
					@foreach ($views['pages'] as $page)
						@if ($extensionLink == $page['url'])
							@include($page['template'], $views['data'])
						@endif
					@endforeach
				@endisset
			@else
				@isset($views['template'])
					 @include($views['template'], $views['data'])
				@endisset
			@endisset
			</div>
		</div>
	</div>
</div>
 
</x-app-layout>
