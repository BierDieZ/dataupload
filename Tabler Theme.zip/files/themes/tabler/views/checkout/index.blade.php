<x-app-layout title="{{ __('Checkout') }}">
<script>
        function removeElement(element) {
            element.remove();
            this.error = true;
        }
    </script>
	
<div class="row">
	<div class="col-sm-12">
		<x-success />
	</div>
	@empty(!$products)  
	<div class="col-md-8 col-sm-12 mb-2">
 		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Order overview') }}</h3>
			</div>
			
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('Product') }}</th>
							<th> {{ __('Quantity') }}</th>
							<th>{{ __('Price') }}</th>
							<th class="w-1">{{ __('Action') }}</th>
						</tr>
					</thead>
					<tbody>
					@php
						$i = 0;
					@endphp
					@foreach ($products as $product)
						@php
							++$i;
						@endphp
						<tr>
							<td data-label="{{ __('Product') }}">
								<div class="d-flex py-1 align-items-center">
									<div class="flex-fill">
										<div class="font-weight-medium">{{ ucfirst($product->name) }}</div>
									</div>
								</div>
							</td>
							<td data-label="{{ __('Quantity') }}"}>
								 @if ($product->allow_quantity == 1 || $product->allow_quantity == 2)
									<form method="POST" action="{{ route('checkout.update', $product->id) }}">
										@csrf
										<div class="input-group" >
											<button onclick="if (this.parentNode.querySelector('input[type=number]').value > 0) this.parentNode.querySelector('input[type=number]').stepDown()" type="submit" class="btn">
												<span class="m-auto text-2xl font-thin">−</span>
											</button>
												<input type="number" name="quantity" value="{{ $product->quantity }}" class="text-center form-control w-10" min="1" max="100" />
											<button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" type="submit" class="btn">
												<span class="m-auto text-2xl font-thin">+</span>
											</button>
											
										</div>
									</form>
								@else
									<span class="badge bg-info text-white">{{ $product->quantity }}</span>
								@endif
							</td>
							<td data-label="{{ __('Price') }}">
								<span class="badge bg-info text-white">
									<x-money :amount="$product->price()" showFree="true" />
								</span>
							</td>
							<td data-label="{{ __('Remove') }}">
								<form method="POST" action="{{ route('checkout.remove', $product->id) }}">
								@csrf
									<button type="submit" class="btn btn-outline-danger">
										<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
										   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
										   <path d="M4 7l16 0"></path>
										   <path d="M10 11l0 6"></path>
										   <path d="M14 11l0 6"></path>
										   <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
										   <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
										</svg>
										{{ __('Remove') }} 
									</button>
								</form>
							</td>
							 
						</tr> 
					 @endforeach
					</tbody>
				</table>
			</div>
			<div class="card-footer">
			@if (empty($coupon))
				<form method="POST" action="{{ route('checkout.coupon') }}">
					@csrf
					 <div class="input-group mb-2">
						<input type="text" placeholder="{{ __('Coupon') }}" name="coupon" id="password" class="form-control" required />
						<button type="submit" class="btn btn-outline-success">{{ __('Validate') }}</button>
					 </div>
				</form>
			@else
				<div class="flex items-center justify-between">
					 
					<form method="POST" action="{{ route('checkout.coupon') }}">
						@csrf
						<input type="text" class="d-none" name="remove" value="1">
						<button type="submit" class="btn btn-red">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							   <path d="M4 7l16 0"></path>
							   <path d="M10 11l0 6"></path>
							   <path d="M14 11l0 6"></path>
							   <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
							   <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
							</svg>
							{{ __('Coupon:') }} {{ $coupon->code }} - {{ __('Remove') }} 
						</button>
					</form>
				</div>
			@endif
			</div>
			
		</div>
	</div>
	<div class="col-md-4 col-sm-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Checkout') }}</h3>
			</div>
			 
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('Details') }}</th>
							<th class="w-1">{{ __('Price') }}</th>
						</tr>
					</thead>
					<tbody>
					@foreach ($products as $product)
                            @if ($product->price > 0)
						<tr>
							<td data-label="{{ __('Details') }}">
								<div class="d-flex py-1 align-items-center">
									<div class="flex-fill">
									@if(count($products) > 1)
										<div class="font-weight-medium"> {{ ucfirst($product->name) }}</div>
									@endif
										<div class="font-weight-medium">{{ ucfirst($product->billing_cycle) }}</div>
									</div>
								</div>
							</td>
							<td data-label="{{ __('Price') }}">
								<span class="badge bg-info text-white">
									@php
										if ($product->quantity > 1) {
											$quantity = $product->quantity . " x";
										} else {
											$quantity = "";
										}
									@endphp
									@if ($product->discount)
										{{ $quantity }} <x-money :amount="round($product->price - $product->discount, 2)" />
									@else
										{{ $quantity }}  <x-money :amount="$product->price" />
									@endif
								</span>
								@if ($product->setup_fee > 0)
							  
								<span class="badge bg-info text-white mt-2">
								{{ __('Setup fee') }} {{ $quantity }}   <x-money :amount="$product->setup_fee - $product->discount_fee" /> 
								</div>
								@endif
							</td>
						</tr>
						@endif
                        @endforeach
						 @if (!empty($discount))
							 <tr>
								<td data-label="{{ __('Discount') }}">
									<div class="flex flex-row items-center">
										<span>{{ __('Discount') }}</span>
									</div>
								</td>
								<td data-label="{{ __('Price') }}">
									<span class="badge bg-info text-white mt-2"> <x-money :amount="round($discount, 2)" />  @if($coupon->type == "percent") ({{ $coupon->value }}%) @endif </span> 
								</td>
							</tr>
							
                        @endif
						<tr>
							<td data-label="{{ __('Total') }}">
								<div class="flex flex-row items-center">
									<span>{{ __('Total') }}</span>
								</div>
								 
							</td>
							<td data-label="{{ __('Price') }}">
								<span class="badge bg-info text-white mt-2">
									@if (!empty($discount))
										<x-money :amount="round($total - $discount, 2)" /> 
                                    @else
										<x-money :amount="$total" /> 
                                    @endif
									</span> 
							</td>
						</tr>
					</tbody>
				</table>
		 
			</div>
			
			<div class="card-footer">
				<form method="POST" action="{{ route('checkout.pay') }}">
				@csrf
					<div class="form-floating mb-3">
					<x-input type="select" name="payment_method" id="payment_method" label="{{ __('Payment method') }}" >
						@foreach (App\Models\Extension::where('type', 'gateway')->where('enabled', true)->get() as $gateway)
							<option value="{{ $gateway->id }}">
								{{ isset($gateway->display_name) ? $gateway->display_name : $gateway->name }}
							</option>
							@endforeach
							@auth
							@if(config('settings::credits'))
							<option value="credits">
								{{ __('Pay with credits') }}
							</option>
							@endif
							@endauth
					</x-input>
						 
					</div>
					 <div class="text-center">
						<x-input id="tos" type="checkbox" name="tos" label="{{ __('I agree to the terms of service.') }}" class="form-switch" required />
					 </div>
					<div class="form-footer">
						<button type="submit" class="btn btn-outline-primary w-100">
							{{ __('Checkout') }}
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	@else
		<div class="col-sm-12">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">{{ __('Order overview') }}</h3>
				</div>
				<div class="card-footer">
					{{ __('There are no products in your cart') }} 
				</div>
			</div>
		</div>
			@endempty
	</div>
</x-app-layout>
