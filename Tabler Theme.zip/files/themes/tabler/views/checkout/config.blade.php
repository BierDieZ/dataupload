<x-app-layout title="{{ __('Checkout') }}">
<x-success class="m-2 mb-4" />
<div class="row">
	<div class="col-sm-12">
		<div class="page page-center">
			<div class="container container-narrow py-4">
				<div class="card card-md">
					<div class="card-header">
						<h3 class="card-title">{{ __('Order overview') }}<br>
						<span class="card-subtitle">{{ $product->name }} </span>
						</h3>
					</div>
					<div class="card-body">
						<form method="POST" action="{{ route('checkout.config', $product->id) }}">
						@csrf
						@if ($prices->type == 'recurring')
							 
							<div class="form-floating mb-2">
								<select class="form-select" id="billing_cycle" name="billing_cycle" id="billing_cycle" required>
									@if ($prices->monthly)
										<option value="monthly" @if ($billing_cycle == 'monthly' || old('billing_cycle') == 'monthly') selected @endif>
											{{ __('Monthly') }} -  <x-money :amount="$prices->monthly" showFree="true" />
										</option>
									@endif
									@if ($prices->quarterly)
										<option value="quarterly" @if ($billing_cycle == 'quarterly' || old('billing_cycle') == 'quarterly') selected @endif>
											{{ __('Quarterly') }} -  <x-money :amount="$prices->quarterly" showFree="true" />
										</option>
									@endif
									@if ($prices->semi_annually)
										<option value="semi_annually" @if ($billing_cycle == 'semi_annually' || old('billing_cycle') == 'semi_annually') selected @endif>
											{{ __('Semiannually') }} -  <x-money :amount="$prices->semi_annually" showFree="true" />
										</option>
									@endif
									@if ($prices->annually)
										<option value="annually" @if ($billing_cycle == 'annually' || old('billing_cycle') == 'annually') selected @endif>
											{{ __('Annually') }} -  <x-money :amount="$prices->annually" showFree="true" />
										</option>
									@endif
									@if ($prices->biennially)
										<option value="biennially" @if ($billing_cycle == 'biennially' || old('billing_cycle') == 'biennially') selected @endif>
											{{ __('Biennially') }} -  <x-money :amount="$prices->biennially" showFree="true" />
										</option>
									@endif
									@if ($prices->triennially)
										<option value="triennially" @if ($billing_cycle == 'triennially' || old('billing_cycle') == 'triennially') selected @endif>
											{{ __('Triennially') }} -  <x-money :amount="$prices->triennially" showFree="true" />
										</option>
									@endif
								</select>
								<label for="billing_cycle">{{ __('Billing cycle') }}</label>
							</div>
							 
							<!-- Onchange of the billing cycle, reload the page with the new billing cycle -->
							<script>
								document.getElementById('billing_cycle').onchange = function() {
									window.location.href = "{{ route('checkout.config', $product->id) }}?billing_cycle=" + this.value;
								};
							</script>
						@endif
						 @foreach ($userConfig as $config)
							<x-config-item :config="$config" />
						@endforeach
						@if (count($customConfig) > 0)
							<h1 class="text-xl font-bold mt-6">{{ __('Configurable Options') }}</h1>
						@endif
						@foreach ($customConfig as $config)
							@php
								$configItems = $config
									->configurableOptions()
									->orderBy('order', 'asc')
									->get();
							@endphp
							@foreach ($configItems as $item)
								@if ($item->hidden)
									@continue
								@endif
								<div class="mt-2">
									@php $name = explode('|', $item->name)[1] ?? $item->name; @endphp
									@if ($item->type == 'quantity')
										<label class="form-label mb-2">x {{ ucfirst($name) }}
												@if ($item->configurableOptionInputs->first()->configurableOptionInputPrice->{$billing_cycle})
													<x-money :amount="$item->configurableOptionInputs->first()->configurableOptionInputPrice->{$billing_cycle}" />
												@else
													{{ __('Free') }} 
												@endif</label>
										<div class="input-group" >
											
											<button onclick="if (this.parentNode.querySelector('input[type=number]').value > 0) this.parentNode.querySelector('input[type=number]').stepDown()" type="button" class="btn">
												<span class="m-auto text-2xl font-thin">−</span>
											</button>
											
											<input type="number" name="{{ $item->id }}" id="{{ $item->id }}" placeholder="{{ ucfirst($name) }}" class="text-center form-control w-10" value="0" min="0" required />
											
											<button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" type="button"class="btn">
												<span class="m-auto text-2xl font-thin">+</span>
											</button>
										</div>
										 
									 
									@elseif($item->type == 'radio')
										<div class="form-label mb-2">{{ ucfirst($name) }}</div>									 
										@foreach ($item->configurableOptionInputs()->orderBy('order', 'asc')->get() as $key => $option)
											@php $name = explode('|', $option->name)[1] ?? $option->name; @endphp
											@if ($option->hidden)
												@continue
											@endif
											<label class="form-check form-check-inline">
												<input type="radio" id="{{ $option->id }}" name="{{ $item->id }}" value="{{ $option->id }}" class="form-check-input"  @if (old($item->name) == $option) checked @elseif(!$key) checked @endif>
												<span class="form-check-label">
												{{ ucfirst($name) }} 
												@if ($option->configurableOptionInputPrice->{$billing_cycle})
													-
													<x-money :amount="$option->configurableOptionInputPrice->{$billing_cycle}" />
													@endif
												</span>
											</label>     
										@endforeach
									@elseif($item->type == 'slider')
									   <div class="mt-2">
											@php $includeJs = true; @endphp
											<div class="form-label mb-2">{{ ucfirst($name) }}</div>	
											<div class="flex flex-col radios">
												@foreach ($item->configurableOptionInputs()->orderBy('order', 'asc')->get() as $key => $option)
													@php $name = explode('|', $option->name)[1] ?? $option->name; @endphp
													@if ($option->hidden)
														@continue
													@endif
													<input type="radio" id="{{ $option->id }}"
														name="{{ $item->id }}" value="{{ $option->id }}"
														@if (old($item->name) == $option) checked @elseif(!$key) checked @endif>
													<label class="ml-2  inline-flex items-center"
														for="{{ $option->id }}">
														{{ ucfirst($name) }}
														@if ($option->configurableOptionInputPrice->{$billing_cycle})
															-
															<x-money :amount="$option->configurableOptionInputPrice->{$billing_cycle}" />
														@endif
													</label>
												@endforeach
											</div>
										</div>
									@elseif($item->type == 'select')
										<x-input type="{{ $item->type }}" placeholder="{{ ucfirst($item->name) }}" name="{{ $item->id }}" id="{{ $item->id }}" label="{{ ucfirst($name) }}" required>
											@foreach ($item->configurableOptionInputs()->orderBy('order', 'asc')->get() as $option)
												@if ($option->hidden)
													@continue
												@endif
												@php $name = explode('|', $option->name)[1] ?? $option->name; @endphp
												<option value="{{ $option->id }}"
													@if (old($item->name) == $option) selected @endif>
													{{ ucfirst($name) }}
													@if ($option->configurableOptionInputPrice->{$billing_cycle})
														-
														<x-money :amount="$option->configurableOptionInputPrice->{$billing_cycle}" />
													@endif
												</option>
											@endforeach
										</x-input>
									@else 
										<x-input type="{{ $item->type }}" placeholder="{{ ucfirst($item->name) }}"
											name="{{ $item->id }}" id="{{ $item->id }}"
											label="{{ ucfirst($name) }}" required>
										</x-input>
									@endif
								</div>
							@endforeach
						@endforeach					
						</div>
						<div class="card-footer text-end">
							<button type="submit" class="btn btn-outline-primary ms-auto">
								{{ __('Continue') }}
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
    @isset($includeJs)
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/radioslider@1.0.0-beta.1/dist/radioslider.min.css">

        <script src="https://cdn.jsdelivr.net/npm/radioslider@1.0.0-beta.1/dist/jquery.radioslider.min.js"></script>
        <script>
            $(function() {
                var radios = $(".radios").radioslider({
					size: 'tiny' // or 'tiny'
				});
            });
        </script>
    @endisset
</x-app-layout>
