<x-app-layout title="Terms of Service">
<div class="row justify-content-center">
	<div class="col-lg-12">
		<div class="card card-lg">
			<div class="card-body markdown">
				<div class="row">
					<div class="col-sm-8">
						<h1>Terms of Service</h1>
					</div>
					<div class="col-sm-4">
						Last Updated: {{ config('settings::tos_last_updated') }}
					</div>
				</div>
				 @markdownify(config('settings::tos_text'))
			</div>
		</div>
	</div>
</div>

</x-app-layout>
