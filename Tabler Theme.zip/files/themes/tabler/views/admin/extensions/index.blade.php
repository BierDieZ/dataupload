<x-admin-layout title="{{ __('Extensions') }}" Clients>
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Extensions') }}
		</div>
		<h2 class="page-title">
			{{ __('Extensions and Gateways') }}
		</h2>
	</div>
</div>
<div class="col-12">
	<div class="card">
		<div class="card-header">
			<h3 class="card-title">{{ __('Extensions and Gateways') }}</h3>
			<div class="col-auto ms-auto d-print-none">
				<a type="button" class="btn btn-outline-primary" href="{{ route('admin.extensions.browse') }}">{{ __('Browse Extensions') }}</a>
			</div>
		</div>
	@if (!$servers)
        <p class="dark:bg-secondary-100 dark:text-darkmodetext text-gray-600 px-3 rounded-md text-xl m-4">
            {{ __('No extensions found') }}
        </p>
    @else
		<div class="card-body">
			<div class="row row-cards">
				<div class="col-md-6 col-sm-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">{{ __('Server') }}</h3>
						</div>
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table card-table table-vcenter text-nowrap datatable" id="table">
									<thead class="bg-secondary-100 ">
										<tr>
											<th>{{ __('Name') }}</th>
											<th>{{ __('Enabled?') }}</th>
											<th>{{ __('Version') }}</th>
											<th class="w-1">{{ __('Edit') }}</th>
										</tr>
									</thead>
									<tbody>
										 
										@foreach ($servers as $extensio)
											@if ($extensio == '.' || $extensio == '..')
												@continue
											@endif
											@php
												$extension = App\Models\Extension::where('name', $extensio)
													->get()
													->first();
											@endphp
											@php $metadata = App\Helpers\ExtensionHelper::getMetadata($extension); @endphp
											<tr>
												<td>{{ $metadata->display_name ?? $extensio }}</td>
												<td> @if ($extension->enabled)
														<span class="badge bg-green text-white">{{ __('Yes') }}</span>
													@else
														<span class="badge bg-red text-white">{{ __('No') }}</span>
													@endif
												</td>
												<td><span class="badge bg-azure text-white">{{ $metadata->version ?? 'Unknown Version' }}</span></td>
												<td><a href="{{ route('admin.extensions.edit', ['server', $extensio]) }}" class="btn btn-outline-primary">{{ __('Edit') }}</a></td>
											</tr>
										@endforeach
										 
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">{{ __('Gateway') }}</h3>
						</div>
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table card-table table-vcenter text-nowrap datatable" id="table">
									<thead>
										<tr>
											<th>{{ __('Name') }}</th>
											<th>{{ __('Enabled?') }}</th>
											<th>{{ __('Version') }}</th>
											<th class="w-1">{{ __('Edit') }}</th>
										</tr>
									</thead>
									<tbody>
										 
										 @foreach ($gateways as $gateway)
											@if ($gateway == '.' || $gateway == '..')
												@continue
											@endif
											@php
												$extension = App\Models\Extension::where('name', $gateway)
													->get()
													->first();
											@endphp
											@php $metadata = App\Helpers\ExtensionHelper::getMetadata($extension); @endphp
											<tr>
												<td>{{ $metadata->display_name ?? $gateway }}</td>
												<td>
													@if ($extension->enabled)
														<span class="badge bg-green text-white">{{ __('Yes') }}</span>
													@else
														<span class="badge bg-red text-white">{{ __('No') }}</span>
													@endif
												</td>
												<td><span class="badge bg-azure text-white">{{ $metadata->version ?? 'Unknown Version' }}</span></td>
												<td><a href="{{ route('admin.extensions.edit', ['gateway', $gateway]) }}" class="btn btn-outline-primary">{{ __('Edit') }}</a></td>
											</tr>
										@endforeach
										 
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">{{ __('Events') }}</h3>
						</div>
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table card-table table-vcenter text-nowrap datatable" id="table">
									<thead>
										<tr>
											<th>{{ __('Name') }}</th>
											<th>{{ __('Enabled?') }}</th>
											<th>{{ __('Version') }}</th>
											<th class="w-1">{{ __('Edit') }}</th>
										</tr>
									</thead>
									<tbody>
										 
										 @foreach ($events as $event)
											@if ($event == '.' || $event == '..')
												@continue
											@endif
											@php
												$extension = App\Models\Extension::where('name', $event)
													->get()
													->first();
											@endphp
											@php $metadata = App\Helpers\ExtensionHelper::getMetadata($extension); @endphp
											<tr>
												<td>{{ $event }}</td>
												<td>
													@if ($extension->enabled)
														<span class="badge bg-green text-white">{{ __('Yes') }}</span>
													@else
														<span class="badge bg-red text-white">{{ __('No') }}</span>
													@endif
												</td>
												<td><span class="badge bg-azure text-white">{{ $metadata->version ?? 'Unknown Version' }}</span></td>
												<td><a href="{{ route('admin.extensions.edit', ['event', $event]) }}" class="btn btn-outline-primary">{{ __('Edit') }}</a></td>
											</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    @endif
	</div>
</div>
</x-admin-layout>
