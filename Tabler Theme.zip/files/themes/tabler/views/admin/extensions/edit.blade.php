<x-admin-layout title=" {{ __('Edit client') }}" Clients>
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Edit') }}
		</div>
		<h2 class="page-title">
			{{ $extension->name }}
		</h2>
	</div>
  	<div class="col-12">
		<div class="card">
			<div class="card-header">
				 
			</div>	
 
			<form method="POST" action="{{ route('admin.extensions.update', [$extension->type, $extension->name]) }}">
				@csrf
			   <div class="card-body">	
					<div class="row">
						<div class="col-md-2 col-sm-12">
							<div class="row">
								<div class="col-sm-12 mb-3">
									<x-input type="select" id="enabled" name="enabled" label="{{ __('Enabled') }}" required>
										@if ($extension->enabled == 1)
											<option value="1" selected>True</option>
											<option value="0">False</option>
										@else
											<option value="1">True</option>
											<option value="0" selected>False</option>
										@endif
									</x-input>
								</div>
							</div>
						</div>
						<div class="col-md-10 col-sm-12">
							<div class="row">
								<div class="col-sm-12 mb-3">
									<x-input id="display_name" type="text" name="display_name" label="{{ __('Display Name') }}" value="{{ isset($extension->display_name) ? $extension->display_name : $metadata->display_name ?? $extension->name }}" required />
								</div>
								@foreach ($extension->config as $setting)
								<div class="col-sm-6 mb-3">
									<x-config-item :config="$setting" />
								</div>
								@endforeach
							</div>
						</div>
					</div>
				</div>
				
				
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green">{{ __('Save') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>

</x-admin-layout>
