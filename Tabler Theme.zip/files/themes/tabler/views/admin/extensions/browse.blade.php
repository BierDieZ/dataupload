<x-admin-layout title="{{ __('Browse extensions') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Browse extensions') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
</div>
<div class="col-12">
	<div class="card">
		<div class="card-header">
			<h3 class="card-title">{{ __('Browse extensions') }}</h3>
			<div class="col-auto ms-auto d-print-none">
				<input type="text" class="form-control" placeholder="{{ __('Search') }}" id="extensionSearch">
			</div>
		</div>
		<div class="row row-cards px-4 py-4">
		@foreach ($extensions as $extension)
            @php $extension = (object) $extension; @endphp
			<div class="col-lg-4 col-md-6 col-sm-12  ">
				<div class="card">
					<div class="card-body p-4 text-center">
						<span class="avatar avatar-xl mb-3 rounded" style="background-image: url({{ config('app.marketplace') . '../../storage/' . $extension->icon }})"></span>
						<h3 class="m-0 mb-1">{{ $extension->name }}</h3>
						<div class="text-secondary"><small>{{ $extension->slogan }}</small></div>
						<div class="mt-3">
							<span class="badge bg-purple-lt">{{ ucFirst($extension->type) }}</span>
						</div>
						<div class="ribbon bg-green">
							{{ $extension->price == 0?"Free":$extension->price . "$" }}
						</div>
					</div>
					<hr style="margin-top:-15px;">
					<div class="text-center" style="margin-top:-15px; margin-bottom:15px;">
						@if ($extension->price == 0)                                        
						<form action="{{ route('admin.extensions.install', $extension->id) }}" method="POST">
							@csrf
							<button type="submit" class="btn btn-outline-primary">{{ __('Download') }}</button>
						</form>
						@else 
						<a href="{{ config('app.marketplace') . '/extension/' . $extension->id  . '/' . $extension->name }}" class="btn btn-outline-primary">{{ __('Buy') }}</a> 
						@endif
					</div>
				</div>
				 
			</div>
		 @endforeach
		</div>
</x-admin-layout>
