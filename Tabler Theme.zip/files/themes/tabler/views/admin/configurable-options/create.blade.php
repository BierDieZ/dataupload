<x-admin-layout title="{{ __('Create new Configurable Option Group') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Create new Configurable Option Group') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Create new Configurable Option Group') }}</h3>
			</div>
			<form method="POST" action="{{ route('admin.configurable-options.store') }}">
            @csrf
				<div class="card-body">
					<div class="row">
						<div class="col-sm-12">
							<div class="row">
								<div class="col-md-4 col-sm-12">
									<x-input id="name" class="block mt-1 w-full" type="text" name="name" label="Name" placeholder="Name" required autofocus />
								</div>
								<div class="col-md-4 col-sm-12">
									<x-input id="description" class="block mt-1 w-full" type="text" name="description" label="Description" placeholder="Description" required autofocus />
								</div>
								<div class="col-md-4 col-sm-12">
									<x-input id="products" class="block mt-1 w-full" type="select" name="products[]" label="Products" placeholder="Products" required multiple>
										@foreach ($products as $product)
											<option value="{{ $product->id }}">{{ $product->name }}</option>
										@endforeach
									</x-input>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green ms-auto"> {{ __('Create') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>
</x-admin-layout>
