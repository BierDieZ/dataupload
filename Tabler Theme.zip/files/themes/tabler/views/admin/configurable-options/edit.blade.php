<x-admin-layout title="{{ __('Editing') }} {{ $configurableOptionGroup->name }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Editing') }}
		</div>
		<h2 class="page-title">
			{{ __('Configurable Options') }}
		</h2>
	</div>
    <div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Configurable Options') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#defaultModal"> {{ __('Create new Option') }}</button>
				</div>
				
			</div>
			<div class="card-body">
				<div class="row row-cards">
					<div class="col-md-4 col-sm-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">{{ $configurableOptionGroup->name }}</h3>
							</div>
							<form method="POST" action="{{ route('admin.configurable-options.update', $configurableOptionGroup->id) }}">
							@csrf
								<div class="card-body">
							  
									<x-input id="name" class="block mt-1 w-full" type="text" name="name" label="{{ __('Name') }}" placeholder="{{ __('Name') }}" required autofocus value="{{ $configurableOptionGroup->name }}" />
									<x-input id="description" type="text" name="description" label="{{ __('Description') }}" placeholder="{{ __('Description') }}" required autofocus value="{{ $configurableOptionGroup->description }}" />
									<!-- MultiSelect -->
									<x-input id="products" type="select" name="products[]" label="{{ __('Products') }}" placeholder="{{ __('Products') }}" required multiple>
										@foreach ($products as $product)
											<option value="{{ $product->id }}" @if (in_array($product->id, $configurableOptionGroup->products)) selected @endif> {{ $product->name }}</option>
										@endforeach
									</x-input>
								</div>
								<div class="card-footer">
									<button type="submit" class="btn btn-outline-green w-full">{{ __('Update') }}</button>
								</div>
							</form>
						</div>
					</div>
				  
					<div class="col-md-8 col-sm-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">{{ $configurableOptionGroup->name }}</h3>
							</div>
							<div class="table-responsive">
								<table class="table card-table table-vcenter text-nowrap datatable" id="clientdatatable">
									<thead>
										<tr>
											<th>{{ __('ID') }}</th>
											<th>{{ __('Name') }}</th>
											<th>{{ __('Created At') }}</th>
											<th>{{ __('Edit') }}</th>
											<th>{{ __('Delete') }}</th>
										</tr>
									</thead>
									<tbody>
									@foreach ($configurableOptions as $configurableOption)
										<tr>
											<td data-lbel="{{ __('ID') }}">{{ $configurableOption->id }}</td>
											<td data-lbel="{{ __('Name') }}">{{ $configurableOption->name }}</td>
											<td data-lbel="{{ __('Created At') }}">{{ $configurableOption->created_at }}</td>
											<td data-lbel="{{ __('Edit') }}">
												<button type="button" class="btn btn-outline-info" id="editModalButton{{ $configurableOption->id }}" data-bs-toggle="modal" data-bs-target="#editModal{{ $configurableOption->id }}" data-modal-toggle="editModal{{ $configurableOption->id }}">
													{{ __('Edit') }}
												</button>
												<x-modal id="editModal{{ $configurableOption->id }}" title="{{ __('Edit') }} {{ $configurableOption->name }}" class="modal-xl">
													<form method="POST"action="{{ route('admin.configurable-options.options.update', ['configurableOptionGroup' => $configurableOptionGroup->id, 'configurableOption' => $configurableOption->id]) }}">
														@csrf
														<div class="row">
															<div class="col-sm-12">
																<div class="row">
																	<div class="col-md-6 col-sm-12">
																		<x-input id="name" type="text" name="name" label="{{ __('Name') }}" placeholder="{{ __('Name') }}" required value="{{ $configurableOption->name }}" />
																	</div>
																	<div class="col-md-2 col-sm-12">
																		<x-input id="type" type="select" name="type" label="Type" placeholder="Type" required>
																			<option value="select" @if ($configurableOption->type == 'select') selected @endif> Select</option>
																			<option value="radio" @if ($configurableOption->type == 'radio') selected @endif>Radio</option>
																			<option value="checkbox" @if ($configurableOption->type == 'checkbox') selected @endif> Checkbox</option>
																			<option value="quantity" @if ($configurableOption->type == 'quantity') selected @endif> Quantity</option>
																			<option value="slider" @if ($configurableOption->type == 'slider') selected @endif>Slider</option>
																		</x-input>
																	</div>
																	<div class="col-md-2 col-sm-12">
																		<x-input id="order" type="text" name="order" label="Order" placeholder="Order" required value="{{ $configurableOption->order }}" />
																	</div>
																	<div class="col-md-2 col-sm-12 text-center">
																		<x-input type="hidden" value="0" name="hidden" />
																		<x-input id="hidden" type="checkbox" checked="{{ $configurableOption->hidden }}" name="hidden" label="Hidden" placeholder="Hidden" value="1" />
																	</div>
																</div>
															</div>
														@foreach ($configurableOption->configurableOptionInputs as $option)
															@php $pricing = $option->configurableOptionInputPrice; @endphp
															<div class="col-sm-12 mb-3">
																<div class="card">
																	<div class="card-body">
																		<div class="row">
																			<div class="col-md-5 col-sm-12"> 
																				<x-input label="Name" type="text" name="option[{{ $option->id }}][name]" placeholder="Name" value="{{ $option->name }}" />
																			</div>
																			<div class="col-md-4 col-sm-12"> 
																				<x-input label="Order" type="text" name="option[{{ $option->id }}][order]" placeholder="Order" value="{{ $option->order }}" />
																				 
																			</div>
																			<div class="col-md-2 col-sm-12"> 
																				<x-input label="Hidden" type="checkbox" name="option[{{ $option->id }}][hidden]" checked="{{ $option->hidden }}" placeholder="hidden" value="1" />
																			</div>
																 
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Monthly/One-Time" type="text" name="option[{{ $option->id }}][pricing][monthly]" placeholder="Monthly" value="{{ $pricing['monthly'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Quarterly" type="text" name="option[{{ $option->id }}][pricing][quarterly]" placeholder="Quarterly" value="{{ $pricing['quarterly'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 	
																				<x-input label="Semi-Annually" type="text" name="option[{{ $option->id }}][pricing][semi_annually]" placeholder="Semi-Annually" value="{{ $pricing['semiannually'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 	
																				<x-input label="Annually" type="text" name="option[{{ $option->id }}][pricing][annually]" placeholder="Annually" value="{{ $pricing['annually'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 	
																				<x-input label="Biennially" type="text" name="option[{{ $option->id }}][pricing][biennially]" placeholder="Biennially" value="{{ $pricing['biennially'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 	
																				<x-input label="Triennially" type="text" name="option[{{ $option->id }}][pricing][triennially]" placeholder="Triennially" value="{{ $pricing['triennially'] ?? '' }}" />
																			</div>
																		</div>
																		<div class="row">
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][monthly_setup]" placeholder="Monthly/One-time Setup Fee" value="{{ $pricing['monthly_setup'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][quarterly_setup]" placeholder="Quarterly Setup Fee" value="{{ $pricing['quarterly_setup'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][semi_annually_setup]" placeholder="Semi-Annually Setup Fee" value="{{ $pricing['semi_annually_setup'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][annually_setup]" placeholder="Annually Setup Fee" value="{{ $pricing['annually_setup'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12"> 
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][biennially_setup]" placeholder="Biennially Setup Fee" value="{{ $pricing['biennially_setup'] ?? '' }}" />
																			</div>
																			<div class="col-xl-2 col-lg-3 col-md-4 col-sm-12">
																				<x-input label="Setup Fee" type="text" name="option[{{ $option->id }}][pricing][triennially_setup]" placeholder="Triennially Setup Fee" value="{{ $pricing['triennially_setup'] ?? '' }}" />
																			</div>
																		</div>
																	</div>
																	<div class="card-footer text-end">
																		<button type="button" class="btn btn-outline-danger ms-auto" onclick="event.preventDefault(); document.getElementById('deleteOption{{ $option->id }}').submit();">{{ __('Delete') }}</button>
																	</div>
																</div>
															</div>
														@endforeach
														</div>
														<button type="submit" class="btn btn-outline-green ms-auto" onclick="event.preventDefault(); document.getElementById('updateModalForm).submit();">{{ __('Update') }}</button>
													</form>
														 
													@foreach ($configurableOption->configurableOptionInputs as $option)
														<form method="POST" class="hidden" action="{{ route('admin.configurable-options.options.inputs.destroy', ['configurableOptionGroup' => $configurableOptionGroup->id, 'configurableOption' => $configurableOption->id, 'configurableOptionInput' => $option->id]) }}" id="deleteOption{{ $option->id }}">
															@csrf
															@method('DELETE')
														</form>
													@endforeach
													<form method="POST" action="{{ route('admin.configurable-options.options.inputs.create', ['configurableOptionGroup' => $configurableOptionGroup->id, 'configurableOption' => $configurableOption->id]) }}">
														@csrf
														<button type="submit" class="btn btn-outline-primary mt-2" id="addInput{{ $configurableOption->id }}">{{ __('Add new input') }}</button>
													</form>
												</x-modal>
											</td>
											<td data-lbel="{{ __('Delete') }}">
												<button type="button" class="btn btn-outline-danger" onclick="event.preventDefault(); document.getElementById('deleteForm{{ $configurableOption->id }}').submit();">
													{{ __('Delete') }}
												</button>
												<form id="deleteForm{{ $configurableOption->id }}" action="{{ route('admin.configurable-options.options.destroy', ['configurableOptionGroup' => $configurableOptionGroup->id, 'configurableOption' => $configurableOption->id]) }}" method="POST" class="hidden">
													@csrf
													@method('DELETE')
												</form>
											</td>
										</tr>
									@endforeach
								</tbody>
							</table>
							</div>
					</div>
				</div>
				<x-modal title="Create new Configurable option" id="defaultModal" class="modal">
				<div class="card">
					<form method="POST"action="{{ route('admin.configurable-options.options.create', $configurableOptionGroup->id) }}">
						@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<x-input id="name" type="text" name="name" label="Name" placeholder="Name" required autofocus />
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button type="submit" class="btn btn-outline-green ms-auto"> {{ __('Create') }}</button>
						</div>
					</form>
				</div>
				</x-modal>
			</div>
		</div>
	</div>
    <script>
        var open = '{{ session()->get('open') }}';
        if (open) {
            document.addEventListener("DOMContentLoaded", function(event) {
                setTimeout(() => {
                    document.getElementById('editModalButton' + open).click();
                }, 500);
            });
        }
    </script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
 
</x-admin-layout>
