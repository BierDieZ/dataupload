<x-admin-layout title="{{ __('Configurable Options') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Configurable Options') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Configurable Options') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-green" href="{{ route('admin.configurable-options.create') }}"> {{ __('Create') }}</a>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable">
					<thead>
						<tr>
							<th>{{ __('ID') }}</th>
							<th>{{ __('Name') }}</th>
							<th>{{ __('Description') }}</th>
							<th>{{ __('Created At') }}</th>
							<th>{{ __('Edit') }}</th>
							<th class="w-1">{{ __('Delete') }}</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($configurableGroups as $configurableGroup)
							<tr>
								<td>{{ $configurableGroup->id }}</td>
								<td>{{ $configurableGroup->name }}</td>
								<td>{{ $configurableGroup->description }}</td>
								<td>{{ $configurableGroup->created_at }}</td>
								<td>
									<a href="{{ route('admin.configurable-options.edit', $configurableGroup->id) }}" class="btn btn-outline-primary">{{ __('Edit/View') }}</a>
								</td>
								<td>
									<form method="POST"action="{{ route('admin.configurable-options.delete', $configurableGroup->id) }}">
										@csrf
										@method('DELETE')
										<button type="submit" class="btn btn-outline-danger">{{ __('Delete') }}</button>
									</form>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
</x-admin-layout>