<x-admin-layout clients title="{{ __('Create Ticket') }}">
 
<div class="row row-cards">
<x-success class="mb-4" />
	<div class="col-sm-12">
		<form method="POST" class="card" action="{{ route('admin.tickets.store') }}">
		@csrf
			<div class="card-header">
				<h3 class="card-title">{{ __('Create a new ticket.') }}</h3>
			</div> 
			<div class="card-body">
				<div class="row row-cards">
					<div class="col-sm-12">
						<div class="mb-3">
							<label class="form-label">{{ __('Title') }}</label>
							<input type="text" class="form-control" id="title" type="text" name="title" value="{{ old('title') }}" required autofocus />
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<x-input type="select" id="user" name="user" :label="__('User')">
								@foreach ($users as $user)
									<option value="{{ $user->id }}" @if ($user->id == old('user')) selected @endif>
										{{ $user->name }}</option>
								@endforeach
							</x-input>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<x-input type="select" id="priority" name="priority" :label="__('Priority')">
								<option value="low" @if (old('priority') == 1) selected @endif>{{ __('Low') }}</option>
								<option value="medium" @if (old('priority') == 2) selected @endif>{{ __('Medium') }}</option>
								<option value="high" @if (old('priority') == 3) selected @endif>{{ __('High') }}</option>
							</x-input>
						</div>
					</div>
					<div class="col-md-12">
						<div class="mb-3 mb-0">
							<label class="form-label">{{ __('Description') }}</label>
							<textarea rows="5" class="form-control" id="description" name="description" required>{{ old('description') }}</textarea>
						</div>
					</div>
					<div class="col-md-12">
						<div class="mb-3 mb-0">
							@if (config('settings::recaptcha') == 1)
								<div class="g-recaptcha mt-4" data-sitekey="{{ config('settings::recaptcha_site_key') }}"></div>
							@endif
						</div>
					</div>
				</div>
			</div>
			<div class="card-footer text-end">
				<button type="submit" class="btn btn-primary">{{ __('Create') }}</button>
			</div>
		</form>
	</div>
</div>
</x-admin-layout>
