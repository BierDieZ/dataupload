<x-admin-layout clients title="{{ __('Tickets ' . $ticket->title) }}">
<div class="page-body">
	<div class="container-xl">
	<x-success />
		
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{__('Ticket')}} #{{ $ticket->id }} <br> <small>{{ $ticket->title }}</small></h3>
			</div>
			<form action="{{ route('admin.tickets.update', $ticket->id) }}" method="POST" class="pb-10">
			@csrf
				<div class="card-body">			
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<x-input type="text" id="user" :label="__('User')" name="user" value="{{ $ticket->user->name }} (#{{ $ticket->user->id }})" readonly />
						</div>
						<div class="col-md-4 col-sm-6">
							<x-input type="text" id="title" :label="__('Subject')" name="title" value="{{ $ticket->title }}" />
						</div>
						<div class="col-md-4 col-sm-6">
						<x-input type="select" name="priority" :label="__('Priority')">
							<option value="low" @if ($ticket->priority == "low") selected @endif>{{ __('Low') }}</option>
							<option value="medium" @if ($ticket->priority == "medium") selected @endif>{{ __('Medium') }}</option>
							<option value="high" @if ($ticket->priority == "high") selected @endif>{{ __('High') }}</option>
						</x-input>
						</div>
						<div class="col-md-4 col-sm-6">
							<x-input type="select" id="product" name="product_id" :label="__('Product')">
								<option value="">{{ __('None') }}</option>
								@foreach ($ticket->user->orderProducts()->with('product')->get() as $product)
									<option value="{{ $product->id }}" @if ($product->id == $ticket->order_id) selected @endif> {{ $product->id }} - {{ $product->product->name }} </option>
								@endforeach
							</x-input>
						</div>
						<div class="col-md-4 col-sm-6">
							<x-input type="select" name="status" :label="__('Status')" >
								<option value="open" @if ($ticket->status == 'open') selected @endif>{{ __('Open') }}</option>
								<option value="closed" @if ($ticket->status == 'closed') selected @endif>{{ __('Closed') }}</option>
							</x-input>
						</div>
						<div class="col-md-4 col-sm-6">
							<x-input type="select" id="assigned_to" name="assigned_to" :label="__('Assigned To')">
								<option value="">{{ __('None') }}</option>
								@foreach (App\Models\User::where('role_id', '!=', 2)->with('role')->get() as $user)
									<option value="{{ $user->id }}" @if ($user->id == $ticket->assigned_to) selected @endif>{{ $user->name }} - {{ $user->role->name }} </option>
								@endforeach
							</x-input>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Update') }}</button>
				</div>
			</form>
			<div class="hr-text">
				<span>Chat</span>
			</div>
			<div class="row g-0">
				<div class="col-sm-12">
					<div class="card-body scrollable" style="height: 35rem">
					@php $messages = $ticket->messages()->with('user')->get(); @endphp
					@empty($messages)
						{{ __('No messages yet') }}
					@else
						<div class="chat">
							<div class="chat-bubbles">
						@foreach ($messages as $message)										
							@if ($message->user_id == Auth::user()->id)
								<div class="chat-item">
									<div class="row align-items-end justify-content-end">
										<div class="col col-lg-6">
											<div class="chat-bubble chat-bubble-me">
												<div class="chat-bubble-title">
													<div class="row">
														<div class="col chat-bubble-author">{{__('You')}}</div>
														<div class="col-auto chat-bubble-date">({{$message->messageDate()}})  </div>
													</div>
												</div>
												<div class="chat-bubble-body">
													<p>{!! Str::Markdown(str_replace("\n", "  \n", $message->message), ['html_input' => 'escape']) !!}</p>
												@if($message->files()->count() > 0)
													<br>
													<hr class="border-slate-100">

													<div class="flex justify-end text-end">
														<span class="text-slate-100 ">{{ __('Attachments') }} ({{ $message->files()->count() }})</span>
													</div>

													<div class="flex flex-row flex-wrap gap-3">
														@foreach($message->files as $attachment)
															<div class="col-span-1">
																<a href="{{ $attachment->url }}" class="text-slate-200 hover:text-white" download>
																	@if($attachment->isImage())
																		<div class="mt-2">
																			<img src="{{ $attachment->url }}" class="rounded img-fluid" alt="">
																		</div>
																	@else
																		<div class="text-slate-200 hover:text-white text-sm break-all text-center">
																			 <div class="justify-center flex">
																				 <div id="tooltip" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
																					 {{ $attachment->filename }}
																					 <div class="tooltip-arrow" data-popper-arrow></div>
																				 </div>
																				<i data-tooltip-target="tooltip" class="ri-file-text-line text-4xl mx-auto text-slate-200"></i>
																			</div>
																		</div>
																	@endif
																</a>
															</div>
														@endforeach
													</div>
												@endif
												</div>
											</div>
										</div>
										<div class="col-auto">
											<span class="avatar" style="background-image: url(https://www.gravatar.com/avatar/{{ md5($message->user->email) }}?s=200&d=mp)"></span>
										</div>
									</div>
								</div>
							@elseif ($message->user_id !== Auth::user()->id)
								<div class="chat-item">
									<div class="row align-items-end">
										<div class="col-auto">
											<span class="avatar" style="background-image: url(https://www.gravatar.com/avatar/{{ md5($message->user->email) }}?s=200&d=mp)"></span>
										</div>
										<div class="col col-lg-6">
											<div class="chat-bubble">
												<div class="chat-bubble-title">
													<div class="row">
														<div class="col chat-bubble-author">{{$message->user->name}}</div>
														<div class="col-auto chat-bubble-date">({{$message->messageDate()}})</div>
													</div>
												</div>
												<div class="chat-bubble-body">
													<p>{!! Str::Markdown(str_replace("\n", "  \n", $message->message), ['html_input' => 'escape']) !!}</p>
													@if($message->files()->count() > 0)
														<br>
														<hr class="border-slate-100">
														<div class="flex justify-end text-end">
															<span class="text-slate-100 ">{{ __('Attachments') }} ({{ $message->files()->count() }})</span>
														</div>
														<div class="flex flex-row flex-wrap gap-3">
															@foreach($message->files as $attachment)
																<div class="col-span-1">
																	<a href="{{ $attachment->url }}" class="text-slate-200 hover:text-white" download>
																		@if($attachment->isImage())
																			<div class="mt-2">
																				<img src="{{ $attachment->url }}" class="rounded img-fluid" alt="">
																			</div>
																		@else
																			<div class="text-slate-200 hover:text-white text-sm break-all text-center">
																				 <div class="justify-center flex">
																					 <div id="tooltip" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
																						 {{ $attachment->filename }}
																						 <div class="tooltip-arrow" data-popper-arrow></div>
																					 </div>
																					<i data-tooltip-target="tooltip" class="ri-file-text-line text-4xl mx-auto text-slate-200"></i>
																				</div>
																			</div>
																		@endif
																	</a>
																</div>
															@endforeach
														</div>
													@endif
												</div>
											</div>
										</div>
									</div>
								</div>
							@endif
						@endforeach
						</div>
					</div>
					@endempty
					</div>
					<div class="card-footer">
					 @if($ticket->status == "closed")
						<div class="text-danger text-center">
							{{__('The ticket has been closed, you cannot respond.')}}
						</div>
					@else
						<form method="POST" action="{{ route('admin.tickets.reply', $ticket->id) }}" id="reply" enctype="multipart/form-data">
						@csrf
							<div class="input-group input-group-flat">
								<input type="text" id="message" name="message" class="form-control" autocomplete="off" placeholder="{{ __('Reply') }}" required />
								<span class="input-group-text">								 
									<label for="attachments" data-bs-toggle="tooltip" aria-label="Add attachments" title="Add attachments">
										<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 7l-6.5 6.5a1.5 1.5 0 0 0 3 3l6.5 -6.5a3 3 0 0 0 -6 -6l-6.5 6.5a4.5 4.5 0 0 0 9 9l6.5 -6.5" /></svg>
									</label>
									<x-input type="file" id="attachments" :label="__('Attachments')" name="attachments[]" multiple class="d-none"/>
									<x-recaptcha form="reply" />
									<button type="submit" id="submit-button" style="border:1px solid white; background-color: transparent;">
										<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-send" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
										   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
										   <path d="M10 14l11 -11"></path>
										   <path d="M21 3l-6.5 18a.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a.55 .55 0 0 1 0 -1l18 -6.5"></path>
										</svg>
									</button>
								</span>
							</div>
						</form>
					@endif
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
 
    <script>
        const fileInput = document.getElementById('attachments');
        const fileList = document.getElementById('attachments-list');
        const submitButton = document.getElementById('submit-button');

        const files = [];

        fileInput.addEventListener('change', (e) => {
            const selectedFiles = e.target.files;

            for (let i = 0; i < selectedFiles.length; i++) {
                files.push(selectedFiles[i]);
                const listItem = createListItem(selectedFiles[i]);
                fileList.appendChild(listItem);
            }

            fileInput.value = '';
        });

        function createListItem(file) {
            const listItem = document.createElement('div');
            listItem.classList.add('bg-secondary-200', 'rounded-md', 'w-full', 'max-w-[120px]', 'p-2', 'justify-center', 'flex-col', 'items-center', 'shadow-sm', 'mb-3');

            const fileContent = document.createElement('div');
            fileContent.classList.add('justify-center', 'flex');

            if (/\.(jpe?g|png|gif|bmp)$/i.test(file.name)) {
                const image = document.createElement('img');
                image.src = URL.createObjectURL(file);
                image.alt = file.name;
                image.classList.add('max-h-10', 'rounded-sm');

                fileContent.appendChild(image);
            } else {
                const icon = document.createElement('i');
                icon.classList.add('ri-article-line', 'text-4xl', 'mx-auto', 'text-secondary-500');
                fileContent.appendChild(icon);
            }

            const fileName = document.createElement('div');
            fileName.textContent = file.name;
            fileName.classList.add('text-xs', 'text-center', 'text-secondary-500', 'w-full', 'truncate', 'mt-1');

            const removeButton = document.createElement('button');
            removeButton.textContent = 'x';
            removeButton.classList.add('text-red-500', 'hover:text-red-700', 'cursor-pointer', 'float-right', 'text-xs', 'font-bold');
            removeButton.addEventListener('click', () => {

                const index = files.indexOf(file);
                files.splice(index, 1);
                listItem.remove();
            });

            listItem.appendChild(removeButton);
            listItem.appendChild(fileContent);
            listItem.appendChild(fileName);

            return listItem;
        }

        submitButton.addEventListener('click', () => {
            if (files.length > 0) {
                const fileListArray = new DataTransfer();
                for (const file of files) {
                    fileListArray.items.add(file);
                }
                fileInput.files = fileListArray.files;
            }

            console.log('Wartość inputu "file" ustawiona na wcześniej wybrane pliki.');
        });

        const tx = document.getElementsByTagName("textarea");
        for (let i = 0; i < tx.length; i++) {
            tx[i].setAttribute("style", "height:" + (tx[i].scrollHeight) + "px;overflow-y:hidden;");
            tx[i].addEventListener("input", OnInput, false);
        }

        function OnInput() {
            this.style.height = 0;
            this.style.height = (this.scrollHeight) + "px";
        }
    </script>
</x-admin-layout>
