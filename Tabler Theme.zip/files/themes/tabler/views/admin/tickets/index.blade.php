<x-admin-layout title="{{ __('Tickets') }}">
<div class="page-wrapper">
	<div class="page-header d-print-none">
		<div class="container-xl">
						<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Tickets') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
				@php $unread = App\Models\Ticket::where('status', 'open')->count(); @endphp
					<li class="nav-item">
						<a href="#opentickets" class="nav-link active" data-bs-toggle="tab">{{ __('Open Tickets') }} &nbsp; @if ($unread > 0)<span class="badge bg-red text-white ms-auto">{{ $unread }}</span>@endif</a></a>
					</li>
					<li class="nav-item">
						<a href="#closedtickets" class="nav-link" data-bs-toggle="tab">Closed tickets</a>
					</li>
				</ul>
			</div>
			<div class="card-header">
				<h3 class="card-title">{{ __('Tickets') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-primary" href="{{ route('admin.tickets.create') }}">
					{{ __('Create') }}
					</a>
				</div>
			</div>
			<div class="tab-content">
				<div class="tab-pane active show" id="opentickets">
					@if ($tickets->count())
					<div class="table-responsive">
						<table class="table table-vcenter table-mobile-md card-table">	 
							<thead>
								<tr>
									<th>{{ __('Client') }}</th>
									<th>{{ __('Subject') }}</th>
									<th>{{ __('Priority') }}</th>
									<th>{{ __('Status') }}</th>
									<th>{{ __('Created at') }}</th>
									<th class="w-1">Reply</th>
								</tr>
							</thead>
							<tbody>
								@foreach ($tickets as $service)
									<tr>
										<td>{{ $service->user->name }}</td>
										<td>{{ Str::limit($service->title, 36) }}</td>
										<td>
											@if ($service->priority == 'low')
											<span class="badge bg-green text-white">{{ __('Low') }}</span>
											@elseif($service->priority == 'medium')
											<span class="badge bg-yellow text-white">{{ __('medium') }}</span>
											@elseif($service->priority == 'high')
											<span class="badge bg-red text-white">{{ __('High') }}</span>
											@endif
										</td>
										<td>
											<span class="badge @if ($service->status == 'open') bg-red @else bg-green @endif text-white">{{ $service->status }}</span>
										</td>
										<td>{{ $service->created_at }}</td>
										<td>
											<a href="{{ route('admin.tickets.show', $service->id) }}" class="btn btn-outline-primary">{{ __('View') }}</a>
										</td>
									</tr>
								@endforeach
							</tbody>
						</table>
					</div>
					@else
						<h3 class="text-center text-green my-4"> No Open Tickets </h3>
					@endif
				</div>
			 
				<div class="tab-pane" id="closedtickets">
					@if ($closed->count())
					<div class="table-responsive">
						<table class="table table-vcenter table-mobile-md card-table">	 
							<thead>
								<tr>
									<th>{{ __('Client') }}</th>
									<th>{{ __('Subject') }}</th>
									<th>{{ __('Priority') }}</th>
									<th>{{ __('Status') }}</th>
									<th>{{ __('Created at') }}</th>
									<th class="w-1">Reply</th>
								</tr>
							</thead>
							<tbody>
								@foreach ($closed as $service)
									<tr>
										<td>{{ $service->user->name }}</td>
										<td>{{ Str::limit($service->title, 36) }}</td>
										<td>
											@if ($service->priority == 'low')
											<span class="badge bg-green text-white">{{ __('Low') }}</span>
											@elseif($service->priority == 'medium')
											<span class="badge bg-yellow text-white">{{ __('medium') }}</span>
											@elseif($service->priority == 'high')
											<span class="badge bg-red text-white">{{ __('High') }}</span>
											@endif
										</td>
										<td>
											<span class="badge @if ($service->status == 'open') bg-red @else bg-green @endif text-white">{{ $service->status }}</span>
										</td>
										<td>{{ $service->created_at }}</td>
										<td>
											<a href="{{ route('admin.tickets.show', $service->id) }}" class="btn btn-outline-primary">{{ __('View') }}</a>
										</td>
									</tr>
								@endforeach
							</tbody>
						</table>
					</div>
					@else
						<h3 class="text-center text-green my-4"> No Closed Tickets </h3>
					@endif
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
 
</x-admin-layout>
