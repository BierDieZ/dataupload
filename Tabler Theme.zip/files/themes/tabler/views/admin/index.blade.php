<x-admin-layout title="{{ __('General') }}">
	<div class="row">
		<div class="col-sm-12 mb-2">
			<div class="page-pretitle">
				{{ __('Dashboard') }}
			</div>
			<h2 class="page-title">
				{{ __('An overview of everything') }}
			</h2>
		</div>
		<div class="row row-cards">
			<div class="col-sm-12">
				<div class="card">
					<div class="card-body">
						<div class="d-flex">
							<h3 class="card-title"> </h3>
							<!--<div class="ms-auto">
								<div class="dropdown">
									<a class="dropdown-toggle text-secondary" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
									<div class="dropdown-menu dropdown-menu-end">
										<a class="dropdown-item active" href="#">Last 7 days</a>
										<a class="dropdown-item" href="#">Last 30 days</a>
										<a class="dropdown-item" href="#">Last 3 months</a>
									</div>
								</div>
							</div>!-->
						</div>
						<div class="row">
							<div class="col">
								<div id="chart-active-users-2"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

    <script>
      // @formatter:off
      document.addEventListener("DOMContentLoaded", function () {
      	window.ApexCharts && (new ApexCharts(document.getElementById('chart-active-users-2'), {
      		chart: {
      			type: "line",
      			fontFamily: 'inherit',
      			height: 288,
      			parentHeightOffset: 0,
      			toolbar: {
      				show: false,
      			},
      			animations: {
      				enabled: false
      			},
      		},
      		fill: {
      			opacity: 1,
      		},
      		stroke: {
      			width: 4,
      			lineCap: "round",
      			curve: "smooth",
      		},
      		series: [{
      			name: "{{ __('Orders') }}",
      			data: 	[
						@for ($i = 29; $i >= 0; $i--) 
							{{ isset($orderCounts[$i]) ? $orderCounts[$i] : 0 }},
						@endfor
					]
      		},{
      			name: "{{ __('Users') }}",
      			data: 	[
						@for ($i = 29; $i >= 0; $i--)
							{{ isset($userCounts[$i]) ? $userCounts[$i] : 0 }},
                        @endfor
					]
      		},{
      			name: "{{ __('Revenue') }}",
      			data: 	[
						@for ($i = 29; $i >= 0; $i--)
							{{ isset($invoiceCounts[$i]) ? $invoiceCounts[$i] : 0 }},
						@endfor
					]
      		}],
      		tooltip: {
      			theme: 'light'
      		},
      		grid: {
      			padding: {
      				top: -20,
      				right: 0,
      				left: -4,
      				bottom: -4
      			},
      			strokeDashArray: 2,
      		},
      		xaxis: {
      			labels: {
      				padding: 0,
      			},
      			tooltip: {
      				enabled: false
      			},
      			type: 'datetime',
      		},
      		yaxis: {
      			labels: {
      				padding: 4
      			},
      		},
      		labels: [
      			@for ($i = 29; $i >= 0; $i--)
					'{{ date('Y-m-d', strtotime('- ' . $i . 'day')) }}',
                @endfor
      		],
      		colors: [tabler.getColor("red"), tabler.getColor("yellow"), tabler.getColor("green")],
      		legend: {
      			show: true,
      			position: 'bottom',
      			offsetY: 12,
      			markers: {
      				width: 10,
      				height: 10,
      				radius: 100,
      			},
      			itemMargin: {
      				horizontal: 8,
      				vertical: 8
      			},
      			},
      	})).render();
      });
      // @formatter:on
    </script>
</x-admin-layout>
