<x-admin-layout title="{{ __('Editing template') }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Editing template') }}
		</div>
		<h2 class="page-title">
			 {{ class_basename($template->mailable) }}
		</h2>
	</div>
	<div class="col-sm-12">
		<div class="card">
			<form action="{{ route('admin.email.template.update', $template->id) }}" method="POST">
				@csrf
				<div class="card-body">
					<div class="row">
						<div class="col-sm-12">
							<x-input type="text" name="subject" class="w-full mt-4" value="{{ $template->subject }}" label="Subject" />
						</div>
						<div class="col-sm-12">
							<x-input type="textarea" id="editor" class="w-full mt-4" rows="20" label="HTML Template (Markdown supported)" name="html_template">{{ $template->html_template }}</x-input>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button class="btn btn-outline-green ms-auto">{{ __('Save') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>
</x-admin-layout>
