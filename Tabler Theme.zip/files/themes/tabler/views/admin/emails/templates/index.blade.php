<x-admin-layout title="{{ __('Email Templates') }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Emails Templates') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
					<li class="nav-item">
						<a href="{{ route('admin.email') }}" class="nav-link">{{ __('Email Logs') }}</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('admin.email.templates') }}" class="nav-link active">{{ __('Email Templates') }}</a>
					</li>
				</ul>
			</div>	
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable">
					<thead>
						<tr>
							<th>{{ __('Mailable') }}</th>
							<th class="w-1">{{ __('Action') }}</th>
						</tr>
					</thead>
					<tbody>
					 @foreach ($templates as $template)
						<tr>
							<td data-label="{{ __('Mailable') }}"> {{ class_basename($template->mailable) }}</td>
							<td data-label="{{ __('Action') }}">
								<a href="{{ route('admin.email.template', $template->id) }}">
									<button class="btn btn-outline-primary"> </i> {{ __('Edit') }}</button>
								</a>
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
 
</x-admin-layout>
