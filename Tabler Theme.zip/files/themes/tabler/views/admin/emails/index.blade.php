<x-admin-layout title=" {{ __('Emails') }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Emails') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
					<li class="nav-item">
						<a href="{{ route('admin.email') }}" class="nav-link active">{{ __('Email Logs') }}</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('admin.email.templates') }}" class="nav-link">{{ __('Email Templates') }}</a>
					</li>
					<li class="nav-item ms-auto">
						<x-pagination :paginator="$emails" />
                    </li>
				</ul>
			</div>	
			<div class="card-body">
				 
                <div class="accordion" id="accordion-example">
				@foreach ($emails as $email)
					<div class="accordion-item">
						<h2 class="accordion-header" id="heading-1">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#email-body-{{ $email->id }}" aria-expanded="false">
								{{ $email->subject }} - 
								{{ $email->created_at }} - 
								{{ __('to') }}: {{ $email->user->name }} 
								@if ($email->success) 
									<span class="badge bg-green text-white"> {{ __('Sent') }}</span>
								@else
									<span class="badge bg-green text-white"> {{ __('Failed') }}</span>
								@endif
							</button>
						</h2>
						<div id="email-body-{{ $email->id }}" class="accordion-collapse collapse" data-bs-parent="#accordion-example">
							<div class="accordion-body pt-0">
							@if (!$email->success)
								<div class="bg-red e"role="alert">
									@php
										$error = $email->errors;
										$error = explode("\n", $error);
									@endphp
									@foreach ($error as $key => $value)
										@if ($key > 0)
											<span class="block sm:inline">{{ $value }}</span>
										@else
											<strong class="font-bold">{{ $value }}</strong>
										@endif
										<br />
									@endforeach
								</div>
							@else
								<iframe srcdoc="{{ $email->body }}" frameborder="0"
									class="w-full transition-all ease-in-out rounded-md" style="min-height: 500px;">
								</iframe>
							@endif
							</div>
						</div>
					</div>
				@endforeach
				</div>
			</div>
		</div>
	</div>
</div>
</x-admin-layout>
