<x-admin-layout clients title="{{ __('Invoice') }}"> 
    <x-success class="mt-4" />
	<div class="row">
		<div class="col-sm-12 mb-2">
			<div class="page-pretitle">
				{{ __('Invoices') }}
			</div>
			<h2 class="page-title">
				{{ __('Here you can see all invoices.') }}
			</h2>
		</div>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Invoice') }} #{{ $invoice->id }}</h3>
				<div class="col-auto ms-auto d-print-none">
				@if($invoice->status === 'pending')
				<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#{{ $invoice->id }}">
				 {{ __('Mark as paid') }}
				</button>
				@endif
 					 
				</div>
			</div>
         
   

    @php
        $invoice->paid_with = $invoice->paid_with=== "unknown"? __('Not Paid')  : $invoice->paid_with;
    @endphp
 
    <div class="card-body">
        <div class="row">
            
            <div class="col-md-6 col-sm-12">
				<div class="row">
					<div class="col-sm-12">
						<x-input disabled type="text" name="client" :label="__('Client')" name="title" value="{{ $invoice->user->name }}" class="mt-2 lg:mt-0" icon="ri-user-line" />
					</div>
                    <div class="col-md-6 col-sm-12">
                        <x-input disabled type="text" name="total" :label="__('Total')" icon="ri-money-dollar-circle-line" class="w-full mt-2 lg:mt-0" value="{{ ucfirst($total) }} {{ config('settings::currency_sign') }}"/>
                    </div>
					<div class="col-md-6 col-sm-12">					
						<x-input disabled type="text" name="status" :label="__('Status')" icon="ri-calendar-line" class="w-full mt-2 lg:mt-0" value="{{ ucfirst($invoice->status) }}"/>
                    </div>
				</div>
            </div>
			<div class="col-md-6 col-sm-12">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<x-input disabled type="text" name="paid_with" :label="__('Payment Method')" icon="ri-money-dollar-circle-line" class="w-full mt-2 lg:mt-0" value="{{ ucfirst($invoice->paid_with) }}"/>
					</div>
					<div class="col-md-6 col-sm-12">
						<x-input disabled type="text" name="reference" :label="__('Reference')" icon="ri-money-dollar-circle-line" class="w-full mt-2 lg:mt-0" value="{{ $invoice->reference??__('No Reference') }}"/>
					</div>
					<div class="col-md-4 col-sm-12">
						<x-input disabled type="text" name="created_at" :label="__('Created At')" icon="ri-calendar-line" class="w-full mt-2 lg:mt-0" value="{{ $invoice->created_at }}"/>
					</div>
					<div class="col-md-4 col-sm-12">					
						<x-input disabled type="text" name="updated_at" :label="__('Updated At')" icon="ri-calendar-line" class="w-full mt-2 lg:mt-0" value="{{ $invoice->updated_at }}"/>
					</div>
					<div class="col-md-4 col-sm-12">
						<x-input disabled type="text" name="paid_at" :label="__('Paid At')" icon="ri-calendar-line" class="w-full mt-2 lg:mt-0" value="{{ $invoice->paid_at?? __('Not Paid') }}"/>
					</div>
				</div>
			</div>
        </div>
    </div>
	<div class="hr-text mb-4">
		{{ __('Products') }}
	</div>
    <div class="table-responsive">
		<table class="table table-vcenter table-mobile-md card-table">
            <thead>
                <tr>
                    <th>{{ __('ID') }}</th>
                    <th>{{ __('Name') }}</th>
                    <th>{{ __('Price') }}</th>
                    <th>{{ __('Discount') }} </th>
                    <th class="w-1">{{ __('Assigned Order') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($products as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->name }}</td>
                        <td><x-money :amount="$item->price" /></td>
                        <td ><x-money :amount="$item->discount" /></td>
                        <td>
                            @if($item->order)
                                <a href="{{ route('admin.orders.show', $item->order->id) }}"
                                    class="text-underline underline-offset-2">
                                    {{ $item->order->id }}
                                </a>
                            @else
                                {{ __('Not assigned') }}
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    </div>
    </div>
   
<form action="{{ route('admin.invoices.paid', $invoice->id) }}" method="POST">
@csrf
	<x-modal :id="$invoice->id" title="{{__('Marking invoice')}} {{ $invoice->id }} {{__('as paid')}}">
	<x-input type="select" name="paid_with" label="Payment Method">
		@foreach (App\Models\Extension::where('type', 'gateway')->where('enabled', true)->get() as $extension)
		<option value="{{ $extension->name }}">{{ $extension->name }}</option>
		@endforeach
		<option value="manual">{{ __('Manual') }}</option>
	</x-input>
	<x-input type="text" name="paid_reference" label="{{__('Reference')}}" />
		<x-slot name="footer">
			<button class="btn btn-outline-green ms-auto"  type="submit">{{ __('Mark as paid') }}</button>
		</x-slot>
	</x-modal>
</form>
</x-admin-layout>
