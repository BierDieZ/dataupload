<x-admin-layout title="{{ __('Create Invoice') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Create Invoice') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
    <div class="col-12">
		<div class="card">
			<div class="card-header">							 
				<h3 class="card-title">{{ __('Create Invoice') }}</h3>
				<div class="ms-auto">
					<button type="button" id="add-item" class="btn btn-outline-info ms-auto">{{ __('Add Item') }}</button>
				</div>
			</div> 
		<form action="{{ route('admin.invoices.store') }}" method="POST">
        @csrf
		<div class="card-body">
			<div class="row">
				<div class="col-sm-12">
					<div class="row">
						<div class="col-md-4 col-sm-12">
							<x-input type="select" name="user_id" id="user_id" label=" {{ __('Client') }}">
								@foreach ($users as $user)
									 <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->email }})</option>
								@endforeach
							</x-input> 
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-12" id="items">
							<div class="row">
								<div class="col-md-10 col-sm-12 mb-2">
									<x-input type="text" label="{{ __('Items') }}" name="item_name[]" id="item_name" required placeholder="{{ __('Item Name') }}" value="{{ old('item_name') }}" />
								</div>
								<div class="col-md-2 col-sm-12 mb-2">
									<x-input label="{{ __('Item Price') }}"  type="number" name="item_price[]" id="item_price" required placeholder="{{ __('Item Price') }}" step="0.01" min="0" value="{{ old('item_price') }}" />
								</div>
							</div>
						</div>
               
						<script>
							document.getElementById('add-item').addEventListener('click', function() {
								var item = document.createElement('div');
								item.classList.add('row');
								item.innerHTML = `
								<div class="col-md-9 col-sm-12">
								   <x-input type="text" label="{{ __('Items') }}" name="item_name[]" id="item_name" required placeholder="{{ __('Item Name') }}" value="{{ old('item_name') }}" />
								</div>
								<div class="col-md-2 col-sm-12">
									<x-input label="{{ __('Item Price') }}"  type="number" name="item_price[]" id="item_price" required placeholder="{{ __('Item Price') }}" step="0.01" min="0" value="{{ old('item_price') }}" />
								</div>
								<div class="col-sm-1 mb-2 mt-2">
									<button id="removeRow" type="button" class="btn btn-outline-danger ms-auto w-100">{{ __('Delete') }}</button>
								</div>
								`;
								document.getElementById('items').appendChild(item);
								 
							});
							$(document).on('click', '#removeRow', function () {
								$(this).closest('.row').remove();
							});
						</script>
					</div>
				</div>
            </div>
        </div>
        <div class="card-footer text-end">
            <button type="submit" class="btn btn-outline-green">{{ __('Create Invoice') }}</button>
        </div>
    </form>
</x-admin-layout>
