<x-admin-layout title="{{ __('Create Product') }}">
<x-success class="mt-4" />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Products') }}
		</div>
		<h2 class="page-title">
			 {{ __('Create Product') }}
		</h2>
	</div>
    <div class="col-12">
		<div class="card">
			<div class="card-header">							 
				<h3 class="card-title">{{ __('Create Product') }}</h3>
			</div>
			<form method="POST" action="{{ route('admin.products.store') }}" enctype="multipart/form-data">
			@csrf
				<div class="card-body">
					<div class="row mb-4">
						<div class="col-md-6 col-sm-12">
							<label for="image">{{ __('Image') }}</label>
							<input id="image" class="form-control" type="file" name="image" required />					 
							<label class="form-check mt-2">
								<input type="checkbox" name="no_image" id="no_image" value="1" {{ old('no_image') ? 'checked' : '' }} class="form-check-input">
								<span class="form-check-label">
								 {{ __('Image') }} {{ __('Disabled') }}?
								</span>
								 <script>
									document.getElementById('no_image').addEventListener('change', function() {
										document.getElementById('image').disabled = this.checked;
									});
								</script>
							</label>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<x-input name="name" id="name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ old('name') }}" required autofocus />
							
						</div>
						<div class="col-md-4 col-sm-12">
							<x-input type="select" id="category" name="category_id" label="{{ __('Category') }}" required>
								@if ($categories->count())
									@foreach ($categories as $category)
										<option value="{{ $category->id }}">{{ $category->name }}</option>
									@endforeach
								@else
									<option value="">No categories found</option>
								@endif
							</x-input>
						</div>
						<div class="col-md-2 col-sm-12">
							<x-input name="price" id="price" label="{{ __('Price') }}" type="number" placeholder="{{ __('Price') }}" value="{{ old('price') }}" required  min="0" step="any" required min="0" />
						</div>
						<div class="col-sm-12">
							<textarea name="description" id="description" rows="5" class="form-control" placeholder="{{ __('Description') }}" required>{{ old('description') }}</textarea>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<div class="d-flex">
						<a href="{{ route('admin.categories.create') }}" class="btn btn-link">Create Category</a>
						<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Save') }}</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</x-admin-layout>
