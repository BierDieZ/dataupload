<x-admin-layout title="{{ __('Pricing') }} {{ $product->name }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Pricing') }}
		</div>
		<h2 class="page-title">
			  {{ $product->name }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs">
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.edit')) active @else  @endif" href="{{ route('admin.products.edit', $product->id) }}"  >{{ __('Details') }}</a> 
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.pricing')) active @else  @endif" href="{{ route('admin.products.pricing', $product->id) }}" >{{ __('Pricing') }}</a>
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.extension')) active @else  @endif" href="{{ route('admin.products.extension', $product->id) }}" >{{ __('Extension') }}</a>
					</li>
				</ul>
			</div>	
			<form action="{{ route('admin.products.pricing.update', $product->id) }}" method="POST">
				@csrf
			   <div class="card-body">
					<div class="row mb-4">
						<div class="col-md-4 col-sm-12">
							<div class="col-sm-12">
								<x-input type="select" id="pricing" name="pricing" label=" {{ __('Pricing') }}" required>
									<option value="free" @if ($pricing->type == 'free') selected @endif>
										{{ __('Free') }}
									</option>
									<option value="one-time" @if ($pricing->type == 'one-time') selected @endif>
										{{ __('One-time') }}
									</option>
									<option value="recurring" @if ($pricing->type == 'recurring') selected @endif>
										{{ __('Recurring') }}
									</option>
								</x-input>
							</div>
						</div>
						<div class="col-md-8 col-sm-12">
							<div class="row">
								@if ($pricing->type == 'one-time')
								<div class="@if ($pricing->type == 'one-time') col-lg-4 @endif col-md-6 col-sm-12">
									<x-input name="monthly" id="price" label="{{ __('Price') }}" type="text" value="{{ $pricing->monthly }}" required />
								</div>
							   
								@elseif($pricing->type == 'recurring')
								<div class="col-sm-6">
									<x-input name="monthly" id="monthly" label="{{ __('Monthly') }}" type="text" value="{{ $pricing->monthly }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="monthly_setup" id="monthly_setup_fee" label="{{ __('Monthly Setup Fee') }}" type="text" value="{{ $pricing->monthly_setup }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="quarterly" id="quarterly" label="{{ __('Quarterly') }}" type="text" value="{{ $pricing->quarterly }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="quarterly_setup" id="quarterly_setup_fee" label="{{ __('Quarterly Setup Fee') }}" type="text" value="{{ $pricing->quarterly_setup }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="semi_annually" id="semi_annually" label="{{ __('Semiannually') }}" type="text" value="{{ $pricing->semi_annually }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="semi_annually_setup" id="semi_annually_setup_fee" label="{{ __('Semiannually Setup Fee') }}" type="text" value="{{ $pricing->semi_annually_setup }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="annually" id="annually" label="{{ __('Annually') }}" type="text" value="{{ $pricing->annually }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="annually_setup" id="annually_setup_fee" label="{{ __('Annually Setup Fee') }}" type="text" value="{{ $pricing->annually_setup }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="biennially" id="biennially" label="{{ __('Biennially') }}" type="text" value="{{ $pricing->biennially }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="biennially_setup" id="biennially_setup_fee" label="{{ __('Biennially Setup Fee') }}" type="text" value="{{ $pricing->biennially_setup }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="triennially" id="triennially" label="{{ __('Triennially') }}" type="text" value="{{ $pricing->triennially }}" />
								</div>
								<div class="col-sm-6">
									<x-input name="triennially_setup" id="triennially_setup_fee" label="{{ __('Triennially Setup Fee') }}" type="text" value="{{ $pricing->triennially_setup }}" />
								</div>
								 
								 
									 
								 
								@endif
								 
								<div class="@if ($pricing->type == 'free') col-lg-2 @endif @if ($pricing->type == 'recurring') col-md-6 @endif  col-sm-12">
									<x-input name="limit" id="price" label="{{ __('Limit per client') }}" type="number" min="0" value="{{ $product->limit }}" />
								</div>
								<div class="@if ($pricing->type == 'free') col-lg-10 @endif @if ($pricing->type == 'recurring') col-md-6 @endif col-sm-12">
									<x-input type="select" id="allow_quantity" name="allow_quantity" label="{{ __('Allow multiple quantities') }}">
										<option value="0" @if ($product->allow_quantity == 0) selected @endif>
												{{ __('No') }}
											</option>
											<option value="1" @if ($product->allow_quantity == 1) selected @endif>
												{{ __('Yes, Multiple Services (Each represents a own individual service instance)') }}
											</option>
											<option value="2" @if ($product->allow_quantity == 2) selected @endif>
												{{ __('Yes, Single Service (One service instance with multiple quantity)') }}
											</option>
									</x-input>
								</div>
								 
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green"> {{ __('Save') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>

</x-admin-layout>
