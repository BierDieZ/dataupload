<x-admin-layout title="{{ __('Editing') }} {{ $product->name }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Editing') }}
		</div>
		<h2 class="page-title">
			  {{ $product->name }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs">
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.edit')) active @else  @endif" href="{{ route('admin.products.edit', $product->id) }}"  >{{ __('Details') }}</a> 
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.pricing')) active @else  @endif" href="{{ route('admin.products.pricing', $product->id) }}" >{{ __('Pricing') }}</a>
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.extension')) active @else  @endif" href="{{ route('admin.products.extension', $product->id) }}" >{{ __('Extension') }}</a>
					</li>
					<li class="nav-item ms-auto active">
						<div class="dropdown">
						 
							<a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-settings" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z"></path>
								   <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"></path>
								</svg>
							</a>
							<div class="dropdown-menu dropdown-menu-end">
								<a href="{{ route('admin.products.extension.export', $product->id) }}" class="dropdown-item" role="menuitem" tabindex="-1" id="menu-item-0"> {{ __('Export') }}</a>
								<button class="dropdown-item" role="menuitem" tabindex="-1" id="menu-item-0"onclick="document.getElementById('importFile').click();">{{ __('Import') }}</button>
								<form method="POST" action="{{ route('admin.products.duplicate', $product->id) }}" id="duplicate">
									@csrf
									<input type="file" name="json" class="d-none" onchange="this.form.submit()"id="importFile">
								</form>
							</div>
						</div>
					</li>
				</ul>
			</div>	
  
			<form method="POST" action="{{ route('admin.products.extension.update', $product->id) }}"enctype="multipart/form-data" id="formu">
				@csrf
				<div class="card-body">
					<div class="row mb-4">
						<div class="col-md-10 col-sm-12">
							<x-input type="select" id="server" name="extension_id" label="{{ __('Server') }}" required>
								@if ($extensions->count())
									<option value="" disabled selected>None</option>
									@foreach ($extensions as $server)
										@if ($server->id == $product->extension_id)
											<option value="{{ $server->id }}" selected>{{ $server->name }}
											</option>
										@else
											<option value="{{ $server->id }}">{{ $server->name }}</option>
										@endif
									@endforeach
								@else
									<option value="">{{ __('No servers found') }}</option>
								@endif
							</x-input>
						</div>
						<div class="col-md-2 col-sm-12">
							<button type="button" class="btn btn-outline-danger w-100 mt-2" onclick="document.getElementById('formu').submit();"  id="submitt"> {{ __('Update server') }} </button>
						</div>
					</div>
				@isset($extension)
					<div class="row">
						@foreach ($extension->productConfig as $setting)
							@if (!isset($setting->required))
								@php
									$setting->required = false;
								@endphp
							@endif
							@if ($setting->type == 'title')
								{{ $setting->friendlyName }} {{ $setting->description }}
									 
								@continue
							@endif
							<div class="col-md-6 col-sm-12">
								<x-config-item :config="$setting" />
							</div>
						@endforeach
					</div>
				@endisset
				</div>
				<div class="card-footer text-end" type="submit">
					<button class="btn btn-outline-green">
						{{ __('Update') }}
					</button>
				</div>
			</form>
		</div>
    </div>
 </div>
</x-admin-layout>
