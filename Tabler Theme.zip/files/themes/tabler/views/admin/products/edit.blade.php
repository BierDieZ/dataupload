<x-admin-layout title="{{ __('Update product') }} {{ $product->name }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Update product') }}
		</div>
		<h2 class="page-title">
			  {{ $product->name }}
		</h2>
	</div>
		<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs">
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.edit')) active @else  @endif" href="{{ route('admin.products.edit', $product->id) }}"  >{{ __('Details') }}</a> 
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.pricing')) active @else  @endif" href="{{ route('admin.products.pricing', $product->id) }}" >{{ __('Pricing') }}</a>
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.products.extension')) active @else  @endif" href="{{ route('admin.products.extension', $product->id) }}" >{{ __('Extension') }}</a>
					</li>
					<li class="nav-item ms-auto active">
						<div class="dropdown">
							<a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-settings" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z"></path>
								   <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"></path>
								</svg>
							</a>
							<div class="dropdown-menu dropdown-menu-end">
								 
								<button class="dropdown-item text-danger" role="menuitem" tabindex="-1" id="menu-item-0" onclick="document.getElementById('duplicate').submit()"> {{ __('Duplicate') }}</button>
								<button class="dropdown-item text-danger" role="menuitem" tabindex="-1" id="menu-item-0" onclick="document.getElementById('delete').submit()"> {{ __('Delete') }}</button>
								<form method="POST" action="{{ route('admin.products.destroy', $product->id) }}" id="delete">
									@csrf
									@method('DELETE')
								</form>
								<form method="POST" action="{{ route('admin.products.duplicate', $product->id) }}" id="duplicate">
									@csrf
								</form>
							</div>
						</div>
					</li>
				</ul>
			</div>	 
 
        <form method="POST" action="{{ route('admin.products.update', $product->id) }}" enctype="multipart/form-data">
            @csrf
			<div class="card-body">
				<div class="row mb-4">
					<div class="col-md-6 col-sm-12">
						<label for="image">{{ __('Image') }}</label>
						 @if ($product->image == 'null')
							<input id="image" class="form-control" type="file" name="image" disabled required />
							<x-input name="no_image" id="no_image" value="1"  label="{{ __('Image') }} {{ __('Disabled') }} ?" type="checkbox" checked required />
						@else
							<input id="image" class="form-control" type="file" name="image" required />
							<x-input name="no_image" id="no_image" value="1"  label="{{ __('Image') }} {{ __('Disabled') }} ?" type="checkbox" required />
						@endif
					</div>
					<div class="col-md-6 col-sm-12">
						<img src="{{ $product->image }}" alt="{{ $product->name }}" class="" id="prodctimg" onerror="removeElement(this)">
						  <script>
					function removeElement(element) {
						element.onerror = "";
					}
					document.getElementById('no_image').addEventListener('change', function() {
						document.getElementById('image').disabled = this.checked;
						document.getElementById('prodctimg').classList.toggle('d-none');
					});
					// Listen for file uploads then display the image
					document.getElementById('image').addEventListener('change', function() {
						if (this.files && this.files[0]) {
							var img = document.getElementById('prodctimg');
							img.classList.remove('d-none');
							img.src = URL.createObjectURL(this.files[0]);
						}
					});
					if (document.getElementById('no_image').checked) {
						document.getElementById('image').disabled = true;
						document.getElementById('prodctimg').classList.add('d-none');
					}
				</script>
					</div>
					 
				</div>
				<div class="row mb-2">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-md-8 col-sm-12">
								<x-input name="name" id="name" label="{{ __('Name') }}" type="text" value="{{ $product->name }} " required />
							</div>
							<div class="col-md-4 col-sm-12">
								<x-input type="select" id="category" name="category_id" label="{{ __('Category') }}" required>
									 @if ($categories->count())
										@foreach ($categories as $category)
											@if ($category->id == $product->category_id)
												<option value="{{ $category->id }}" selected>{{ $category->name }}
												</option>
											@else
												<option value="{{ $category->id }}">{{ $category->name }}</option>
											@endif
										@endforeach
									@else
										<option value="">No categories found</option>
									@endif
								</x-input>
							</div>
							<div class="col-md-2 col-sm-12">
						 
								<label class="form-check form-check-inline mt-2">
									<input type="checkbox" name="stock_enabled" id="stock_enabled" value="1" onchange="if(this.checked) { document.getElementById('stock').classList.remove('d-none');  } else { document.getElementById('stock').classList.add('d-none'); }" class="form-check-input" @if ($product->stock_enabled) checked @endif />
									<label for="stock_enabled">{{ __('Enable Stock') }}</label>
								</label>
								<div class="@if (!$product->stock_enabled) d-none @endif" id="stock">
									<x-input name="stock" id="stocki" label="{{ __('Stock') }}" type="number" min="0" value="{{ $product->stock }}" required />
								</div>
							</div>
							 
							<div class="col-sm-12">
								<textarea name="description" id="description" rows="5" class="form-control" placeholder="{{ __('Description') }}" required>{{ $product->description }}</textarea>
							</div>
						</div>
					</div>
				</div>
			</div>
        
				 
            
           <div class="card-footer text-end">
					<div class="d-flex">
						<a href="{{ route('admin.categories.create') }}" class="btn btn-link">Create Category</a>
						<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Save') }}</button>
					</div>
				</div>
        </form>
    </div>
    </div>
    </div>
</x-admin-layout>
