<x-admin-layout title="{{ __('Products') }}" clients>
    <x-success class="mt-4" />
	<div class="row">
		<div class="col-sm-12 mb-2">
			<div class="page-pretitle">
				{{ __('Products') }}
			</div>
			<h2 class="page-title">
				{{ __('Here you can see all products.') }}
			</h2>
		</div>
 
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Products') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-green" href="{{ route('admin.products.create') }}">{{ __('Create') }}</a>
				</div>
			</div>
		<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>

		@if ($categories->isEmpty())
			<div class="text-center p-4">
				<p>{{ __('No products found') }}</p>
				<br>
				<a class="btn btn-primary" href="{{ route('admin.categories.create') }}">{{ __('Create category') }}</a>
			</div>
		@else
			<div class="card-body" id="categories">
				<div class="row row-cards">
				@foreach ($categories as $category)
					<div class="col-sm-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title"><b>{{__('Category')}}:</b> {{ $category->name }}<br><small>{{__('Category Description')}}:</b> {{ $category->description }}</small></h3>
							</div>
							<div class="table-responsive">
								<table class="table card-table table-vcenter text-nowrap datatable"> 
									<thead class="text-left">
										<tr>
											<th>{{ __('ID') }}</th>
											<th>{{ __('Name') }}</th>
											<th>{{ __('Description') }}</th>
											<th>{{ __('Actions') }}</th>
											<th class="w-1">{{ __('Order') }}</th>
										</tr>
									</thead>
									<tbody id="{{ $category->id }}">
										@if ($category->products->isNotEmpty())
											@foreach ($category->products()->orderBy('order')->get() as $product)
												<tr id="{{ $product->id }}" data-id="{{ $product->id }}" data-order="{{ $product->order }}" data-category="{{ $category->id }}">
													<td>
														{{ $product->id }}</td>
													<td>
														{{ $product->name }}</td>
													<td>
														{{ Str::limit($product->description, 50) }}</td>
													<td>
														<a href="{{ route('admin.products.edit', $product->id) }}">
															<button class="btn button-primary">
																<i class="ri-pencil-line"></i> {{ __('Edit') }}
															</button>
														</a>
													</td>
													<td class="text-center draggable">
														 <svg xmlns="http://www.w3.org/2000/svg" class="draggable icon icon-tabler icon-tabler-arrows-move-vertical" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
														   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
														   <path d="M9 18l3 3l3 -3"></path>
														   <path d="M12 15v6"></path>
														   <path d="M15 6l-3 -3l-3 3"></path>
														   <path d="M12 3v6"></path>
														</svg>
													</td>
												</tr>
											@endforeach
										@else
											<tr>
												<td colspan="4" class="text-center">
													<p class="text-gray-500 px-3 rounded-md text-xl m-4">
														{{ __('No products found on category') }} {{ $category->name }}
													</p>
												</td>
											</tr>
										@endif
									</tbody>
								</table>
							</div>
						</div>
					 <script>
                        var el = document.getElementById('{{ $category->id }}');
                        var sortable = Sortable.create(el, {
                            animation: 150,
                            ghostClass: 'bg-gray-100',
                            chosenClass: 'bg-secondary-200',
                            handle: '.draggable',
                            onEnd: function(evt) {
                                var url = "{{ route('admin.products.reorder') }}";
                                // Get all items by data-category
                                var products = document.querySelectorAll('[data-category="' + evt.item.parentNode.id + '"]');
                                // Loop through all items and update order
                                products.forEach(function(product) {
                                    product.setAttribute('data-order', product.rowIndex);
                                });
                                // Products should be array with {id, order}
                                products = Array.from(products).map(function(product) {
                                    return {
                                        id: product.id,
                                        order: product.getAttribute('data-order')
                                    }
                                });

                                // Send data to server
                                var data = {
                                    products: products,
                                    category: evt.item.parentNode.id,
                                    _token: '{{ csrf_token() }}'
                                };
                                // Plain JavaScript
                                var request = new XMLHttpRequest();
                                request.open('POST', url, true);
                                request.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
                                request.send(JSON.stringify(data));

                                request.onload = function() {
                                    if (request.status >= 200 && request.status < 400) {
                                        // Success!
                                        var resp = request.responseText;
                                        console.log(resp);
                                    } else {
                                        // We reached our target server, but it returned an error
                                        console.log('error');
                                    }
                                };

                            },
                        });
                    </script>
				</div>
					 
				@endforeach
				</div>
			</div>
    @endif  
		</div>
	</div>
	 
</x-admin-layout>
