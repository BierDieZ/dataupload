<x-admin-layout title="{{ __('Categories') }}" clients>
    <x-success class="mt-4" />
	<div class="row">
		<div class="col-sm-12 mb-2">
			<div class="page-pretitle">
				{{ __('Categories') }}
			</div>
			<h2 class="page-title">
				{{ __('Here you can see all categories.') }}
			</h2>
		</div>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Categories') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-green" href="{{ route('admin.categories.store') }}">{{ __('Create') }}</a>
				</div>
			</div>
			@if (count($categories) > 0)
			<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable"> 
					<thead>
						<tr>
							<th>{{ __('ID') }}</th>
							<th>{{ __('Name') }}</th>
							<th>{{ __('Slug') }}</th>
							<th>{{ __('Actions') }}</th>
							<th class="w-1">{{ __('Order') }}</th>
						</tr>
					</thead>
					<tbody id="categories">
						@foreach ($categories as $category)
							<tr id="{{ $category->id }}" data-id="{{ $category->id }}" data-order="{{ $category->order }}">
								<td>{{ $category->id }}</td>
								<td>{{ $category->name }}</td>
								<td>
									<span class="badge bg-info">
										<a href="{{ route('products', $category->slug) }}" class="text-white" target="_blank">
											{{ route('products', $category->slug) }}
											<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-external-link" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
											   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
											   <path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6"></path>
											   <path d="M11 13l9 -9"></path>
											   <path d="M15 4h5v5"></path>
											</svg>
										</a>
									</span>
								</td>
								<td>
									<div class="btn-list"> 
										<a href="{{ route('admin.categories.edit', $category->id) }}" class="btn btn-primary">{{ __('Edit') }}</a>
										<form action="{{ route('admin.categories.delete', $category->id) }}" method="POST">
											@csrf
											@method('DELETE')
											<button type="submit" class="btn btn-danger">
												{{ __('Delete') }}
											</button>
										</form>
									</div> 
								</td>
								<td class="text-center draggable">
									<svg xmlns="http://www.w3.org/2000/svg" class="draggable icon icon-tabler icon-tabler-arrows-move-vertical" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
									   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
									   <path d="M9 18l3 3l3 -3"></path>
									   <path d="M12 15v6"></path>
									   <path d="M15 6l-3 -3l-3 3"></path>
									   <path d="M12 3v6"></path>
									</svg>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
			@else 			   
			<div class="text-center p-4">
				{{ __('No Categories Found.') }}
			</div>
			@endif
		</div>
	</div>
    <script>
        var el = document.getElementById('categories');
        var sortable = Sortable.create(el, {
            animation: 150,
            ghostClass: 'bg-gray-100',
            chosenClass: 'bg-secondary-200',
            handle: '.draggable',
            onEnd: function(evt) {
                var url = "{{ route('admin.categories.reorder') }}";
                var categories = document.querySelectorAll('#categories tr');
                categories.forEach(function(category) {
                    category.setAttribute('data-order', category.rowIndex);
                });
                categories = Array.from(categories).map(function(category) {
                    return {
                        id: category.getAttribute('data-id'),
                        order: category.getAttribute('data-order'),
                    };
                });

                var data = {
                    categories: categories,
                    _token: '{{ csrf_token() }}'
                };
                // Plain JavaScript
                var request = new XMLHttpRequest();
                request.open('POST', url, true);
                request.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
                request.send(JSON.stringify(data));

                request.onload = function() {
                    if (request.status >= 200 && request.status < 400) {
                        var resp = request.responseText;

                    } else {
                        console.log('error');
                    }
                };

            },
        });
    </script>

</x-admin-layout>
