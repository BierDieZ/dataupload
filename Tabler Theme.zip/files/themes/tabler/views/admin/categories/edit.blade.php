<x-admin-layout title="{{ __('Categories Edit') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Categories Edit') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
    <div class="col-12">
		<div class="card">
			<div class="card-header">							 
				<h3 class="card-title">{{ __('Categories Edit') }}</h3>
			</div>
		<form action="{{ route('admin.categories.update', $category->id) }}" method="POST">
		@csrf
			<div class="card-body">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<x-input name="name" id="name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ old('name', $category->name) }}" required autocomplete="name" autofocus />
					</div>
					<div class="col-md-6 col-sm-12">
						<x-input name="slug" id="slug" label="{{ __('Slug') }}" type="text" placeholder="{{ __('Slug') }}" value="{{ old('name', $category->slug) }}" required autocomplete="slug" autofocus />
						<span class="text-gray-500" id="slugd"></span>
					</div>
					<div class="col-sm-12">
						<x-input name="description" id="description" label="{{ __('Description') }}" type="text"  value="{{ old('name', $category->description) }}" required />
					</div>
				  
					<script>
						var slug = document.getElementById('slugd');
						var name = document.getElementById('name');
						slug.addEventListener('keyup', function() {
							document.getElementById('slugd').textContent = '/category/' + slug.value;
						});
						name.addEventListener('keyup', function() {
							slug.value = name.value.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
							document.getElementById('slugd').textContent = '/category/' + name.value;
						});
					</script>
				</div>
			</div>
			<div class="card-footer text-end">
				<button type="submit" class="btn btn-outline-green">{{ __('Update') }}</button>
			</div>
		</form>       
    </div>
</x-admin-layout>
