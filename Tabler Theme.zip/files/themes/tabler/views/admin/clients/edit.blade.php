<x-admin-layout title=" {{ __('Edit client') }}" Clients>
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Edit client') }}
		</div>
		<h2 class="page-title">
			{{ $user->first_name }} {{ $user->last_name }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs">
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.clients.edit')) active @else  @endif" href="{{ route('admin.clients.edit', $user->id) }}"  >{{ __('Client Details') }}</a> 
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.clients.products*')) active @else  @endif" href="{{ route('admin.clients.products', $user->id) }}" > {{ __('Products/Services') }}</a>
					</li>
					<li class="nav-item ms-auto active">
						<div class="dropdown">
							<a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-settings" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z"></path>
								   <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"></path>
								</svg>
							</a>
							<div class="dropdown-menu dropdown-menu-end">
								<a href="{{ route('admin.clients.loginasclient', $user->id) }}" class="dropdown-item">{{ __('Login as client') }}</a>
								<button class="dropdown-item text-danger text-decoration-none" data-bs-toggle="modal" data-bs-target="#modal_delete" style="background-color:transparent !important; border:0px !important;">{{__('Delete')}}</button>
								<form action="{{ route('admin.clients.delete', $user->id) }}" method="POST" id="delete">
								@csrf
								@method('DELETE')
								</form>
							</div>
							<div class="modal modal-blur fade" id="modal_delete" tabindex="-1" role="dialog" aria-hidden="true">
								<div class="modal-dialog modal-md modal-dialog-centered" role="document">
									<div class="modal-content">
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										<div class="modal-status  bg-danger"></div>
										<div class="modal-body text-center py-4">
											<svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10.24 3.957l-8.422 14.06a1.989 1.989 0 0 0 1.7 2.983h16.845a1.989 1.989 0 0 0 1.7 -2.983l-8.423 -14.06a1.989 1.989 0 0 0 -3.4 0z" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>
											<h3>{{ __('Delete Unrecoverable') }}</h3>
											<div class="text-secondary mb-4">{{ __('Are you sure you want to delete') }} <b> {{ $user->first_name }} </b> ?</div>
										</div>
										<div class="modal-footer">
											<div class="w-100">
												<div class="row">
												<div class="col">
												<a href="#" class="btn w-100" data-bs-dismiss="modal">
													{{ __('No') }}
												  </a></div>
												<div class="col">
												<button class="btn btn-outline-danger w-100" data-bs-dismiss="modal"  onclick="document.getElementById('delete').submit()">
													{{ __('Yes') }}
												  </button>
												  </div>
											  </div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>	 
			<form method="POST" action="{{ route('admin.clients.update', $user->id) }}">
				@csrf
				<div class="card-body">
					
					<div class="row mb-2">
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12 mb-3">
									<x-input name="companyname" id="companyname" label="{{ __('Company Name') }}" type="text" value="{{ $user->companyname }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="first_name" id="first_name" label="{{ __('First name') }}" type="text" value="{{ $user->first_name }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="last_name" id="last_name" label="{{ __('Last name') }}" type="text" value="{{ $user->last_name }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="email" id="email" label="{{ __('Email') }}" type="email" value="{{ $user->email }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="phone" id="phone" label="{{ __('Phone') }}" type="text" value="{{ $user->phone }}" />
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="address" id="address" label="{{ __('Address') }}" type="text" value="{{ $user->address }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="city" id="city" label="{{ __('City') }}" type="text" value="{{ $user->city }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="state" id="state" label="{{ __('State') }}" type="text" value="{{ $user->state }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="country" id="country" label="{{ __('Country') }}" type="text" value="{{ $user->country }}" />
								</div>
								<div class="col-md-6 col-sm-12  mb-3">
									<x-input name="zip" id="zip" label="{{ __('Zip') }}" type="text" value="{{ $user->zip }}" />
								</div>
							</div>
						 
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="row">	
								<div class="col-sm-12 mb-3">
									<x-input type="number" name="credits" step="0.01" id="credits" label="{{ __('Credits') }}" value="{{ $user->credits }}" />
								</div>
								 
								<div class="col-sm-12 mb-3">
									<x-input type="select" name="role" id="role" label="{{ __('Role(admin)') }}">
										@foreach ($roles as $role)
											<option value="{{ $role->id }}" @if ($user->role->id == $role->id) selected @endif>
												{{ $role->name }}
												@if ($role->id == 2)
													{{ __('(Default, Client)') }}
												@endif
												@if ($role->id == 1)
													{{ __('(Full Administrator)') }}
												@endif
											</option>
										@endforeach
									</x-input>
								</div>
							</div>
						</div>
					</div> 
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Update') }}</button>
				</div>
			</form>
		</div>
    </div>
</div>
    
</x-admin-layout>
