<x-admin-layout title="Products/Services of {{ $user->name }}" Clients>
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Edit client') }}
		</div>
		<h2 class="page-title">
			{{ $user->first_name }} {{ $user->last_name }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">							 
				<ul class="nav nav-tabs card-header-tabs">
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.clients.edit')) active @else  @endif" href="{{ route('admin.clients.edit', $user->id) }}"  >{{ __('Client Details') }}</a> 
					</li>
					<li class="nav-item">
						<a class="nav-link @if (request()->routeIs('admin.clients.products*')) active @else  @endif" href="{{ route('admin.clients.products', $user->id) }}" > {{ __('Products/Services') }}</a>
					</li>
				</ul>
			</div>
			<div class="card-body">
			   <script>
					function change() {
						window.location.href = "{{ route('admin.clients.products', $user->id) }}/" + document.getElementById('product')
							.value;
					}
				</script>
				<x-input type="select" name="product" id="product" label="{{ __('Select Product/Service') }}" onchange="change()">
					@foreach ($orderProducts as $product)
						<option value="{{ $product->id }}" @if ($product->id === $orderProduct->id) selected @endif>
							{{ $product->product->name }} ({{ $product->id }})
						</option>
					@endforeach
				</x-input>
			</div>
			<div class="card-body">
				<div class="row row-cards">
					<div class="col-md-6 col-sm-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Order ID: <a href="{{ route('admin.orders.show', $orderProduct->order->id) }}">#{{ $orderProduct->order->id }}</a></h3>
							</div>
							<form method="POST" action="{{ route('admin.clients.products.update', [$user->id, $orderProduct->id]) }}">
								<div class="card-body">
									@csrf
									<div class="row mb-2">
										<div class="col-sm-12">
											<div class="row">
												<div class="col-sm-12 mb-3">
													<div class="row">
														<div class="col-md-10 col-sm-12">
															<x-input type="select" name="action" id="action" label="Extension Settings" class="w-full" onchange="document.getElementById('statusinput').value = this.value">
																<option selected disabled>{{ __('Select Action') }}</option>
																<option value="create">{{ __('Create') }}</option>
																<option value="suspend">{{ __('Suspend') }}</option>
																<option value="unsuspend">{{ __('Unsuspend') }}</option>
																<option value="terminate">{{ __('Terminate') }}</option>
															</x-input>
														</div>
														<div class="col-md-2 col-sm-12 mt-2">
															<button class="btn btn-outline-green w-100" onclick="event.preventDefault(); document.getElementById('changestatus').submit();">{{ __('Go') }}</button>
														</div>
													</div>
												</div>
												<div class="col-sm-12  mb-3">
													<x-input type="text" disabled name="created_at" id="created_at" value="{{ $orderProduct->created_at }}" label="Created At" />
												</div>
												<div class="col-sm-12  mb-3">
													<x-input type="select" name="status" id="status" label="Status" >
														<option value="0" selected disabled>{{ __('Select Status') }}</option>
														<option value="pending" {{ $orderProduct->status === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
														<option value="paid" {{ $orderProduct->status === 'paid' ? 'selected' : '' }}>{{ __('Paid') }}</option>
														<option value="cancelled" {{ $orderProduct->status === 'cancelled' ? 'selected' : '' }}>{{ __('Cancelled') }}</option>
														<option value="suspended" {{ $orderProduct->status === 'suspended' ? 'selected' : '' }}> {{ __('Suspended') }}</option>
													</x-input>
												</div>
												 
											</div>
										</div>
										<div class="hr-text">
											<span>Product ID: <a href="{{ route('admin.products.edit', $orderProduct->product->id) }}" class="text-logo">#{{ $orderProduct->product->id }}</a></span>
										</div>
										<div class="col-sm-12 mb-3">
											<x-input type="date" name="expiry_date" id="expiry_date" value="{{ $orderProduct->expiry_date ? $orderProduct->expiry_date->format('Y-m-d') : '' }}" label="Expiry Date" />
										</div>
										<div class="col-md-6 col-sm-12 mb-3">
											 <x-input type="number" name="quantity" id="quantity" value="{{ $orderProduct->quantity }}" label="Quantity" />
										</div>
										<div class="col-md-6 col-sm-12 mb-3">
											<x-input type="text" name="price" id="price" value="{{ $orderProduct->price }}" label="Price" />
										</div>
									</div> 
									 
								</div>
								<div class="card-footer text-end">
									<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Update') }}</button>
								</div>
							</form>
							<form action="{{ route('admin.clients.products.changestatus', [$user->id, $orderProduct->id]) }}" method="POST" class="hidden" id="changestatus">
								@csrf
								<input type="hidden" name="status" id="statusinput">
							</form>
						</div>
					</div>
					<div class="col-md-6 col-sm-12">
						<div class="card mb-3">
							<div class="card-header">
								<h3 class="card-title">{{ __('Invoices') }}</h3>
							</div>
							<div class="table-responsive">
								<table class="table table-vcenter table-mobile-md card-table">
									<thead>
										<tr>
											<th>{{ __('Invoice ID') }}</th>
											<th>{{ __('Status') }}</th>
											<th>{{ __('Created At') }}</th>
											<th>{{ __('Total') }}</th>
											<th class="w-1">{{ __('Action') }}</th>
										</tr>
									</thead>
									<tbody>
										@foreach ($orderProduct->getInvoices as $invoice)
											<tr>
												<td><a href="{{ route('admin.invoices.show', $invoice->id) }}">#{{ $invoice->id }}</a></td>
												<td>{{ $invoice->status }}</td>
												<td>{{ $invoice->created_at }}</td>
												<td>{{ config('settings::currency_sign') }}{{ $invoice->total() }}</td>
												<td><a href="{{ route('admin.invoices.show', $invoice->id) }}" class="btn btn-outline-primary">{{ __('View') }}</a></td>
											</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header">
								<h3 class="card-title">{{ __('Configurable Options') }}</h3>
								<div class="col-auto ms-auto d-print-none">
									<form action="{{ route('admin.clients.products.config.create', [$user->id, $orderProduct->id]) }}" method="POST">
										@csrf
										<button class="btn btn-outline-primary">{{ __('Add New') }}</button>
									</form>
								</div>
							</div>
							@foreach ($configurableOptions as $configurableOption)
							<div class="card-body">
							
								 <form action="{{ route('admin.clients.products.config.update', [$user->id, $orderProduct->id, $configurableOption->id]) }}" method="POST">
									@if ($configurableOption->configurableOption())
										<form action="{{ route('admin.clients.products.config.update', [$user->id, $orderProduct->id, $configurableOption->id]) }}" method="POST">
											@csrf
											<div class="row">
												<div class="col-md-6 col-sm-12">
													<x-input type="text" name="key" id="key" value="{{ $configurableOption->configurableOption->name }}" disabled label="Key" />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input type="select" name="value" id="value" value="{{ $configurableOption->configurableOptionInput->name }}" label="Value">
													<option value="0" selected disabled>{{ __('Select Value') }}</option>
													@foreach ($configurableOption->configurableOption->configurableOptionInputs as $configurableOptionInput)
														<option value="{{ $configurableOptionInput->id }}"
															@if ($configurableOption->configurableOptionInput->id === $configurableOptionInput->id) selected @endif>
															{{ $configurableOptionInput->name }}
														</option>
													@endforeach
													</x-input>
												</div>
											</div>
											<button class="btn btn-outline-green" >Update</button>
										</form>
										 
									@else
										
											@csrf
											<div class="row">
												<div class="col-md-6 col-sm-12">
													<x-input type="text" name="key" id="key" value="{{ $configurableOption->key }}" label="Key" />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input type="text" name="value" id="value" value="{{ $configurableOption->value }}" label="Value" />
												</div>
												<div class="btn-list mt-2">
													 
													<button class="btn btn-outline-red " onclick="event.preventDefault(); document.getElementById('delete-form-{{ $configurableOption->id }}').submit();">Delete</button>
													<button class="btn btn-outline-green ms-auto">Update</button>
												</div>
											</div>
										
										 
										 
									@endif
									</form>
									<form action="{{ route('admin.clients.products.config.delete', [$user->id, $orderProduct->id, $configurableOption->id]) }}" id="delete-form-{{ $configurableOption->id }}" method="POST">
											@csrf
											@method('DELETE')
										</form>
								</div>
							@endforeach
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
    
</x-admin-layout>
