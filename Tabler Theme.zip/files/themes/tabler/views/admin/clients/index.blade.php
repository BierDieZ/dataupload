<x-admin-layout title="{{ __('Clients') }}" Clients>
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('All clients') }}
		</div>
		<h2 class="page-title">
			{{ __('Here you can see all your clients.') }}
		</h2>
	</div>
</div>
<div class="col-12">
	<div class="card">
		<div class="card-header">
			<h3 class="card-title">{{ __('Clients') }}</h3>
			<div class="col-auto ms-auto d-print-none">
				<a type="button" class="btn btn-outline-primary" href="{{ route('admin.clients.create') }}">{{ __('Create client') }}</a>
			</div>
		</div>
		<div class="table-responsive">
			<table class="table card-table table-vcenter text-nowrap datatable">
				<thead>
					<tr>
						<th class="w-1">{{ __('ID') }}</th>
						<th>{{ __('Name') }}</th>
						<th>{{ __('Email') }}</th>
						<th>{{ __('Created At') }}</th>
						<th class="w-1">{{ __('Edit') }}</th>
					</tr>
				</thead>
				<tbody>
				@foreach ($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
						<td>{{ $user->name }}</td>
						<td>{{ $user->email }}</td>
						<td><span class="badge bg-info text-white"> {{ $user->created_at }}</span></td>
						<td class="text-end">
							<a href="{{ route('admin.clients.edit', $user->id) }}"class="btn btn-outline-primary">{{ __('Edit/View') }}</a>
						</td>
					</tr>
				@endforeach
				</tbody>
			</table>
		</div>
	</div>
</div>
</x-admin-layout>
