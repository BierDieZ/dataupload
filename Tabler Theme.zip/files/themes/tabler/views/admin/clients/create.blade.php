<x-admin-layout title="{{ __('Clients') }}" Clients>
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Create client') }}
		</div>
		<h2 class="page-title">
			 {{ __('Here you can create a new client.') }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">							 
				 <h3 class="card-title">{{ __('Create client') }}</h3>
			</div> 
				<form method="POST" action="{{ route('admin.clients.store') }}">
				@csrf
					<div class="card-body">
                        <div class="row">
							<div class="col-sm-12">
								<div class="row">
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="first_name" id="first_name" label="{{ __('First name') }}" type="text" required placeholder="John" value="{{ old('first_name') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="last_name" id="last_name" label="{{ __('Last name') }}" type="text" required placeholder="Doe" value="{{ old('last_name') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="email" id="email" label="{{ __('Email') }}" type="email" required placeholder="john@doe.nl" value="{{ old('email') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="phone" id="phone" label="{{ __('Phone') }}" type="text" placeholder="+1234567890" value="{{ old('phone') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="companyname" id="companyname" label="{{ __('Company Name') }}" type="text" placeholder="Company Name" value="{{ old('companyname') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="password" id="password" label="{{ __('Password') }}" type="password" placeholder="********" value="{{ old('password') }}" />
									</div>
								</div>
							<hr>
								<div class="row">
									<div class="col-md-6 col-sm-12 mb-2">
										 <x-input name="address" id="address" label="{{ __('Address') }}" type="text" placeholder="Bobcat Lane" value="{{ old('address') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										 <x-input name="city" id="city" label="{{ __('City') }}" type="text" placeholder="St. Robert" value="{{ old('city') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="state" id="state" label="{{ __('State') }}" type="text" placeholder="Missouri" value="{{ old('state') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										<x-input name="country" id="country" label="{{ __('Country') }}" type="text" placeholder="United States" value="{{ old('country') }}" />
									</div>
									<div class="col-md-6 col-sm-12 mb-2">
										 <x-input name="zip" id="zip" label="{{ __('Zip') }}" type="text" placeholder="1234 NW" value="{{ old('zip') }}" />
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="card-footer text-end">
						<button type="submit" class="btn btn-outline-green ms-auto">
							{{ __('Save') }}
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
  
</x-admin-layout>
