<x-admin-layout title=" {{ __('Coupons') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Coupons') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Coupons') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-green" href="{{ route('admin.coupons.store') }}"> {{ __('Create') }}</a>
				</div>
			</div>
			@if (count($coupons) > 0)
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable">
					<thead>
						<tr>
							<th>{{ __('Code') }}</th>
							<th>{{ __('Type') }}</th>
							<th>{{ __('Uses') }}</th>
							<th>{{ __('Value') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($coupons as $coupon)
							<tr>
								<td data-label="{{ __('Code') }}">{{ $coupon->code }}</td>
								<td data-label="{{ __('Type') }}">{{ $coupon->type }}</td>
								<td data-label="{{ __('Uses') }}">{{ $coupon->uses }}</td>
								<td data-label="{{ __('Value') }}">{{ $coupon->value }}</td>
								<td data-label="{{ __('Actions') }}">
									<div class="btn-list flex-nowrap">
										<a href="{{ route('admin.coupons.edit', $coupon->id) }}" class="btn btn-outline-primary form-submit">
											{{ __('Edit') }}
										</a>
										<form action="{{ route('admin.coupons.delete', $coupon->id) }}" method="POST">
											@csrf
											@method('DELETE')
											<button type="submit" class="btn btn-outline-red form-submit">
												{{ __('Delete') }}
											</button>
										</form>
									</div>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
			@else 			   
			<div class="text-center p-4">
				{{ __('No Coupons Found.') }}
			</div>
			@endif
		</div>
    </div>
</div>
</x-admin-layout>
