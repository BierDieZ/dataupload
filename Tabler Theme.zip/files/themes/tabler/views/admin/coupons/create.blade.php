<x-admin-layout title="{{ __('Create Coupon') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Create Coupon') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Create Coupon') }}</h3>
			</div>
			<form action="{{ route('admin.coupons.store') }}" method="POST">
				@csrf
				<div class="card-body">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
									<x-input name="code" id="code" label="{{ __('Code') }}" type="text" placeholder="{{ __('Code') }}" value="{{ old('code') }}" required  />
								</div>
								<div class="col-md-4 col-sm-12">
									<x-input type="select" name="type" id="type" label="{{ __('Type') }}">
										<option value="percent">{{ __('Percent') }}</option>
										<option value="fixed">{{ __('Fixed') }}</option>
									</x-input>
								</div>
								<div class="col-md-4 col-sm-12">
									<x-input type="select" name="time" id="type" label="{{ __('Time') }}">
										<option value="lifetime">{{ __('Lifetime') }}</option>
										<option value="onetime">{{ __('One Time') }}</option>
									</x-input>
								</div>
								<div class="col-md-4 col-sm-12">
									<x-input name="value" id="value" label="{{ config('settings::currency_sign') }} {{ __('Value') }}" type="number" step="0.1" min="0" value="{{ old('value') }}" required  />
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<x-input type="select" name="status" id="status" label="{{ __('Status') }}">
										<option value="active" selected>{{ __('Active') }}</option>
										<option value="inactive">{{ __('Inactive') }}</option>
									</x-input>
								</div>
								<div class="col-md-6 col-sm-12">
									<x-input name="max_uses" id="max_uses" label="{{ __('Max Uses (not required)') }}" type="number" step="1" min="0" value="{{ old('max_uses') }}"  />
								</div>
								<div class="col-sm-12">
									<x-input type="select" name="products[]" id="products" label="{{ __('Assigned Products (not required)') }}" multiple>
										@foreach ($products as $product)
										<option value="{{ $product->id }}">{{ $product->name }}</option>
										@endforeach
									</x-input>
								</div>
								<div class="col-md-6 col-sm-12">
									<x-input name="start_date" id="start_date" label="{{ __('Start Date (not required)') }}" type="date"  value="{{ old('start_date') }}"  />
								</div>
								<div class="col-md-6 col-sm-12">
									<x-input name="end_date" id="end_date" label="{{ __('End Date (not required)') }}" type="date"  value="{{ old('end_date') }}"  />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green">{{ __('Save') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>
</x-admin-layout>
