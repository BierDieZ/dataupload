<x-admin-layout title=" {{ __('Announcements') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Announcements') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Announcements') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a type="button" class="btn btn-outline-green" href="{{ route('admin.announcements.store') }}"> {{ __('Create') }}</a>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable">
					 <thead>
						<tr>
							<th>{{ __('Name') }}</th>
							<th>{{ __('Created At') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody class="bg-white dark:bg-secondary-100 divide-y divide-gray-200">
						@foreach ($announcements as $announcement)
							<tr>
								<td>{{ $announcement->title }}</td>
								<td>{{ $announcement->created_at }}
								</td>
								<td>
									<div class="btn-list flex-nowrap">
										<a href="{{ route('admin.announcements.edit', $announcement->id) }}" class="btn">{{ __('Edit') }}</a>
										<form action="{{ route('admin.announcements.delete', $announcement->id) }}"method="POST">
											@csrf
											@method('DELETE')
											<button type="submit" class="btn btn-outline-red form-submit">{{ __('Delete') }}</button>
										</form>
									</div>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>	 
</x-admin-layout>
