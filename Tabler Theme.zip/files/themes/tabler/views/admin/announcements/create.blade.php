<x-admin-layout title="{{ __('Announcement') }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Announcement') }}
		</div>
		<h2 class="page-title">
			 {{ __('Create Announcement') }}
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Announcement') }}</h3>
			</div>
            <form method="POST" action="{{ route('admin.announcements.store') }}">
                @csrf
				<div class="card-body">
					<div class="row">
						<div class="col-sm-12">
							<x-input name="title" id="title" label="{{ __('Title') }}" type="text" placeholder="{{ __('Title') }}" value="{{ old('title') }}" required  />
						</div>
						<div class="mt-4">
							<label class="block dark:text-darkmodetext text-sm font-medium text-gray-700">
								{{ __('Description') }}
							</label>
							<textarea id="tinymce-mytextarea" type="text" class="form-input w-full @error('announcement') border-red-500 @enderror" name="announcement" value="{{ old('description') }}" novalidate ></textarea>
						</div>
						    <script>
							  // @formatter:off
							  document.addEventListener("DOMContentLoaded", function () {
								let options = {
								  selector: '#tinymce-mytextarea',
								  height: 300,
								  menubar: false,
								  statusbar: false,
								  plugins: [
									'advlist autolink lists link image charmap print preview anchor',
									'searchreplace visualblocks code fullscreen',
									'insertdatetime media table paste code help wordcount'
								  ],
								  toolbar: 'undo redo | formatselect | ' +
									'bold italic backcolor | alignleft aligncenter ' +
									'alignright alignjustify | bullist numlist outdent indent | ' +
									'removeformat',
								  content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; font-size: 14px; -webkit-font-smoothing: antialiased; }'
								}
								if (localStorage.getItem("tablerTheme") === 'dark') {
								  options.skin = 'oxide-dark';
								  options.content_css = 'dark';
								}
								tinyMCE.init(options);
							  })
							  // @formatter:on
							</script>
					</div>
				</div>
				<div class="card-footer text-end">
					<div class="d-flex">
						<x-input name="published" id="published" value="1"  label="{{ __('Published') }}" type="checkbox" />
						<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Create') }}</button>
					</div>
				</div>
            </form>
		</div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.7.2/tinymce.min.js" integrity="sha512-AHsE0IVoihNpGako20z2Tsgg77r5h9VS20XIKa+ZZ8WzzXxdbiUszgVUmXqpUE8GVUEQ88BKQqtlB/xKIY3tUg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</x-admin-layout>
