<x-admin-layout title="{{ __('Order: ') }} {{ $order->id }}"> 
    <x-success class="mt-4" />
	<div class="row">
		<div class="col-sm-12 mb-2">
			<div class="page-pretitle">
				{{ __('Order: ') }}
			</div>
			<h2 class="page-title">
				#{{ $order->id }}
			</h2>
		</div>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Order: ') }} #{{ $order->id }}</h3>
				<div class="col-auto ms-auto d-print-none">
					@if($order->status !== 'cancelled')
						<button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modal_delete">{{__('Delete')}}</button>
						<form action="{{ route('admin.orders.delete', $order->id) }} " method="POST" id="delete">
							@method('DELETE')
							@csrf
						</form>
						<div class="modal modal-blur fade" id="modal_delete" tabindex="-1" role="dialog" aria-hidden="true">
								<div class="modal-dialog modal-md modal-dialog-centered" role="document">
									<div class="modal-content">
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										<div class="modal-status  bg-danger"></div>
										<div class="modal-body text-center py-4">
											<svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10.24 3.957l-8.422 14.06a1.989 1.989 0 0 0 1.7 2.983h16.845a1.989 1.989 0 0 0 1.7 -2.983l-8.423 -14.06a1.989 1.989 0 0 0 -3.4 0z" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>
											<h3>{{ __('Delete Unrecoverable') }}</h3>
											<div class="text-secondary mb-4">{{ __('Are you sure you want to delete') }} <b> {{ __('Order: ') }} #{{ $order->id }} </b> ?</div>
										</div>
										<div class="modal-footer">
											<div class="w-100">
												<div class="row">
												<div class="col">
												<a href="#" class="btn w-100" data-bs-dismiss="modal">
													{{ __('No') }}
												  </a></div>
												<div class="col">
												<button class="btn btn-outline-danger w-100" data-bs-dismiss="modal"  onclick="document.getElementById('delete').submit()">
													{{ __('Yes') }}
												  </button>
												  </div>
											  </div>
											</div>
										</div>
									</div>
								</div>
							</div>
					@endif
				</div>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-lg-3 col-md-6 col-sm-12">
								<x-input disabled type="text" name="client" :label="__('Client')" name="title" value="{{ $order->user->name }}" icon="ri-user-line" />
							</div>
							<div class="col-lg-3 col-md-6 col-sm-12">
								<x-input disabled type="text" name="total" :label="__('Total')" icon="ri-money-dollar-circle-line" value="{{ ucfirst($order->total()) }} {{ config('settings::currency_sign') }}"/>
							</div>
							<div class="col-lg-3 col-md-6 col-sm-12">
								 <x-input disabled type="text" name="created_at" :label="__('Created At')" icon="ri-calendar-line" value="{{ $order->created_at }}"/>
							</div>
							<div class="col-lg-3 col-md-6 col-sm-12">
								 <x-input disabled type="text" name="updated_at" :label="__('Updated At')" icon="ri-calendar-line" value="{{ $order->updated_at }}"/>
							</div>
						</div>
						<div class="hr-text">{{ __('Products') }}</div>
						<div class="row">
							<div class="table-responsive">
								<table class="table table-vcenter table-mobile-md card-table">
									<thead>
										<tr>
											<th>{{__('ID')}}</th>
											<th>{{__('Name')}}</th>
											<th>{{__('Cost')}}</th>
											<th>{{__('Status')}}</th>
											<th>{{__('Active to')}}</th>
											<th>{{__('Link')}}</th>
											<th class="w-1">{{__('Actions')}}</th>
										</tr>
									</thead>
									<tbody>
										@foreach ($order->products as $product)
										<tr class="place-items-center">
											<td>{{ $product->product()->get()->first()->id }}</td>
											<td>{{ $product->product()->get()->first()->name }}</td>
											<td>
												<span class="badge bg-azure text-white">{{ config('settings::currency_sign') }}{{ $product->price ?? $product->product->price }} </span>
											</td>
											<td>
												@if($product->status === 'paid')
													<span class="badge bg-green text-white">{{ __('Paid') }}</span>
												@elseif($product->status === 'pending')
													<span class="badge bg-warning text-white">{{ __('Pending') }}</span>
												@else
													<span class="badge bg-danger text-white">{{ ucfirst($product->status) }}</span>
												@endif
											</td>
											<td>{{ $product->expiry_date ? $product->expiry_date->format('Y-m-d') : 'N/A' }}</td>
											<td>{{ $product->link ?: 'N/A' }}</td>
											<td>
												<div class="btn-list flex-nowrap">
												<a href="{{ route('admin.clients.products', ['user' => $order->user, 'orderProduct' => $product->id]) }}" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Edit')}}" class="btn">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-settings-2" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M19.875 6.27a2.225 2.225 0 0 1 1.125 1.948v7.284c0 .809 -.443 1.555 -1.158 1.948l-6.75 4.27a2.269 2.269 0 0 1 -2.184 0l-6.75 -4.27a2.225 2.225 0 0 1 -1.158 -1.948v-7.285c0 -.809 .443 -1.554 1.158 -1.947l6.75 -3.98a2.33 2.33 0 0 1 2.25 0l6.75 3.98h-.033z"></path>
													   <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
													</svg>
												</a>
												<a href="#" target="_blank"  data-bs-toggle="modal" data-bs-target="#changePriceQuantity{{ $product->id }}"  class="btn">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-cash" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Change price/quantity')}}">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M7 9m0 2a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2z"></path>
													   <path d="M14 14m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
													   <path d="M17 9v-2a2 2 0 0 0 -2 -2h-10a2 2 0 0 0 -2 2v6a2 2 0 0 0 2 2h2"></path>
													</svg>
												</a>
												@if(!$product->link)
												<form method="POST" action="{{ route('admin.orders.create', $order->id) }}" >
													@csrf
													<button class="btn" type="submit" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Create server in extension')}}">
														<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-server-cog" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
														   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
														   <path d="M3 4m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v2a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z"></path>
														   <path d="M12 20h-6a3 3 0 0 1 -3 -3v-2a3 3 0 0 1 3 -3h10.5"></path>
														   <path d="M18 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
														   <path d="M18 14.5v1.5"></path>
														   <path d="M18 20v1.5"></path>
														   <path d="M21.032 16.25l-1.299 .75"></path>
														   <path d="M16.27 19l-1.3 .75"></path>
														   <path d="M14.97 16.25l1.3 .75"></path>
														   <path d="M19.733 19l1.3 .75"></path>
														   <path d="M7 8v.01"></path>
														   <path d="M7 16v.01"></path>
														</svg>
													</button>
												</form>
												@endif
												@if ($product->status == 'pending')
													<form method="POST" action="{{ route('admin.orders.paid', $order->id) }}" >
														@csrf
														<button class="btn" type="submit" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Mark as paid')}}">
															<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-server-cog" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
															   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
															   <path d="M3 4m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v2a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z"></path>
															   <path d="M12 20h-6a3 3 0 0 1 -3 -3v-2a3 3 0 0 1 3 -3h10.5"></path>
															   <path d="M18 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
															   <path d="M18 14.5v1.5"></path>
															   <path d="M18 20v1.5"></path>
															   <path d="M21.032 16.25l-1.299 .75"></path>
															   <path d="M16.27 19l-1.3 .75"></path>
															   <path d="M14.97 16.25l1.3 .75"></path>
															   <path d="M19.733 19l1.3 .75"></path>
															   <path d="M7 8v.01"></path>
															   <path d="M7 16v.01"></path>
															</svg>
														</button>
													</form>
												@endif 
													<form action="{{ route('admin.orders.deleteProduct', ['order' => $order->id, 'product' => $product->id]) }}" method="POST">
														@method('DELETE')
														@csrf
														<button type="submit" class="btn" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete product from order">
															<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-playlist-x" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
															   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
															   <path d="M19 8h-14"></path>
															   <path d="M5 12h7"></path>
															   <path d="M12 16h-7"></path>
															   <path d="M16 14l4 4"></path>
															   <path d="M20 14l-4 4"></path>
															</svg>
														</button>
													</form>
												</div>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						</div>
						<div class="hr-text"> {{ __('Invoices') }}</div>
						<div class="row">
							<div class="table-responsive">
								<table class="table table-vcenter table-mobile-md card-table">
								<thead>
								<tr class="border-b-2 border-secondary-200">
									<th>{{ __('ID') }}</th>
									<th>{{ __('Status') }}</th>
									<th>{{ __('Created at') }}</th>
									<th>{{ __('Paid at') }}</th>
									<th class="w-1">{{ __('Actions') }}</th>
								</tr>
								</thead>
								<tbody>
								@foreach ($order->invoices as $invoice)
									<tr>
										<td>{{ $invoice->id }}</td>
										<td>
											@if($invoice->status === 'paid')
												<span class="badge bg-green text-white">{{ __('Paid') }}</span>
											@elseif($invoice->status === 'pending')
												<span class="badge bg-warning text-white">{{ __('Pending') }}</span>
											@else
												<span class="badge bg-danger text-white">{{ ucfirst($invoice->status) }}</span>
											@endif
										</td>
										<td>{{ $invoice->created_at }}</td>
										<td>{{ $invoice->paid_at }}</td>
										<td>
											<div class="btn-list flex-nowrap">
												<a href="{{ route('admin.invoices.show', $invoice->id) }}" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('View Invoice')}}" class="btn">
													<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-eye-search" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
													   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
													   <path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
													   <path d="M12 18c-.328 0 -.652 -.017 -.97 -.05c-3.172 -.332 -5.85 -2.315 -8.03 -5.95c2.4 -4 5.4 -6 9 -6c3.465 0 6.374 1.853 8.727 5.558"></path>
													   <path d="M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
													   <path d="M20.2 20.2l1.8 1.8"></path>
													</svg>
												</a>
												 
											</div>
										</td>
									</tr>
								@endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    @if(isset($product))
	<div class="modal" id="changePriceQuantity{{ $product->id }}" tabindex="-1">
		<div class="modal-dialog" role="document">
			<form method="POST"action="{{ route('admin.orders.changeProduct', ['order' => $order->id, 'product' => $product->id]) }}">
			@csrf
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">{{ __('Change Price/Quantity') }}</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-sm-12">
								<x-input name="price" label="{{ __('Price') }}" type="number" placeholder="{{ config('settings::currency_sign') }}{{ __('Price') }}" value="{{ $product->price ?? $product->product->price }}" class="form-input" />
							</div>
							<div class="col-sm-12">
								<x-input name="quantity" label="{{ __('Quantity') }}" type="text" placeholder="{{ __('Quantity') }}" value="{{ $product->quantity }}" class="form-input" />
							</div>
							<div class="col-sm-12">
								<x-input name="expiry_date" label="{{ __('Expiry Date') }}" type="date" placeholder="{{ __('Expiry Date') }}" value="{{ $product->expiry_date ? $product->expiry_date->format('Y-m-d') : '' }}" class="form-input" />
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn me-auto" data-bs-dismiss="modal">{{__('Close')}}</button>
						<button type="submit" class="btn btn-outline-green" data-bs-dismiss="modal">{{ __('Change') }}</button>
					</div>
				</div>
			</form>
		</div>
	</div>
    @endif
 
        

</x-admin-layout>
