<x-admin-layout title="{{ __('Orders') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Orders') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>    
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Orders') }}</h3>
			</div>
			@if ($orders->count() > 0)
			<div class="table-responsive">
				<table class="table table-vcenter table-mobile-md card-table">
					<thead>
						<tr>
							<th>{{ __('ID') }}</th>
							<th>{{ __('User') }}</th>
							<th>{{ __('Total') }}</th>
							<th>{{ __('Created At') }}</th>
							<th>{{ __('Updated At') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($orders as $order)
							<tr>
								<td>{{ $order->id }}</td>
								<td>{{ $order->user->name }}</td>
								<td>{{ $order->total() }} {{ config('settings::currency_sign') }}</td>
								<td>{{ $order->created_at }}</td>
								<td>{{ $order->updated_at }}</td>
								<td>
									<a href="{{ route('admin.orders.show', $order->id) }}" class="btn btn-outline-primary">
										{{ __('Show') }}
									</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
			@else
			<div class="text-center p-4">{{ __('Orders not found!') }}</div>
			@endif
		</div>
	</div>
</div>
 
</x-admin-layout>
