<x-admin-layout title=" {{ __('Settings') }}">
<x-success />
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			 {{ __('Settings') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
					<li class="nav-item">
						<a href="#general" class="nav-link active" data-bs-toggle="tab">General</a>
					</li>
					<li class="nav-item">
						<a href="#affiliate" class="nav-link" data-bs-toggle="tab">Affiliate</a>
					</li>
					<li class="nav-item">
						<a href="#company" class="nav-link" data-bs-toggle="tab">Company</a>
					</li>
					<li class="nav-item">
						<a href="#credits" class="nav-link" data-bs-toggle="tab">Credits</a>
					</li>
					<li class="nav-item">
						<a href="#cronjob" class="nav-link" data-bs-toggle="tab">Cronjob</a>
					</li>
					<li class="nav-item">
						<a href="#login" class="nav-link" data-bs-toggle="tab">Login</a>
					</li>
					<li class="nav-item">
						<a href="#mail" class="nav-link" data-bs-toggle="tab">Mail</a>
					</li>
					<li class="nav-item">
						<a href="#security" class="nav-link" data-bs-toggle="tab">Security</a>
					</li>
					<li class="nav-item">
						<a href="#theme" class="nav-link" data-bs-toggle="tab">Theme</a>
					</li>
					<li class="nav-item">
						<a href="#upgrade" class="nav-link" data-bs-toggle="tab">Upgrade</a>
					</li>
				</ul>
			</div>			 
			<div class="tab-content">
				<div class="tab-pane active show" id="general">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.general') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-6 col-sm-12">
											<x-input name="app_name" id="app_name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ config('settings::app_name') }}" required  />
										</div>
										<div class="col-md-6 col-sm-12">
											<x-input name="app_logo" id="app_logo" label="{{ __('Logo') }}" type="file" accept="image/*"  />
										</div>
										<div class="col-md-6 col-sm-12">
											<x-input type="select" name="timezone" id="timezone" label="{{ __('Timezone') }}" required>
											@foreach ($timezones as $timezone)
													<option value="{{ $timezone }}" {{ $timezone == config('settings::timezone') ? 'selected' : '' }}>
														{{ $timezone }}</option>
												@endforeach
											</x-input>
										</div>
										<div class="col-md-6 col-sm-12">
											<x-input type="select" name="sidebar" id="sidebar" label="{{ __('Menu display style') }}" required>
												<option value="0" {{ config('settings::sidebar') == 0 ? 'selected' : '' }}>{{ __('Topbar') }}</option>
												<option value="1" {{ config('settings::sidebar') == 1 ? 'selected' : '' }}>{{ __('Sidebar') }}</option>
											</x-input>
										</div>
										<div class="col-sm-12">
											<textarea id="textarea" name="home_page_text" type="textarea" placeholder="{{ __('Home Page Text') }}" value="{{ old('description') }}" novalidate >{{ config('settings::home_page_text') }}</textarea>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6 col-sm-12">
											<div class="row">
												<div class="col-sm-12">
												<div class="hr-text">
													<span>{{ __('Orders') }}</span>
												</div>
													<x-input type="number" name="remove_unpaid_order_after" id="remove_unpaid_order_after" label="{{ __('Days after which an unpaid server will remove itself') }}" value="{{ config('settings::remove_unpaid_order_after') }}" />
												</div>
											</div>
										</div>
										<div class="col-md-6 col-sm-12">
											<div class="row">
												<div class="col-sm-12">
													<div class="hr-text">
														<span>{{ __('Currency') }}</span>
													</div>
												</div>
												<div class="col-lg-4 col-md-6 col-sm-12">
													<x-input type="text" name="currency_sign" id="currency_sign" label="{{ __('Currency Sign') }}" value="{{ config('settings::currency_sign') }}" />
												</div>
												<div class="col-lg-4 col-md-6 col-sm-12">
													<x-input type="text" name="currency" id="currency" label="{{ __('Currency Code') }}" value="{{ config('settings::currency') }}" />
												</div>
												<div class="col-lg-4 col-md-6 col-sm-12">
													<x-input type="select" name="currency_position" id="currency_position" label="{{ __('Currency Position') }}" required>
														<option value="left" {{ config('settings::currency_position') == 'left' ? 'selected' : '' }}>{{ __('Left') }}</option>
														<option value="right" {{ config('settings::currency_position') == 'right' ? 'selected' : '' }}>{{ __('Right') }}</option>
													</x-input>
												</div>
											</div>
										</div>
										<div class="col-md-6 col-sm-12">
											<div class="row">
												<div class="col-sm-12">
													<div class="hr-text">
														<span>{{ __('Language') }}</span>
													</div>
												</div>
												<div class="col-md-8 col-sm-12">
													<x-input type="select" name="language" id="language" label="{{ __('Language') }}" required>
														@foreach ($languages as $language)
															<option value="{{ $language }}" {{ $language == config('settings::language') ? 'selected' : '' }}> {{ $language }}</option>
														@endforeach
													</x-input>
												</div>
												<div class="col-md-4 col-sm-12 mt-2" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('If enabled, the language will be automatically set to the language of the browser.') }}">
													<x-input type="checkbox" id="allow_auto_lang" name="allow_auto_lang" value="1" label="{{ __('Allow Auto Language') }}" :checked="config('settings::allow_auto_lang') ? 'checked' : ''"  />
													 
												</div>
											</div>
										</div>
										<div class="col-md-6 col-sm-12">
											<div class="row">
												<div class="col-sm-12">
													<div class="hr-text">
														<span>{{ __('SEO') }}</span>
													</div>
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input type="text" name="seo_title" id="seo_title" label="{{ __('Seo Title') }}" value="{{ config('settings::seo_title') }}" />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input type="text" name="seo_description" id="seo_description" label="{{ __('Seo Description') }}" value="{{ config('settings::seo_description') }}" />
												</div>
												<div class="col-md-8 col-sm-12">
													<x-input type="text" name="seo_keywords" id="seo_keywords" label="{{ __('Seo Keywords (separate with comma)') }}" value="{{ config('settings::seo_keywords') }}"  />
												</div>
												<div class="col-md-4 col-sm-12 mt-2">
													<x-input type="checkbox" id="seo_twitter_card" name="seo_twitter_card" value="1" label="{{ __('Seo Twitter Card') }}" :checked="config('settings::seo_twitter_card') ? 'checked' : ''"  />
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">   
							<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="affiliate">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.affiliate') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-2 col-sm-12" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Affiliates can earn money by referring users to the site.') }}">
											<x-input type="checkbox" id="affiliate" name="affiliate" value="1" label="{{ __('Affiliate System enabled') }}" :checked="config('settings::affiliate') ? 'checked' : ''"  />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="affiliate_percentage" id="affiliate_percentage" label="{{ __('Earning Percentage %') }}" type="text" placeholder="{{ __('Earning Percentage %') }}" value="{{ config('settings::affiliate_percentage') }}"    />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input type="select" name="affiliate_type" id="affiliate_type" label="{{ __('Currency Position') }}" required>
												<option value="random" {{ config('settings::affiliate_type') == 'random' ? 'selected' : '' }}>{{ __('Random Link') . ' ' . url('asde2e') }}</option>
												<option value="fixed" {{ config('settings::affiliate_type') == 'fixed' ? 'selected' : '' }}>{{ __('Fixed Link') . ' ' . url(str_replace(' ', '', auth()->user()->name)) }}</option>
												<option value="custom" {{ config('settings::affiliate_type') == 'custom' ? 'selected' : '' }}>{{ __('Custom Link (The user sets his own code)') }}</option>
											</x-input>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="company">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.company') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-3 col-sm-12">
											<x-input name="company_name" id="company_name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ config('settings::company_name') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_tin" id="company_tin" label="{{ __('TIN') }}" type="text" placeholder="{{ __('TIN') }}" value="{{ config('settings::company_tin') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_country" id="company_country" label="{{ __('Country') }}" type="text" placeholder="{{ __('Country') }}" value="{{ config('settings::company_country') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_address" id="company_address" label="{{ __('Address') }}" type="text" placeholder="{{ __('Address') }}" value="{{ config('settings::company_address') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_phone" id="company_phone" label="{{ __('Phone') }}" type="text" placeholder="{{ __('Phone') }}" value="{{ config('settings::company_phone') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_email" id="company_email" label="{{ __('Email') }}" type="text" placeholder="{{ __('Email') }}" value="{{ config('settings::company_email') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_city" id="company_city" label="{{ __('City') }}" type="text" placeholder="{{ __('City') }}" value="{{ config('settings::company_city') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="company_zip" id="company_zip" label="{{ __('Zip') }}" type="text" placeholder="{{ __('Zip') }}" value="{{ config('settings::company_zip') }}"    />
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="credits">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.credits') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-3 col-sm-12">
											<x-input type="checkbox" id="credits" name="credits" value="1" label=" {{ __('Check to enable adding of funds by clients from the client area.') }}" :checked="config('settings::credits') ? 'checked' : ''"  />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="minimum_deposit" id="minimum_deposit" label="{{ __('Minimum deposit') }}" type="number" placeholder="{{ __('Minimum deposit') }}" value="{{ config('settings::minimum_deposit') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="maximum_deposit" id="maximum_deposit" label="{{ __('Maximum deposit') }}" type="number" placeholder="{{ __('Maximum deposit') }}" value="{{ config('settings::maximum_deposit') }}"    />
										</div>
										<div class="col-md-3 col-sm-12">
											<x-input name="maximum_balance" id="maximum_balance" label="{{ __('Maximum credit balance') }}" type="number" placeholder="{{ __('Maximum credit balance') }}" value="{{ config('settings::maximum_balance') }}"    />
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="cronjob">
				@php $last_ran_at = config('settings::cronjob_last_run'); @endphp
				@isset($last_ran_at)
					<div class="card-body">
						<div class="row">
							<div class="col-sm-12">
								<div class="row">
									<div class="col-md-6 col-sm-12">
									 
										<x-input name="" label="{{ __('Last Ran At') }}" type="text" value="{{ $last_ran_at }}" disabled />
										
										@if ($last_ran_at < now()->subMinutes(10))
											<p class="text-red">
												{{ __('Cronjob has not run in the last') }}
												<b>{{ now()->diffInMinutes($last_ran_at) }} </b>
												{{ __('minutes.') }}<br />
												{{ __('Please check your cronjob setup.') }}
											</p>
										@endif
									</div>
								</div>
							</div>
						</div>
					</div>
					@if ($last_ran_at < now()->subMinutes(10))
					<div class="card-footer text-end">
						<a href="https://paymenter.org/docs/getting-started/installation/#cronjob" class="btn btn-outline-azure ms-auto" target="_blank">{{ __('Click here to learn how to setup cronjob.') }}</a>
					</div>
					@endif
				@else
					 <div class="card-body">
						<div class="row">
							<div class="col-sm-6">
								<x-input name="" label="{{ __('Last Ran At') }}" type="text" value="Never" disabled />
							</div>
							<div class="col-sm-12 text-danger">
								{{ __('Cronjob is not running. Please setup cronjob to run every minute.') }}<br />
								{{ __('This will cause issues such as invoices not being generated/ mails not being sent etc.') }}
							</div>
						</div>
					</div>
					<div class="card-footer text-end">
						<a href="https://paymenter.org/docs/getting-started/installation/#cronjob" class="btn btn-outline-azure ms-auto" target="_blank">{{ __('Click here to learn how to setup cronjob.') }}</a>
					</div>
				@endisset
				</div>
				<div class="tab-pane" id="login">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.login') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<label class="form-label">{{ __('Discord:') }} 
										<span class="form-help ms-auto" data-bs-toggle="popover" data-bs-placement="top" data-bs-html="true" data-bs-content="<p>{{ __('Discord OAuth2 is a service that allows users to log in to your site using their Discord account.') }}</p><p> {{ __('You need to set your redirect url to') }}</p><p class='mb-0'><code>{{ route('social.login.callback', 'discord') }}</code></p>">?</span></label>
										<div class="col-md-2 col-sm-12">
											<x-input type="checkbox" id="discord_enabled" name="discord_enabled" value="1" label="{{ __('Enable Discord') }}" :checked="config('settings::discord_enabled') ? 'checked' : ''"  />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="discord_client_id" id="discord_client_id" label="{{ __('Discord Client ID') }}" type="text" placeholder="{{ __('Discord Client ID') }}" value="{{ config('services.discord.client_id') }}"    />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="discord_client_secret" id="discord_client_secret" label="{{ __('Discord Client Secret') }}" type="text" placeholder="{{ __('Discord Client Secret') }}" value="{{ config('services.discord.client_secret') }}"    />
										</div>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="row">
										<label class="form-label">{{ __('Google:') }}
										<span class="form-help ms-auto" data-bs-toggle="popover" data-bs-placement="top" data-bs-html="true" data-bs-content="<p> {{ __('Google OAuth2 is a service that allows users to log in to your site using their Google account.') }}</p><p> {{ __('You need to set your redirect url to') }}</p><p class='mb-0'><code>{{ route('social.login.callback', 'google') }}</code></p>">?</span></label>
										<div class="col-md-2 col-sm-12">
											<x-input type="checkbox" id="google_enabled" name="google_enabled" value="1" label="{{ __('Enable Google') }}" :checked="config('settings::google_enabled') ? 'checked' : ''"  />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="google_client_id" id="google_client_id" label="{{ __('Google Client ID') }}" type="text" placeholder="{{ __('Google Client ID') }}" value="{{ config('settings::google_client_id') }}"    />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="google_client_secret" id="google_client_secret" label="{{ __('Google Client Secret') }}" type="text" placeholder="{{ __('Google Client Secret') }}" value="{{ config('settings::google_client_secret') }}"    />
										</div>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="row">
										<label class="form-label">{{ __('Github:') }}
										<span class="form-help ms-auto" data-bs-toggle="popover" data-bs-placement="top" data-bs-html="true" data-bs-content="<p>{{ __('Github OAuth2 is a service that allows users to log in to your site using their Github account.') }}</p><p> {{ __('You need to set your redirect url to') }}</p><p class='mb-0'><code>{{ route('social.login.callback', 'github') }}</code></p>">?</span></label>
										<div class="col-md-2 col-sm-12">
											<x-input type="checkbox" id="github_enabled" name="github_enabled" value="1" label="{{ __('Enable Github') }}" :checked="config('settings::github_enabled') ? 'checked' : ''"  />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="github_client_id" id="github_client_id" label="{{ __('Github Client ID') }}" type="text" placeholder="{{ __('Github Client ID') }}" value="{{ config('settings::github_client_id') }}"    />
										</div>
										<div class="col-md-5 col-sm-12">
											<x-input name="github_client_secret" id="github_client_secret" label="{{ __('Github Client Secret') }}" type="text" placeholder="{{ __('Github Client Secret') }}" value="{{ config('settings::github_client_secret') }}"    />
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="mail">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.email') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-2 col-sm-12">
											<div class="col-sm-12">
												<x-input type="checkbox" id="mail_disabled" name="mail_disabled" value="1" label="{{ __('Disable all mails') }}" :checked="config('settings::mail_disabled') ? 'checked' : ''"  />
											</div>
											<div class="col-sm-12">
												<x-input type="checkbox" id="must_verify_email" name="must_verify_email" value="1" label="{{ __('Must Verify Email') }}" :checked="config('settings::must_verify_email') ? 'checked' : ''"  />
											</div>
										</div>
										<div class="col-md-10 col-sm-12">
											<div class="row">
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_username" id="mail_username" label="{{ __('Mail Username') }}" type="text" placeholder="{{ __('Mail Username') }}" value="{{ config('mail.username') }}"    />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_password" id="mail_password" label="{{ __('Mail Password') }}" type="password" placeholder="{{ __('Mail Password') }}" value="{{ config('mail.password') }}"    />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_host" id="mail_host" label="{{ __('Mail Host') }}" type="text" placeholder="{{ __('Mail Host') }}" value="{{ config('mail.host') }}"    />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_port" id="mail_port" label="{{ __('Mail Port') }}" type="text" placeholder="{{ __('Mail Port') }}" value="{{ config('mail.port') }}"    />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_from_address" id="mail_from_address" label="{{ __('Mail From Address') }}" type="text" placeholder="{{ __('Mail From Address') }}" value="{{ config('mail.from.address') }}"    />
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="mail_from_name" id="mail_from_name" label="{{ __('Mail From Name') }}" type="text" placeholder="{{ __('Mail From Name') }}" value="{{ config('mail.from.name') }}"    />
												</div>
												<div class="col-md-2 col-sm-12">
													<x-input type="select" name="mail_encryption" id="mail_encryption" label="{{ __('Mail Encryption') }}" >
														<option value="tls" {{ config('mail.encryption') == 'tls' ? 'selected' : '' }}>TLS</option>
														<option value="ssl" {{ config('mail.encryption') == 'ssl' ? 'selected' : '' }}>SSL</option>
														<option value="none" {{ config('mail.encryption') == '' ? 'selected' : '' }}>None</option>
													</x-input>
												</div>
												<div class="col-md-10 col-sm-12" data-bs-toggle="tooltip" data-bs-placement="top" title=" {{ __('Email addresses to BCC all outgoing emails to. Separate multiple email addresses using commas.') }}">
													<x-input name="bcc" id="bcc" label="{{ __('BCC Messages') }}" type="text" placeholder="{{ __('BCC Messages') }}" value="{{ config('settings::bcc') }}"    />
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<div class="d-flex">
								<button type="button" class="btn btn-outline-info" id="testMail">{{ __('Test') }}</button>
								<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
							</div>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="security">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.security') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-2 col-sm-12">
											<div class="col-sm-12">
												<x-input type="checkbox" id="recaptcha" name="recaptcha" value="1" label="{{ __('Enable Recaptcha') }}" :checked="config('settings::recaptcha') ? 'checked' : ''"  />
											</div>
										</div>
										<div class="col-md-10 col-sm-12">
											<div class="row">
												<div class="col-md-6 col-sm-12">
													<x-input type="select" name="recaptcha_type" id="recaptcha_type" label="{{ __('Recaptcha type') }}" >
														<option value="v2" {{ config('settings::recaptcha_type') == 'v2' ? 'selected' : '' }}>{{ __('Recaptcha v2 (checkbox)') }}</option>
														<option value="v2_invisible" {{ config('settings::recaptcha_type') == 'v2_invisible' ? 'selected' : '' }}> {{ __('Recaptcha v2 (invisible)') }}</option>
														<option value="v3" {{ config('settings::recaptcha_type') == 'v3' ? 'selected' : '' }}> {{ __('Recaptcha v3') }}</option>
														<option value="turnstile" {{ config('settings::recaptcha_type') == 'turnstile' ? 'selected' : '' }}> {{ __('Cloudflare Turnstile') }}</option>
														<option value="hcaptcha" {{ config('settings::recaptcha_type') == 'hcaptcha' ? 'selected' : '' }}>{{ __('hCaptcha') }}</option>
													</x-input>
												</div>
												<div class="col-md-6 col-sm-12">
													<x-input name="recaptcha_site_key" id="recaptcha_site_key" label="{{ __('Recaptcha public key') }}" type="text" placeholder="{{ __('Recaptcha public key') }}" value="{{ config('settings::recaptcha_site_key') }}"    />
												</div>
												<div class="col-sm-12">
													<x-input name="recaptcha_secret_key" id="recaptcha_secret_key" label="{{ __('Recaptcha Secret key') }}" type="text" placeholder="{{ __('Recaptcha Secret key') }}" value="{{ config('settings::recaptcha_secret_key') }}"    />
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="hr-text">
									<span>{{ __('Terms of Service:') }}</span>
								</div>
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-2 col-sm-12">
											<div class="col-sm-12">
												<x-input type="checkbox" id="tos" name="tos" value="1" label="{{ __('Require TOS to be accepted on checkout') }}" :checked="config('settings::tos') ? 'checked' : ''"  />
											</div>
										</div>
										<div class="col-md-10 col-sm-12">
											<div class="row">
												<div class="col-sm-12">
													<textarea id="textarea" name="tos_text" type="text">{{ config('settings::tos_text') }}</textarea>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<div class="d-flex">
								<button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
							</div>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="theme">
					<form method="POST" enctype="multipart/form-data" action="{{ route('admin.settings.theme') }}">
					@csrf
						<div class="card-body">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-4 col-sm-12">
											<div class="col-sm-12">
												<div class="col-md-6 col-sm-12">
													<x-input type="select" name="theme" id="theme" label="{{ __('Theme') }}" >
														@foreach ($themes as $theme)
														<option value="{{ $theme }}" {{ $theme == config('settings::theme-active') ? 'selected' : '' }}>{{ $theme }}</option>
													@endforeach
													</x-input>
												</div>
											</div>
										</div>
										 
									</div>
								</div>
								<div class="col-sm-12">
									<div class="row">
									@foreach ($themeConfig->settings as $setting)
										@if ($setting->type == 'subcategory')
										<div class="col-md-6 col-sm-12">
											<div class="hr-text">
												<span>{{ __($setting->label) }}</span>
											</div>
											<div class="row">
												@foreach ($setting->settings as $subSetting)
												
													@if ($subSetting->type == 'color')
														<div class="col-md-4">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="config('settings::theme:' . $subSetting->name, $subSetting->default ?? null)" :label="$subSetting->label" :id="$subSetting->name" class="w-fit" />
														</div>
													@elseif($subSetting->type == 'checkbox')
														<div class="col-md-4">
															<input type="hidden" name="{{ $subSetting->name }}" value="0">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="1" :label="$subSetting->label" :checked="config('settings::theme:' . $subSetting->name, $subSetting->default ?? false) ? 1 : 0" :id="$subSetting->name" />
														</div>
													@else
														<div class="col-md-8">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="config('settings::theme:' . $subSetting->name, $subSetting->default ?? null)" :label="$subSetting->label" :id="$subSetting->name" />
														</div>
													@endif
												
												@endforeach
											</div>
										</div>
										@elseif ($setting->type == 'Optional')
										<div class="col-md-6 col-sm-12">
											<div class="hr-text">
												<span>{{ __($setting->label) }}</span>
											</div>
											<div class="row">
												@foreach ($setting->settings as $subSetting)
												
													@if($subSetting->type == 'checkbox')
														<div class="col-sm-6">
															<input type="hidden" name="{{ $subSetting->name }}" value="0">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="1" :label="$subSetting->label" :checked="config('settings::theme:' . $subSetting->name, $subSetting->default ?? false) ? 1 : 0" :id="$subSetting->name" />
														</div>
													@endif
												
												@endforeach
											</div>
										</div>
										@elseif ($setting->type == 'customFooterLinks')
										<div class="col-md-6 col-sm-12">
											<div class="hr-text">
												<span>{{ __($setting->label) }}</span>
											</div>
											<div class="row">
												@foreach ($setting->settings as $subSetting)
												
													@if($subSetting->type == 'checkbox')
														<div class="col-sm-6">
															<input type="hidden" name="{{ $subSetting->name }}" value="0">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="1" :label="$subSetting->label" :checked="config('settings::theme:' . $subSetting->name, $subSetting->default ?? false) ? 1 : 0" :id="$subSetting->name" />
														</div>
													@else
														<div class="col-sm-6">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="config('settings::theme:' . $subSetting->name, $subSetting->default ?? null)" :label="$subSetting->label" :id="$subSetting->name" />
														</div>
													@endif
												
												@endforeach
											</div>
										</div>
										@elseif ($setting->type == 'customFooter')
										<div class="col-md-6 col-sm-12">
											<div class="hr-text">
												<span>{{ __($setting->label) }}</span>
											</div>
											<div class="row">
												@foreach ($setting->settings as $subSetting)
												
													@if($subSetting->type == 'checkbox')
														<div class="col-sm-6">
															<input type="hidden" name="{{ $subSetting->name }}" value="0">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="1" :label="$subSetting->label" :checked="config('settings::theme:' . $subSetting->name, $subSetting->default ?? false) ? 1 : 0" :id="$subSetting->name" />
														</div>
													 @else
														<div class="col-sm-12">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="config('settings::theme:' . $subSetting->name, $subSetting->default ?? null)" :label="$subSetting->label" :id="$subSetting->name" />
														</div>
													@endif
												
												@endforeach
											</div>
										</div>
										@elseif ($setting->type == 'customNotificationTopbar')
										<div class="col-md-6 col-sm-12">
											<div class="hr-text">
												<span>{{ __($setting->label) }}</span>
											</div>
											<div class="row">
												@foreach ($setting->settings as $subSetting)
												
													@if($subSetting->type == 'checkbox')
														<div class="col-sm-12">
															<input type="hidden" name="{{ $subSetting->name }}" value="0">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="1" :label="$subSetting->label" :checked="config('settings::theme:' . $subSetting->name, $subSetting->default ?? false) ? 1 : 0" :id="$subSetting->name" />
														</div>
													@else
														<div class="col-sm-12">
															<x-input :name="$subSetting->name" :type="$subSetting->type" :value="config('settings::theme:' . $subSetting->name, $subSetting->default ?? null)" :label="$subSetting->label" :id="$subSetting->name" />
														</div>
													@endif
												
												@endforeach
											</div>
										</div>
										@else
											 <div class="row">
												@if ($setting->type == 'color')
													<div class="col-md-6">
													<x-input :name="$setting->name" :type="$setting->type" :value="config('settings::theme:' . $setting->name, $setting->name)" :label="$setting->label" :id="$setting->name" class="w-fit" />
													</div>
												@elseif($setting->type == 'checkbox')
													<div class="col-md-6">
														<input type="hidden" name="{{ $setting->name }}" value="0">
														<x-input :name="$setting->name" :type="$setting->type" :value="1" :label="$setting->label" :checked="config('settings::theme:' . $setting->name, $setting->default ?? false) ? 1 : 0" :id="$setting->name" />
													</div>
												@else
													<div class="col-md-6">
														<x-input :name="$setting->name" :type="$setting->type" :value="config('settings::theme:' . $setting->name, $setting->default ?? null)" :label="$setting->label" :id="$setting->name" />
													</div>
												@endif
											</div>
										@endif
									@endforeach
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<div class="d-flex">
								<button type="submit" name="reset" value="1" class="btn btn-outline-danger">{{ __('Reset') }}</button>
								<button type="submit" class="btn btn-outline-green ms-auto">{{ __('Save') }}</button>
							</div>
						</div>
					</form>
				</div>
				<div class="tab-pane" id="upgrade">
					<div class="card-body">
						<div class="row">
							<div class="col-sm-12">
								@if (config('app.version') == 'development')
									<div class="row">
										<div class="col-md-6 col-sm-12">
											{{ __('You are running a development version') }}
										</div>
										<br>
										<div class="text-red">
											<strong class="font-bold">{{ __('This version is not supported for production use. It may contain various errors and some functions may not work.') }}</strong>
											<br>
											{{ __('Please use the latest stable version.') }}
										</div>
									</div>
								@else
									<div class="row">
										<div class="col-md-6 col-sm-12">
											{{ __('You are running version') }} {{ config('app.version') }}
										</div>
										<br>
										<div class="text-green">
											<strong class="font-bold">{{ __('Latest version') }}</strong> <span id="latest-version"></span>
										</div>
									</div>								  
								@endif
							</div>
						</div>
					</div>
				</div>
				<script>
					document.getElementById('latest-version').innerHTML = '...';
					fetch('https://api.github.com/repos/Paymenter/Paymenter/releases/latest')
						.then(response => response.json())
						.then(data => {
							if(data.tag_name == 'v{{ config('app.version') }}') {
								document.getElementById('latest-version').innerHTML = data.tag_name + ' ({{ __('Latest') }})';
							} else {
								document.getElementById('latest-version').innerHTML = data.tag_name + ' ({{ __('Update available') }})' + '<br><a href="https://paymenter.org/docs/how-to-update" class="text-blue-500 hover:text-blue-700">{{ __('Upgrade') }}</a>';
							}
						});
				</script>
			</div>
		</div>
	</div>
</div>
 
<div class="modal" id="testMailSuccess" tabindex="-1">
	<div class="modal-dialog modal-sm" role="document">
		<div class="modal-content">
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			<div class="modal-status bg-success"></div>
			<div class="modal-body text-center py-4">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-green icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
					<path stroke="none" d="M0 0h24v24H0z" fill="none" />
					<circle cx="12" cy="12" r="9" />
					<path d="M9 12l2 2l4 -4" />
				</svg>
				<h3>Success</h3>
				<div class="text-secondary">Email send succesfully!</div>
			</div>
			<div class="modal-footer">
				<div class="w-100">
					<div class="row">
						<div class="col">
							<a href="#" class="btn btn-success w-100" data-bs-dismiss="modal">
								Ok
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal" id="testMailFailed" tabindex="-1">
	<div class="modal-dialog modal-sm" role="document">
		<div class="modal-content">
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			<div class="modal-status bg-danger"></div>
			<div class="modal-body text-center py-4">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
					<path stroke="none" d="M0 0h24v24H0z" fill="none" />
					<path d="M12 9v2m0 4v.01" />
					<path d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75" />
				</svg>
				<h3 id="error_textsomethingwentwrong"></h3>
				<div class="text-secondary" id="error_textdata"></div>
			</div>
			<div class="modal-footer">
				<div class="w-100">
					<div class="row">
						<div class="col">
							<a href="#" class="btn btn-danger w-100" data-bs-dismiss="modal">Ok</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.7.2/tinymce.min.js" integrity="sha512-AHsE0IVoihNpGako20z2Tsgg77r5h9VS20XIKa+ZZ8WzzXxdbiUszgVUmXqpUE8GVUEQ88BKQqtlB/xKIY3tUg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
            $('#testMail').click(function() {
                $('#testMail').attr('disabled', true)
                $('#testMail').html('Sending...')
                $.ajax({
                    url: "{{ route('admin.settings.email.test') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        mail_username: $('input[name="mail_username"]').val(),
                        mail_password: $('input[name="mail_password"]').val(),
                        mail_host: $('input[name="mail_host"]').val(),
                        mail_port: $('input[name="mail_port"]').val(),
                        mail_from_address: $('input[name="mail_from_address"]').val(),
                        mail_from_name: $('input[name="mail_from_name"]').val(),
                        mail_encryption: $('input[name="mail_encryption"]').val(),
                    },
                    success: function(data) {
                        if (data.success) {
							$("#testMailSuccess").modal('show');
                        } else {
                            var somethingwentwrong = ('Something went wrong!');
							var data = (data.error);
							$("#testMailFailed").modal('show');
							$("#error_textsomethingwentwrong").html(somethingwentwrong);
							$("#error_textdata").html(data);
                        }
                        $('#testMail').attr('disabled', false)
                        $('#testMail').html('Try Again')
                    }
                }).catch(function(error) {
                    console.log(error)
					var somethingwentwrong = ('Something went wrong!');
					var data = (error.responseJSON.error);
					$("#testMailFailed").modal('show');
					$("#error_textsomethingwentwrong").html(somethingwentwrong);
					$("#error_textdata").html(data);
                    $('#testMail').attr('disabled', false)
                    $('#testMail').html('Try Again')
                });
            });
 
		  // @formatter:off
		  document.addEventListener("DOMContentLoaded", function () {
			let options = {
			  selector: '#textarea',
			  height: 300,
			  menubar: false,
			  statusbar: false,
			  plugins: [
				'advlist autolink lists link image charmap print preview anchor',
				'searchreplace visualblocks code fullscreen',
				'insertdatetime media table paste code help wordcount'
			  ],
			  toolbar: 'undo redo | formatselect | ' +
				'bold italic | alignleft aligncenter ' +
				'alignright alignjustify | bullist numlist outdent indent | ' +
				'removeformat',
			  content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; font-size: 14px; -webkit-font-smoothing: antialiased; }'
			}
			if (localStorage.getItem("tablerTheme") === 'dark') {
			  options.skin = 'oxide-dark';
			  options.content_css = 'dark';
			}
			tinyMCE.init(options);
		  })
		  // @formatter:on
		</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.7.2/tinymce.min.js" integrity="sha512-AHsE0IVoihNpGako20z2Tsgg77r5h9VS20XIKa+ZZ8WzzXxdbiUszgVUmXqpUE8GVUEQ88BKQqtlB/xKIY3tUg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</x-admin-layout>
