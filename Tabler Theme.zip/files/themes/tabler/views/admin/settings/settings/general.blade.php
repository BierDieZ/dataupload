 <div class="hidden mt-3" id="tab-general">
    <form method="POST" enctype="multipart/form-data" class="mb-3" action="{{ route('admin.settings.general') }}">
        @csrf
         <div class="card-body">
			<div class="row">
				<div class="col-sm-12">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<x-input name="app_name" id="app_name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ config('settings::app_name') }}" required  />
						</div>
						<div class="col-md-6 col-sm-12">
							<x-input name="app_logo" id="app_logo" label="{{ __('Logo') }}" type="file" accept="image/*"  />
						</div>
						<div class="col-md-6 col-sm-12">
							<x-input type="select" name="timezone" id="timezone" label="{{ __('Timezone') }}" required>
							@foreach ($timezones as $timezone)
									<option value="{{ $timezone }}" {{ $timezone == config('settings::timezone') ? 'selected' : '' }}>
										{{ $timezone }}</option>
								@endforeach
							</x-input>
						</div>
						<div class="col-md-6 col-sm-12">
							<x-input type="select" name="sidebar" id="sidebar" label="{{ __('Menu display style') }}" required>
								<option value="0" {{ config('settings::sidebar') == 0 ? 'selected' : '' }}>{{ __('Topbar') }}</option>
								<option value="1" {{ config('settings::sidebar') == 1 ? 'selected' : '' }}>{{ __('Sidebar') }}</option>
							</x-input>
						</div>
						<div class="col-sm-12">
							<textarea id="home_page_text" name="home_page_text" type="text" placeholder="{{ __('Home Page Text') }}" value="{{ old('description') }}" novalidate >{{ config('settings::home_page_text') }}</textarea>
							<script>
							  // @formatter:off
							  document.addEventListener("DOMContentLoaded", function () {
								let options = {
								  selector: '#home_page_text',
								  height: 300,
								  menubar: false,
								  statusbar: false,
								  plugins: [
									'advlist autolink lists link image charmap print preview anchor',
									'searchreplace visualblocks code fullscreen',
									'insertdatetime media table paste code help wordcount'
								  ],
								  toolbar: 'undo redo | formatselect | ' +
									'bold italic backcolor | alignleft aligncenter ' +
									'alignright alignjustify | bullist numlist outdent indent | ' +
									'removeformat',
								  content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; font-size: 14px; -webkit-font-smoothing: antialiased; }'
								}
								if (localStorage.getItem("tablerTheme") === 'dark') {
								  options.skin = 'oxide-dark';
								  options.content_css = 'dark';
								}
								tinyMCE.init(options);
							  })
							  // @formatter:on
							</script>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
								<div class="hr-text">
									<span>{{ __('Orders') }}</span>
								</div>
									<x-input type="number" name="remove_unpaid_order_after" id="remove_unpaid_order_after" label="{{ __('Days after which an unpaid server will remove itself') }}" value="{{ config('settings::remove_unpaid_order_after') }}" />
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
									<div class="hr-text">
										<span>{{ __('Currency') }}</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-6 col-sm-12">
									<x-input type="text" name="currency_sign" id="currency_sign" label="{{ __('Currency Sign') }}" value="{{ config('settings::currency_sign') }}" />
								</div>
								<div class="col-lg-4 col-md-6 col-sm-12">
									<x-input type="text" name="currency" id="currency" label="{{ __('Currency Code') }}" value="{{ config('settings::currency') }}" />
								</div>
								<div class="col-lg-4 col-md-6 col-sm-12">
									<x-input type="select" name="currency_position" id="currency_position" label="{{ __('Currency Position') }}" required>
										<option value="left" {{ config('settings::currency_position') == 'left' ? 'selected' : '' }}>{{ __('Left') }}</option>
										<option value="right" {{ config('settings::currency_position') == 'right' ? 'selected' : '' }}>{{ __('Right') }}</option>
									</x-input>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
									<div class="hr-text">
										<span>{{ __('Language') }}</span>
									</div>
								</div>
								<div class="col-md-8 col-sm-12">
									<x-input type="select" name="language" id="language" label="{{ __('Language') }}" required>
										@foreach ($languages as $language)
											<option value="{{ $language }}" {{ $language == config('settings::language') ? 'selected' : '' }}> {{ $language }}</option>
										@endforeach
									</x-input>
								</div>
								<div class="col-md-4 col-sm-12 mt-2" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('If enabled, the language will be automatically set to the language of the browser.') }}">
									<x-input type="checkbox" id="allow_auto_lang" name="allow_auto_lang" value="1" label="{{ __('Allow Auto Language') }}" :checked="config('settings::allow_auto_lang')"  />
									 
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
									<div class="hr-text">
										<span>{{ __('SEO') }}</span>
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<x-input type="text" name="seo_title" id="seo_title" label="{{ __('Seo Title') }}" value="{{ config('settings::seo_title') }}" />
								</div>
								<div class="col-md-6 col-sm-12">
									<x-input type="text" name="seo_description" id="seo_description" label="{{ __('Seo Description') }}" value="{{ config('settings::seo_description') }}" />
								</div>
								<div class="col-md-8 col-sm-12">
									<x-input type="text" name="seo_keywords" id="seo_keywords" label="{{ __('Seo Keywords (separate with comma)') }}" value="{{ config('settings::seo_keywords') }}"  />
								</div>
								<div class="col-md-4 col-sm-12 mt-2" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('If enabled, the language will be automatically set to the language of the browser.') }}">
									<x-input type="checkbox" id="seo_twitter_card" name="seo_twitter_card" label="{{ __('Seo Twitter Card') }}" :checked="config('settings::seo_twitter_card')"  />
									<div class="relative m-4 group">
										<input type="checkbox" class="form-input w-fit peer @error('allow_auto_lang') is-invalid @enderror" placeholder=" " name="allow_auto_lang" value="1" {{ config('settings::allow_auto_lang') ? 'checked' : '' }} data-popover-target="language"/>
										<label class="form-label" style="position: unset;"  >{{ __('Allow Auto Language') }}</label>
										<div id="language" role="tooltip" data-popover class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
											{{ __('If enabled, the language will be automatically set to the language of the browser.') }}
											<div data-popper-arrow></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
        <div class="card-footer text-end">   
        <button class="btn btn-outline-green ms-auto">{{ __('Submit') }}</button>
		</div>
    </form>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.7.2/tinymce.min.js" integrity="sha512-AHsE0IVoihNpGako20z2Tsgg77r5h9VS20XIKa+ZZ8WzzXxdbiUszgVUmXqpUE8GVUEQ88BKQqtlB/xKIY3tUg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
