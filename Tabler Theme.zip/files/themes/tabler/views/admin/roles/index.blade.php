<x-admin-layout title="{{ __('Roles') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Roles') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Clients') }}</h3>
				<div class="col-auto ms-auto d-print-none">
					<a class="btn btn-outline-green" href="{{ route('admin.roles.create') }}">{{ __('Create') }}</a>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table card-table table-vcenter text-nowrap datatable">
					<thead>
						<tr>
							<th>{{ __('ID') }}</th>
							<th>{{ __('Name') }}</th>
							<th>{{ __('Created At') }}</th>
							<th class="w-1">{{ __('Actions') }}</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($roles as $role)
							<tr>
								<td data-label="{{ __('ID') }}">{{ $role->id }}</td>
								<td data-label="{{ __('Name') }}">{{ $role->name }}</td>
								<td data-label="{{ __('Created') }}"><span class="badge bg-info text-white"> {{ $role->created_at }}</span></td>
								<td data-label="{{ __('Actions') }}">
									<a href="{{ route('admin.roles.edit', $role->id) }}" class="btn btn-outline-black">
										{{ __('Edit') }}
									</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
 
</x-admin-layout>
