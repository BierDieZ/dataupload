<x-admin-layout title="{{ __('Creating a new role') }}">
<div class="row">
	<div class="col-sm-12 mb-2">
		<div class="page-pretitle">
			{{ __('Creating a new role') }}
		</div>
		<h2 class="page-title">
			 
		</h2>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">{{ __('Creating a new role') }}</h3>
			</div>
			<form action="{{ route('admin.roles.store') }}" method="POST">
			@csrf
				<div class="card-body">
					<div class="row">
						<div class="col-md-3 col-sm-12">
							<div class="row">
								<div class="col-sm-12">
									<x-input name="name" id="name" label="{{ __('Name') }}" type="text" placeholder="{{ __('Name') }}" value="{{ old('name') }}" required  />
								</div>
							</div>
						</div>
						<div class="col-md-9 col-sm-12">
							<div class="row">
							@foreach ($permissions as $permission => $value)
							@if($permission == 'ADMINISTRATOR') @continue @endif
								<div class="col-lg-4 col-md-6 col-sm-6">
									<x-input type="checkbox" name="permissions[]" id="permissions" value="{{ $permission }}" label="{{ $permission }}" :checked="old('permissions') ? in_array($permission, old('permissions')) : null" />	
								</div>
							@endforeach
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer text-end">
					<button type="submit" class="btn btn-outline-green">{{ __('Save') }}</button>
				</div>
			</form>
		</div>
	</div>
</div>
</x-admin-layout>
