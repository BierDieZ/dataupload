<div class="modal modal-blur fade" id=@isset($id)"{{ $id }}" @else "defaultModal"  @endisset tabindex="-1" >
<div class="modal-dialog @isset($class) {{ $class }} @endisset modal-dialog-centered "   role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">@isset($title){{ $title }}@endisset</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
{{ $slot }}
</div>
@isset($footer)
<div class="modal-footer">
{{ $footer }}
@endisset
</div>
</div>
</div>
</div>