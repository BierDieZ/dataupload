@if(config('settings::theme:organize-footer-links-checkbox') == 0)
<div class="@if (config('settings::sidebar') == 1) container-fluid @else container-xl @endif ">
	<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
    <div class="col-md-4 d-flex align-items-center">
		<span class="mb-md-0 text-muted">&copy; {{ date('Y') }} -
			<a href="{{ route('index') }}" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
					{{ config('app.name', 'Paymenter') }}	
			</a>
		</span>
    </div>
	 
    <ul class="nav col-md-8 justify-content-end  list-inline list-inline-dots d-flex">
		@if(config('settings::theme:footer-credits-checkbox') == 1)
		<li class="list-inline-item">
			<a href="https://tabler.io/" target="_blank" rel="noopener" class="text-decoration-none">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon text-brown icon-filled icon-inline icon-tabler icon-tabler-cup" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
				   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
				   <path d="M5 11h14v-3h-14z"></path>
				   <path d="M17.5 11l-1.5 10h-8l-1.5 -10"></path>
				   <path d="M6 8v-1a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v1"></path>
				   <path d="M15 5v-2"></path>
				</svg>
				Tabler
			</a>
		</li>
		<li class="list-inline-item">
			<a href="https://paymenter.org/" target="_blank" rel="noopener" class="text-decoration-none">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon text-pink icon-filled icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" /></svg>
				Paymenter
			</a>
		</li>
		@endif
	@if(config('settings::theme:footer-custom-links-checkbox') == 1)
		@if(config('settings::theme:custom-link-one-checkbox') == 1)
		<li class="list-inline-item">
			<a href="{{ config('settings::theme:custom-link-one-url') }}" @if(config('settings::theme:custom-link-one-openNewWindow-checkbox') == 1) target="_blank" @endif rel="noopener" class="text-decoration-none">
				{{ config('settings::theme:custom-link-one-title') }}
			</a>
		</li>
		@endif
		@if(config('settings::theme:custom-link-two-checkbox') == 1)
		<li class="list-inline-item">
			<a href="{{ config('settings::theme:custom-link-two-url') }}" @if(config('settings::theme:custom-link-two-openNewWindow-checkbox') == 1) target="_blank" @endif rel="noopener" class="text-decoration-none">
				{{ config('settings::theme:custom-link-two-title') }}
			</a>
		</li>
		@endif
		@if(config('settings::theme:custom-link-three-checkbox') == 1)
		<li class="list-inline-item">
			<a href="{{ config('settings::theme:custom-link-three-url') }}" @if(config('settings::theme:custom-link-three-openNewWindow-checkbox') == 1) target="_blank" @endif rel="noopener" class="text-decoration-none">
				{{ config('settings::theme:custom-link-three-title') }}
			</a>
		</li>
		@endif
		@if(config('settings::theme:custom-link-four-checkbox') == 1)
		<li class="list-inline-item">
			<a href="{{ config('settings::theme:custom-link-four-url') }}" @if(config('settings::theme:custom-link-four-openNewWindow-checkbox') == 1) target="_blank" @endif rel="noopener" class="text-decoration-none">
				{{ config('settings::theme:custom-link-four-title') }}
			</a>
		</li>
		@endif
	@endif
    </ul>
	 
	 
  </footer>
</div>
@else
<x-footer-organized />	
@endif
</div>
</div>
 
<script src="/public/tabler/libs/apexcharts/dist/apexcharts.min.js?1692870487" defer></script>
<script src="/public/tabler/libs/jsvectormap/dist/js/jsvectormap.min.js?1692870487" defer></script>
<script src="/public/tabler/libs/jsvectormap/dist/maps/world.js?1692870487" defer></script>
<script src="/public/tabler/libs/jsvectormap/dist/maps/world-merc.js?1692870487" defer></script>
<script src="/public/tabler/js/tabler.min.js?1692870487" defer></script>
<script src="/public/tabler/js/demo.min.js?1692870487" defer></script>