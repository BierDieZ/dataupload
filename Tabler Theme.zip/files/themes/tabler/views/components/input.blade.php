@if ($type == 'checkbox')
<div @isset($class) class={{ $class }} @endisset>
<label class="form-check form-check-inline mt-2">
<input type="checkbox" id="{{ $id ?? $name }}" class="form-check-input"
@isset($value) value="{{ $value }}" @endisset
@isset($checked) {{ $checked ? 'checked' : '' }} @endisset
name="{{ $name }}"
autocomplete="@isset($autocomplete) {{ $autocomplete }} @else {{ $type }} @endisset"
@isset($disabled) {{ $disabled ? 'disabled' : '' }} @endisset
class="disabled"
@isset($required) {{ $required ? 'required' : '' }} @endisset >
@isset($label)
<span for="{{ $id ?? $name }}" class="form-check-label">{!! $label !!}</span>
@endisset
</label>
</div>
 
@elseif($type == 'color')
    <div @isset($class) class={{ $class }} @endisset>
        {{ $slot }}
        @isset($label)
            <label for="{{ $id ?? $name }}" class="text-sm text-secondary-600">{!! $label !!}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <input type={{ $type }}
                @isset($placeholder) placeholder={{ $placeholder }} @endisset
                name={{ $name }}
                autocomplete="@isset($autocomplete) {{ $autocomplete }} @else {{ $type }} @endisset"
                @isset($value) value={{ $value }} @else value="{{ old($name) }}" @endisset
                id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="bg-secondary-200 text-secondary-800 font-medium rounded-md placeholder-secondary-500 outline-none w-full border focus:ring-2 focus:ring-offset-2 ring-offset-secondary-50 dark:ring-offset-secondary-100 duration-300
            @error($name) border-danger-300 focus:border-danger-400 focus:ring-danger-300 @else border-secondary-300 focus:border-secondary-400 focus:ring-primary-400 @enderror">
        </div>
        @error($name)
            <label for="{{ $id ?? $name }}" class="text-sm text-danger-300">{{ $message }}</label>
        @enderror
    </div>
@elseif($type == 'select')
    <div @isset($class) class="{{ $class }}" @endisset>
       <div class="form-floating mb-3">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <select {{ $attributes->except('class') }} id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-select
            @error($name) is-invalid @enderror
            @isset($icon) pl-10 pr-4 @else px-4 @endisset">
                {{ $slot }}
            </select>
			  @isset($label)
				<label for="{{ $id ?? $name }}" class="form-check-label">{!! $label !!}</label>
			@endisset
        </div>
         @error($name)
             <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
@elseif($type == 'textarea')
    <div @isset($class) class="{{ $class }}" @endisset>
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{!! $label !!}</label>
        @endisset
            <textarea {{ $attributes->except('class') }} id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-control
            @error($name) is-invalid @else  @enderror">{{ $slot }}</textarea>
        
        @error($name)
            <label for="{{ $id ?? $name }}" class="form-label">{{ $message }}</label>
        @enderror
    </div>
@else
    <div @isset($class) class="{{ $class }}" @endisset>
        <div class="form-floating mb-3"> 
          {{ $slot }}
            <input type={{ $type }} {{ $attributes->except('class') }} 
				@isset($value) value="{{ $value }}" @else value="{{ old($name) }}" @endisset
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-control form-floating mb-3
				@error($name) is-invalid @else  @enderror">
          @isset($label)
            <label for="{{ $id ?? $name }}" >{{ $label }}</label>
        @endisset
		
		</div>
        @error($name)
             <div class="invalid-feedback">{{ $message }}</div>
        @enderror
		
                            
                              
                            
    </div>
@endif
 