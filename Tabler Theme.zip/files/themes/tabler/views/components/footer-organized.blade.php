	<footer class="mt-4 footer @if(config('settings::theme:footer-background-transparent-checkbox') == 1) footer-transparent @endif d-print-none">
		<div class="@if (config('settings::sidebar') == 1) container-fluid @else container-xl @endif">
		<div class="row">
			<div class="col-12 col-md-2 col-sm-6 mb-3">
				<h5>{{ __('Products') }}</h5>
				<ul class="nav flex-column">
				@foreach (App\Models\Category::withCount('products')->get() as $category)
					@if ($category->products_count > 0)
					<li class="nav-item mb-2">
						<a href="{{ route('products', $category->slug) }}" class="nav-link p-0 text-muted">{{ $category->name }}</a>
					</li>
					@endif
				@endforeach
				</ul>
			</div>
			@auth
			<div class="col-12 col-md-2 col-sm-6 mb-3">
				<h5>{{ __('My Account') }}</h5>
				<ul class="nav flex-column">
					<li class="nav-item mb-2">
						<a href="{{ route('clients.profile') }}" class="link-secondary text-decoration-none">{{__('Profile')}}</a>
					</li>
					@if (config('settings::credits'))
					<li class="nav-item mb-2">
						<a href="{{ route('clients.credits') }}" class="link-secondary text-decoration-none">{{ __('Credits') }}</a> 
					</li>
					@endif
					@if (Auth::user()->has('ADMINISTRATOR'))
					<li class="nav-item mb-2">
						<a href="{{ route('clients.api.index') }}" class="link-secondary text-decoration-none">{{ __('Account API') }}</a>	
					</li>
					@endif
					@if (config('settings::affiliate'))
					<li class="nav-item mb-2">
						<a href="{{ route('clients.affiliate') }}" class="link-secondary text-decoration-none">{{ __('Affiliate') }}</a> 
					</li>
					@endif
				</ul>
			</div>
			@else
			<div class="col-12 col-md-2 col-sm-6 mb-3">
				<h5>{{ __('Account') }}</h5>
				<ul class="nav flex-column">
					<li class="nav-item mb-2">
						<a href="{{ route('login') }}" class="link-secondary text-decoration-none">{{ __('Log In') }}</a>
					</li>
					<li class="nav-item mb-2">
						<a href="{{ route('password.request') }}" class="link-secondary text-decoration-none">{{ __('Forgot Password?') }}</a>
					</li>
					<li class="nav-item mb-2">
						<a href="{{ route('register') }}" class="link-secondary text-decoration-none">{{ __('Register') }} </a>
					</li>
				</ul>
			</div>
			@endauth
			@if(config('settings::theme:footer-custom-links-checkbox') == 1)
			<div class="col-12 col-md-2 col-sm-6 mb-3">
				<h5>{{ __('Other Links') }}</h5>
				<ul class="nav flex-column">
					@if(config('settings::theme:custom-link-one-checkbox') == 1)
					<li class="nav-item mb-2">
						<a href="{{ config('settings::theme:custom-link-one-url') }}" @if(config('settings::theme:custom-link-one-openNewWindow-checkbox') == 1) target="_blank" @endif class="link-secondary text-decoration-none" rel="noopener">
						{{ config('settings::theme:custom-link-one-title') }}
						</a>
					</li>
					@endif
					@if(config('settings::theme:custom-link-two-checkbox') == 1)
					<li class="nav-item mb-2">
						<a href="{{ config('settings::theme:custom-link-two-url') }}" @if(config('settings::theme:custom-link-two-openNewWindow-checkbox') == 1) target="_blank" @endif class="link-secondary text-decoration-none" rel="noopener">
						{{ config('settings::theme:custom-link-two-title') }}
						</a>
					</li>
					@endif
					@if(config('settings::theme:custom-link-three-checkbox') == 1)
					<li class="nav-item mb-2">
						<a href="{{ config('settings::theme:custom-link-three-url') }}" @if(config('settings::theme:custom-link-three-openNewWindow-checkbox') == 1) target="_blank" @endif class="link-secondary text-decoration-none" rel="noopener">
						{{ config('settings::theme:custom-link-three-title') }}
						</a>
					</li>
					@endif
					@if(config('settings::theme:custom-link-four-checkbox') == 1)
					<li class="nav-item mb-2">
						<a href="{{ config('settings::theme:custom-link-four-url') }}" @if(config('settings::theme:custom-link-four-openNewWindow-checkbox') == 1) target="_blank" @endif class="link-secondary text-decoration-none" rel="noopener">
						{{ config('settings::theme:custom-link-four-title') }}
						</a>
					</li>
					@endif
				</ul>
			</div>
			@endif
			@if(config('settings::theme:footer-socialmedia-checkbox') == 1)
			<div class="col-12 col-md-2 col-sm-6 mb-3">
				<h5>{{ __('Socialmedia') }}</h5>
				<ul class="nav flex-column">
					<li class="nav-item">
						@if(config('settings::theme:socialmedia-twitter-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-twitter-url') }}" target="_blank" class="btn btn-twitter btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="Twitter (X)">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter-filled" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14.058 3.41c-1.807 .767 -2.995 2.453 -3.056 4.38l-.002 .182l-.243 -.023c-2.392 -.269 -4.498 -1.512 -5.944 -3.531a1 1 0 0 0 -1.685 .092l-.097 .186l-.049 .099c-.719 1.485 -1.19 3.29 -1.017 5.203l.03 .273c.283 2.263 1.5 4.215 3.779 5.679l.173 .107l-.081 .043c-1.315 .663 -2.518 .952 -3.827 .9c-1.056 -.04 -1.446 1.372 -.518 1.878c3.598 1.961 7.461 2.566 10.792 1.6c4.06 -1.18 7.152 -4.223 8.335 -8.433l.127 -.495c.238 -.993 .372 -2.006 .401 -3.024l.003 -.332l.393 -.779l.44 -.862l.214 -.434l.118 -.247c.265 -.565 .456 -1.033 .574 -1.43l.014 -.056l.008 -.018c.22 -.593 -.166 -1.358 -.941 -1.358l-.122 .007a.997 .997 0 0 0 -.231 .057l-.086 .038a7.46 7.46 0 0 1 -.88 .36l-.356 .115l-.271 .08l-.772 .214c-1.336 -1.118 -3.144 -1.254 -5.012 -.554l-.211 .084z" stroke-width="0" fill="currentColor" /></svg>
						</a>
						@endif
						@if(config('settings::theme:socialmedia-twitter-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-facebook-url') }}" target="_blank" class="btn btn-facebook btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="Facebook">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" /></svg>
						</a>
						@endif
						@if(config('settings::theme:socialmedia-instagram-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-instagram-url') }}" target="_blank" class="btn btn-instagram btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="Instagram">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" /><path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" /><path d="M16.5 7.5l0 .01" /></svg>
						</a>
						@endif
						@if(config('settings::theme:socialmedia-linkedin-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-linkedin-url') }}" target="_blank" class="btn btn-linkedin btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="Linkedin">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-linkedin" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z" /><path d="M8 11l0 5" /><path d="M8 8l0 .01" /><path d="M12 16l0 -5" /><path d="M16 16v-3a2 2 0 0 0 -4 0" /></svg>
						</a>
						@endif
						@if(config('settings::theme:socialmedia-discord-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-discord-url') }}" target="_blank" class="btn btn-discord btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="Discord">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-discord" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M8 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" /><path d="M14 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" /><path d="M15.5 17c0 1 1.5 3 2 3c1.5 0 2.833 -1.667 3.5 -3c.667 -1.667 .5 -5.833 -1.5 -11.5c-1.457 -1.015 -3 -1.34 -4.5 -1.5l-.972 1.923a11.913 11.913 0 0 0 -4.053 0l-.975 -1.923c-1.5 .16 -3.043 .485 -4.5 1.5c-2 5.667 -2.167 9.833 -1.5 11.5c.667 1.333 2 3 3.5 3c.5 0 2 -2 2 -3" /><path d="M7 16.5c3.5 1 6.5 1 10 0" /></svg>
						</a>
						@endif
						@if(config('settings::theme:socialmedia-youtube-checkbox') == 1)
						<a href="{{ config('settings::theme:socialmedia-youtube-url') }}" target="_blank" class="btn btn-youtube btn-icon mb-1" rel="noopener" data-bs-toggle="tooltip" data-bs-placement="top" title="YouTube">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-youtube" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M2 8a4 4 0 0 1 4 -4h12a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-12a4 4 0 0 1 -4 -4v-8z" /><path d="M10 9l5 3l-5 3z" /></svg>
						</a>
						@endif
					</li>
				</ul>
			</div>
			@endif
 
		</div>
		<div class="pt-3 border-top">
			<div class="row">
				<div class="col-md-10">
					<p>&copy; {{ date('Y') }} {{ config('app.name', 'Paymenter') }}. {{ config('settings::theme:footer-description-textarea') }}</p>
				</div>
				@if(config('settings::theme:footer-credits-checkbox') == 1)
				<div class="col-md-2">
					<div class="row d-flex justify-content-between">
						<div class="col-6">
							<a href="https://tabler.io/" target="_blank" class="text-decoration-none" rel="noopener">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon text-grey icon-filled icon-inline icon-tabler icon-tabler-cup" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
								   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
								   <path d="M5 11h14v-3h-14z"></path>
								   <path d="M17.5 11l-1.5 10h-8l-1.5 -10"></path>
								   <path d="M6 8v-1a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v1"></path>
								   <path d="M15 5v-2"></path>
								</svg>
								Tabler
							</a>
						</div>
						<div class="col-6">
							<a href="https://paymenter.org/" target="_blank" class=" text-decoration-none" rel="noopener">
								<svg xmlns="http://www.w3.org/2000/svg" class="icon text-pink icon-filled icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" /></svg>
								Paymenter
							</a>
						</div>
					</div>
				</div>
				@endif
			</div>
		</div>
    </div>
  </footer>
 