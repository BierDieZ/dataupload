@props(['amount' => null, 'showFree' => false])
@if ($amount == 0 && $showFree)
	{{ __('Free') }}
@else
	@if (config('settings::currency_position') == 'left') {{ config('settings::currency_sign') }}{{ number_format($amount, 2) }} @endif
	 
	@if (config('settings::currency_position') == 'right'){{ number_format($amount, 2) }}{{ config('settings::currency_sign') }}@endif
@endif
