<div class="bg-black py-3 text-white border-bottom d-print-none">
	<div class="container-fluid">
		<div class="text-center">
			<div>
			{{ config('settings::theme:custom-notification-topbar-text') }}
			</div>
		</div>
	</div>
</div>