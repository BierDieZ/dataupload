@if(Auth::check() && Auth::user()->has('ADMINISTRATOR'))
    @if(config('app.commit') && config('app.version') === 'beta' && config('app.commit') !== config('settings::latest_version'))
		<div class="modal modal-blur fade" id="modal_update" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-md modal-dialog-centered" role="document">
				<div class="modal-content">
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					<div class="modal-status  bg-danger"></div>
					<div class="modal-body text-center py-4">
						<svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10.24 3.957l-8.422 14.06a1.989 1.989 0 0 0 1.7 2.983h16.845a1.989 1.989 0 0 0 1.7 -2.983l-8.423 -14.06a1.989 1.989 0 0 0 -3.4 0z" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>
						<h3>{{ __('Update available') }}</h3>
						<div class="text-secondary mb-4">{{ __('To download the beta version of Paymenter run:') }}</div>
						<kbd>php artisan p:upgrade --url https://api.paymenter.org/beta</kbd>
					</div>
				</div>
			</div>
		</div>
    @endif
	  @if((config('app.version') == 'beta' && config('app.commit') !== config('settings::latest_version')) || (config('app.version') !== 'beta' && config('app.version') !== 'development' && config('app.version') !== config('settings::latest_version')))
	<div id="update_panel" class="alert alert-danger" role="alert">
		<div class="d-flex">
			<div>
				<svg xmlns="http://www.w3.org/2000/svg" class="icon alert-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0" /><path d="M12 8v4" /><path d="M12 16h.01" /></svg>
			</div>
			<div>
				<h4 class="alert-title">{{ __('Update available') }} <b>({{ config('settings::latest_version') }})</b></h4>
				<div class="text-secondary">
				 @if(config('app.commit') && config('app.version') === 'beta')
					{{ __('A new paymenter beta version is available for download.') }}
				@else
					{{ __('A new paymenter stable version is available for download.') }}
				@endif
				<a
                                    @if(config('app.commit') && config('app.version') === 'beta')
                                        data-bs-toggle="modal" data-bs-target="#modal_update"
                                    @else
                                        href="https://paymenter.org/docs/how-to-update"
                                        target="_blank"
                                    @endif
                                    class="cursor-pointer btn ms-auto"
                                >
                                    {{ __('Update') }}
                                </a>
				</div>
			</div>
		</div>
	</div>  
 
        <script>
            let expirationDate = localStorage.getItem('update_panel_expiration');
            let currentTime = new Date();
        
            if (!expirationDate || new Date(expirationDate) < currentTime) {
                document.getElementById('update_panel').style.display = 'flex';
            
                document.querySelector('#close_update_panel').addEventListener('click', function() {
                    document.getElementById('update_panel').style.display = 'none';
                
                    let date = new Date(currentTime.getTime() + (72 * 60 * 60 * 1000));
                    localStorage.setItem('update_panel_expiration', date.toISOString());
                });
            }
        </script>
    @endif
@endif
