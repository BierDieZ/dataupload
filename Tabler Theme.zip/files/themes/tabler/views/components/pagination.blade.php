@props(['paginator'])
@if ($paginator->hasPages())
<ul class="pagination ">
	 
	@if ($paginator->onFirstPage())
	<li class="page-item disabled">
		<a class="page-link" href="#" tabindex="-1" aria-disabled="true">
		<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>
		Previous
		</a>
	</li>
	@else
	<li class="page-item">
		<a class="page-link" href="{{ $paginator->previousPageUrl() }}">
		<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>
		Previous
		</a>
	</li>
	@endif
	 @for ($i = 1; $i <= $paginator->lastPage(); $i++)
		{{-- "Three Dots" Separator --}}
		@if ($paginator->currentPage() > 3 && $i === 2)
			<li class="page-item"><a class="page-link" href="#">...</a></li>
		@endif

		{{-- Array Of Links --}}
		@if ($i == $paginator->currentPage())
			<li class="page-item active"><a class="page-link" href="#">{{ $i }}</a></li>
		@elseif($i === $paginator->currentPage() + 1 || $i === $paginator->currentPage() + 2)
			<li class="page-item"><a class="page-link" href="{{ $paginator->url($i) }}">{{ $i }}</a></li>
		@elseif($i === $paginator->currentPage() - 1 || $i === $paginator->currentPage() - 2)
		<li class="page-item"><a class="page-link" href="{{ $paginator->url($i) }}">{{ $i }}</a></li>
		@endif

		{{-- "Three Dots" Separator --}}
		@if ($paginator->currentPage() < $paginator->lastPage() - 2 && $i === $paginator->lastPage() - 1)
			<li class="page-item"><a class="page-link" href="#">...</a></li>
		@endif
	@endfor
	@if ($paginator->hasMorePages())
		<li class="page-item">
			<a class="page-link" href="{{ $paginator->nextPageUrl() }}">
			next
			<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>
			</a>
		</li>
	@else
	<li class="page-item disabled">
		<a class="page-link" href="#" tabindex="-1" aria-disabled="true">
		next
		<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>
		 
		</a>
	</li>
	@endif		
	 
</ul>
@endif
