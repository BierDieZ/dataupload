@if (config('settings::app_logo'))
    <img src="{{ asset(config('settings::app_logo')) }}" width="110" height="32" alt="{{ config('settings::app_name') }}" class="navbar-brand-image" />
@else
    <img src="/img/logo.png" alt="Paymenter" class="navbar-brand-image" >
@endif
