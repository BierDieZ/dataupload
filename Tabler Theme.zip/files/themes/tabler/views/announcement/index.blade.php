<x-app-layout title="{{ __('Announcements') }}">
	<div class="row g-2 align-items-center mb-2">
		<div class="col">
			<h2 class="page-title">{{ __('Announcements') }}</h2>
		</div>
	</div>
	 @if ($announcements->count() > 0)
	<div class="row row-cards">
		@foreach ($announcements->sortByDesc('created_at') as $announcement)
		<div class="col-lg-4 col-md-4 col-sm-12">
			<div class="card ">
				<div class="card-header">
					<h3 class="card-title">{{ $announcement->title }}</h3>
				</div>
			<div class="card-body">
			<p class="text-secondary">
				<p>@markdownify(substr($announcement->announcement, 0, 100) . '...')</p>
			</p>
			</div>
				<div class="card-footer">
					<div class="row align-items-center">
					<div class="col-auto text-secondary">{{ __('Published') }} {{ $announcement->created_at->diffForHumans() }}</div>
						<div class="col-auto ms-auto">
							<a href="{{ route('announcements.view', $announcement->id) }}" class="btn btn-primary w-100">{{ __('Read More') }}</a>
						</div>
					</div> 
				</div>
			</div>
		</div>
		@endforeach
	</div>
	@else
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<h3 class="card-title">{{ __('Announcements') }}</h3>
					<div class="text-red">{{ __('Announcement not found!') }}</div>
				</div>
			</div>
		</div>
	</div>
	@endif
</x-app-layout>
