<x-app-layout title="{{ __('Home') }}">
    
    @if (config('settings::home_page_text'))
		<div class="alert alert-info" role="alert">
		  <h4 class="alert-title">Wow! Everything worked!</h4>
		  <div class="text-secondary"> @markdownify(config('settings::home_page_text'))</div>
		</div>
       
    @endif

    @if ($categories->count() > 0)
		 
		<div class="row g-2 align-items-center mb-2">
			<div class="col">
				<h2 class="page-title">{{ __('Categories') }}</h2>
			</div>
		</div>
		<div class="row row-cards mb-2">
		@foreach ($categories as $category)
		 
			@if ($category->products->count() > 0)
			<div class="col-md-4 col-sm-12">
				<div class="card">
					<div class="card-header">
						<h3 class="card-title">{{ $category->name }}</h3>
					</div>
					<div class="card-body">
						<p class="text-secondary">{{ $category->description }}</p>
					</div>
					<div class="card-footer card-footer-transparent">
						<a href="{{ route('products', $category->slug) }}" class="btn btn-primary w-100"> {{ __('Browse Category') }} </a>
					</div>
				</div>
			 </div>
			@endif
			 
        @endforeach
		</div>
    @endif

    @if ($announcements->count() > 0)
		
       		<div class="row g-2 align-items-center mb-2">
				<div class="col">
				<h2 class="page-title">{{ __('Announcements') }}</h2>
				</div>
			</div>
			<div class="row row-cards">
                @foreach ($announcements->sortByDesc('created_at') as $announcement)
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card ">
						<div class="card-header">
							<h3 class="card-title">{{ $announcement->title }}</h3>
						</div>
						<div class="card-body">
							<p class="text-secondary">@markdownify(substr($announcement->announcement, 0, 100) . '...')</p>
						</div>
						<div class="card-footer">
							<div class="row align-items-center">
								<div class="col-auto text-secondary">
									{{ __('Published') }} {{ $announcement->created_at->diffForHumans() }}
								</div>
								<div class="col-auto ms-auto">
									<a href="{{ route('announcements.view', $announcement->id) }}" class="btn btn-primary w-100">{{ __('Read More') }}</a>
								</div>
							</div> 
						</div>
					</div>
				 </div>
                @endforeach
			</div>
    @endif

</x-app-layout>