<x-app-layout>
<div class="page page-center">
	<div class="container container-tight py-4">
        <div class="text-center mb-4">
			<a href="{{ route('index') }}">
				<x-application-logo  />
			</a>
        </div>
        <div class="card card-md">
          <div class="card-body">
            <h2 class="h2 text-center mb-4">{{ __('Login to continue') }}</h2>
            <form method="POST" action="{{ route('login') }}" id="login">
			@csrf
				<div class="mb-3">
					<x-input label="{{ __('Email') }}" type="email" placeholder="{{ __('Email..') }}" required name="email" id="email" />
				</div>
				<div class="mb-2">
					<label class="form-label">
						{{ __('Password') }}
						<span class="form-label-description">
							<a href="{{ route('password.request') }}" class="underline">{{ __('Forgot Password?') }}</a>
						</span>
					</label>
					<x-input label="{{ __('Password') }}" type="password" required placeholder="{{ __('Password') }}" name="password" id="password" />
				</div>
				<div class="mb-2">
					<label class="form-check">
						<input type="checkbox" name="remember" id="remember" class="form-check-input"/>
						<span class="form-check-label">{{ __('Remember me') }}</span>
					</label>
				</div>
				<div class="form-footer">
					<button type="submit" class="btn btn-primary w-100">{{ __('Login') }}</button>
				</div>
			  @if (config('settings::discord_enabled') == 1 ||
                        config('settings::apple_enabled') == 1 ||
                        config('settings::google_enabled') == 1 ||
                        config('settings::github_enabled') == 1)
				<div class="hr-text">{{ __('or') }}</div>
				<div class="card-body">
					<div class="row">
						@if (config('settings::google_enabled') == 1)
						<a href="{{ route('social.login', 'google') }}" class="btn mb-1">
						<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-google" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
						   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
						   <path d="M17.788 5.108a9 9 0 1 0 3.212 6.892h-8"></path>
						</svg>
						{{ __('Sign in with Google') }}
						</a>
						@endif
						@if (config('settings::github_enabled'))
						<a href="{{ route('social.login', 'github') }}" class="btn  mb-1">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon text-github" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 19c-4.3 1.4 -4.3 -2.5 -6 -3m12 5v-3.5c0 -1 .1 -1.4 -.5 -2c2.8 -.3 5.5 -1.4 5.5 -6a4.6 4.6 0 0 0 -1.3 -3.2a4.2 4.2 0 0 0 -.1 -3.2s-1.1 -.3 -3.5 1.3a12.3 12.3 0 0 0 -6.2 0c-2.4 -1.6 -3.5 -1.3 -3.5 -1.3a4.2 4.2 0 0 0 -.1 3.2a4.6 4.6 0 0 0 -1.3 3.2c0 4.6 2.7 5.7 5.5 6c-.6 .6 -.6 1.2 -.5 2v3.5" /></svg>
							{{ __('Sign in with GitHub') }}
						</a>
						@endif
						@if (config('settings::discord_enabled'))
						<a href="{{ route('social.login', 'discord') }}" class="btn  mb-1">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-discord" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							   <path d="M8 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0"></path>
							   <path d="M14 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0"></path>
							   <path d="M15.5 17c0 1 1.5 3 2 3c1.5 0 2.833 -1.667 3.5 -3c.667 -1.667 .5 -5.833 -1.5 -11.5c-1.457 -1.015 -3 -1.34 -4.5 -1.5l-.972 1.923a11.913 11.913 0 0 0 -4.053 0l-.975 -1.923c-1.5 .16 -3.043 .485 -4.5 1.5c-2 5.667 -2.167 9.833 -1.5 11.5c.667 1.333 2 3 3.5 3c.5 0 2 -2 2 -3"></path>
							   <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
							</svg>
							{{ __('Sign in with Discord') }}
						</a>
						@endif
						@if (config('settings::apple_enabled'))
						<a href="{{ route('social.login', 'apple') }}" class="btn mb-1">
							<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-discord" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							   <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							   <path d="M8 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0"></path>
							   <path d="M14 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0"></path>
							   <path d="M15.5 17c0 1 1.5 3 2 3c1.5 0 2.833 -1.667 3.5 -3c.667 -1.667 .5 -5.833 -1.5 -11.5c-1.457 -1.015 -3 -1.34 -4.5 -1.5l-.972 1.923a11.913 11.913 0 0 0 -4.053 0l-.975 -1.923c-1.5 .16 -3.043 .485 -4.5 1.5c-2 5.667 -2.167 9.833 -1.5 11.5c.667 1.333 2 3 3.5 3c.5 0 2 -2 2 -3"></path>
							   <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
							</svg>
							 {{ __('Sign in with Apple') }}
						</a>
						@endif
					</div>
				</div>
                @endif
            </form>
          </div>
        </div>
		<div class="flex items-center justify-center">
			<x-recaptcha form="login" />
		</div>
        <div class="text-center text-secondary mt-3">
        <a href="{{ route('register') }}" tabindex="-1">{{ __('New here? Create an account.') }} </a>
        </div>
    </div>
</div>

</x-app-layout>