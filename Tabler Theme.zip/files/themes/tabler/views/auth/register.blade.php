<x-app-layout title="{{ __('Register') }}">
<div class="page page-center">
      <div class="container container-tight py-4">
        <div class="text-center mb-4">
			<a href="{{ route('index') }}">
				<x-application-logo  />
			</a>
        </div>
        <div class="card card-md">
			<div class="card-body">
				<h2 class="card-title text-center mb-4">{{ __('Make an Account') }} {{ config('app.name', 'Paymenter') }}</h2>
				<form method="POST" action="{{ route('register') }}" id="register">
					@csrf
					<x-input class="mt-3" label="{{ __('First name') }}" type="name" placeholder="{{ __('First name') }}" required name="first_name" id="first_name" icon="ri-user-3-line" />
					<x-input class="mt-3" label="{{ __('Last name') }}" type="name" placeholder="{{ __('Last name') }}" required name="last_name" id="last_name" icon="ri-user-3-line" />
					<x-input class="mt-3" label="{{ __('Email') }}" type="email" placeholder="{{ __('Email') }}" required name="email" id="email" icon="ri-at-line" />
					<x-input type="password" required class="mt-3" label="{{ __('Password') }}" placeholder="{{ __('Password') }}" name="password" id="password" icon="ri-lock-line"/>
					<x-input type="password" required class="mt-3" label="{{ __('Confirm Password') }}" placeholder="{{ __('Confirm Password') }}" name="password_confirmation" id="password-confirm" icon="ri-lock-password-line"/>
					<div class="form-footer">
						<x-recaptcha form="register" />
						<button type="submit" class="btn btn-primary w-100">{{ __('Register') }}</button>
					</div>
				</form>
			</div>
		</div>
		<div class="text-center text-secondary mt-3">
			<a href="{{ route('login') }}" tabindex="-1"> {{ __('Return to Login') }}</a>
		</div>
	</div>
</div>

</x-app-layout>
