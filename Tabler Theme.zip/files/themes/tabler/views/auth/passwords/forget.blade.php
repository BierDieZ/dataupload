<x-app-layout>
 
 <div class="page page-center">
      <div class="container container-tight py-4">
        <div class="text-center mb-4">
			<a href="{{ route('index') }}">
				<img src="/tabler/logo.png" width="110" height="32" alt="{{ config('app.name', 'Paymenter') }}" class="navbar-brand-image" />
			</a>
        </div>
        <form class="card card-md"  method="POST" action="{{ route('password.email') }}" id="forget-password">
		@csrf
          <div class="card-body">
            <h2 class="card-title text-center mb-4">{{ __('Forgot Password') }}</h2>
            <p class="text-secondary mb-4"> {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}</p>
            <div class="mb-3">
              <label class="form-label">Email address</label>
              <input type="email"  name="email" id="email" placeholder="{{ __('Email..') }}" class="form-control" required>
            </div>
            <div class="form-footer">
              <button type="submit" class="btn btn-primary w-100">
                
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 7a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10z" /><path d="M3 7l9 6l9 -6" /></svg>
                {{ __('Email Password Reset Link') }}
              </button>
            </div>
          </div>
        </form>
        <div class="text-center text-secondary mt-3">
			<a href="{{ route('login') }}">{{ __('Return to Login') }}</a>
        </div>
      </div>
    </div>   
</x-app-layout>
