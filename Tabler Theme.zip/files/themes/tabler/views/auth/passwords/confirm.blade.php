<x-app-layout title="{{ __('Confirm Password') }}">
<div class="page page-center">
	<div class="container container-tight py-4">
		<h1 class="text-center mb-4">
			<a href="{{ route('index') }}">
					<x-application-logo  />
					@if(config('settings::theme:website-title-checkbox') == 1)
						{{ config('app.name', 'Paymenter') }}
					@endif
				</a>
		</h1>
		<form method="POST" action="{{ route('password.confirm') }}" id="pw-confirm" class="card card-md">
		  @csrf
			<div class="card-body text-center">
			@error('password')
			<div class="mb-4">
				<div class="alert alert-danger m-0 text-left">
					{{ $message }}
				</div>
			</div>
			@enderror
				<div class="mb-4">
					<p class="text-secondary">{{ __('This is a secure area of the application. Please confirm your password before continuing.') }}</p>
				</div>
				<div class="mb-4">
					<input id="password" type="password"  name="password" class="form-control" required autocomplete="new-password" >
				</div>
				<div class="mb-4">
				<x-recaptcha form="pw-confirm" />
				</div>
				<div>
					<button type="submit" class="btn btn-outline-success w-100">
					 {{ __('Confirm') }}
					</button>
				</div>
			</div>
		</form>
	</div>
</div>
</x-app-layout>
 