<x-guest-layout>
<div class="page page-center">
    <div class="container container-tight py-4">
        <div class="text-center mb-4">
			<a href="{{ route('index') }}">
				<x-application-logo class="w-20 h-20 text-gray-500 fill-current" />
			</a>
        </div>
		<x-auth-session-status class="mb-4" :status="session('status')" />
		<x-auth-validation-errors class="mb-4" :errors="$errors" />
        <form class="card card-md" method="POST" action="{{ route('password.update') }}" id="reset-password">
		@csrf
			<x-input type="hidden" name="token" value="{{ $request->route('token') }}" />
			<div class="card-body">
				<h2 class="card-title text-center mb-4">{{ __('Forgot Password') }}</h2>
				<p class="text-secondary mb-4"> </p>
				<div class="mb-3">
					<x-input name="email" id="email" label="{{ __('Email') }}" type="text" placeholder="{{ __('Email') }}" value="{{ old('email', $request->email) }}" required  />
				</div>
				<div class="mb-3">
					<x-input name="password" id="password" label="{{ __('Password') }}" type="password" placeholder="{{ __('Password') }}" required  />
				</div>
				<div class="mb-3">
					<x-input name="password_confirmation" id="password-confirm" label="{{ __('Confirm Password') }}" type="password" placeholder="{{ __('Confirm Password') }}" required  />
				</div>
				<div class="form-footer">
					<x-recaptcha form="reset-password" />
					<button type="submit" class="btn btn-primary w-100">{{ __('Reset Password') }}</button>
				</div>
			</div>
        </form>
    </div>
</div> 
</x-guest-layout>
