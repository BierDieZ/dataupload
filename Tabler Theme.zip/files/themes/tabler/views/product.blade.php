<x-app-layout description="{{ $category->description ?? null }}" title="{{ $category->name ?? __('Products') }}">
    <x-success />
	<div class="row ">
		<div class="col-sm-12">
			<h2 class="page-title">{{ $category->name }}</h2>
			<p>{{ $category->description }}</p>
		</div>
		<div class="col-sm-12">
			<div class="row">
				<div class="col-lg-3 col-md-4 col-sm-12 mb-4">
					@if ($categories->count() > 0)
					<div class="col-sm-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">{{ __('Categories') }}</h3>
							</div>
							<div class="list-group list-group-flush">
							@foreach ($categories as $categoryItem)
								@if ($categoryItem->products->count() > 0)
								<a href="{{ route('products', $categoryItem->slug) }}" class=" list-group-item list-group-item-action @if ($category->name == $categoryItem->name) active @endif" aria-current="true">
								{{ $categoryItem->name }}
								</a>
								@endif
							@endforeach
							</div>
						</div>
					</div>
					@endif
				</div>
				<div class="col-lg-9 col-md-8 col-sm-12">
					<div class="row">
					@foreach ($category->products()->orderBy('order')->get() as $product)
					<div class="col-lg-4 col-md-6 col-sm-12 mb-4">
						<div class="card card-md">
						@if ($product->image !== 'null')
							<img src="{{ $product->image }}" alt="{{ $product->name }}"
								class="w-14 rounded-md" onerror="removeElement(this);">
						@endif
							<!--future<div class="ribbon bg-green">NEW</div>!-->
							<div class="card-body text-center">
								<div class="text-uppercase text-secondary font-weight-medium">{{ $product->name }}</div>
								<div class="display-5 fw-bold my-3"><x-money :amount="$product->price()" showFree="true" /></div>
								<ul class="list-unstyled lh-lg">
									@markdownify($product->description)
								</ul>
								  @if ($product->stock_enabled && $product->stock <= 0)
									<div class="text-center mt-4">
										<a href="#" class="btn bg-red text-white w-100" disabled>{{ __('Out of stock') }}</a>
									</div>
								@else
									<a href="{{ route('checkout.add', $product->id) }}" class="btn btn-outline-primary w-full">
												Add to cart &nbsp;&nbsp; <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-cart-plus" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 19a2 2 0 1 0 4 0a2 2 0 0 0 -4 0" /><path d="M12.5 17h-6.5v-14h-2" /><path d="M6 5l14 1l-.86 6.017m-2.64 .983h-10.5" /><path d="M16 19h6" /><path d="M19 16v6" /></svg>
											</a>
											
								@endif
							</div>
						</div>
					</div>
					@endforeach
					</div>
				</div>
			</div>
		</div>
	</div>
</x-app-layout>
