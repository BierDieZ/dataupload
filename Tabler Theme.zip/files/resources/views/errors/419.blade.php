<x-app-layout title="419 error">
<div class="page page-center">
<div class="container-tight py-4">
<div class="empty">
<div class="empty-header">419</div>
<p class="empty-title">Page Expired</p>
<p class="empty-subtitle text-secondary">
 The page has expired due to inactivity. Please refresh and try again.
</p>
<div class="empty-action">
<button onclick="location.replace(location.href)" class="btn btn-primary">
Refresh
</button>
</div>
</div>
</div>
</div>
</x-app-layout>
