<x-app-layout title="404 error">
<div class="page page-center">
<div class="container-tight py-4">
<div class="empty">
<div class="empty-header">404</div>
<p class="empty-title">Page not found</p>
<p class="empty-subtitle text-secondary">
We are sorry but the page you are looking for was not found
</p>
</div>
</div>
</div>
</x-app-layout>
