<x-app-layout title="401 error">
<div class="page page-center">
<div class="container-tight py-4">
<div class="empty">
<div class="empty-header">401</div>
<p class="empty-title">Unauthorized</p>
<p class="empty-subtitle text-secondary">
 You are not authorized to access this page.
</p>
</div>
</div>
</div>
</x-app-layout>
