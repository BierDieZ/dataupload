@php
    $categories = \App\Models\Category::whereNull('category_id')->take(5)->get();
    $products = \App\Models\Product::take(5)->get();
    $settings = \App\Models\Setting::all()->keyBy('key');
@endphp

<footer>
    @if(config('settings::theme:sions-footer'))
        <div class="s-background sions-footer">
            @if(config('settings::theme:sions-footer-logo'))
                <div class="sions-footercard sions-footer-logo">
                    <x-application-logo />
                </div>
            @endif

            @if(config('settings::theme:sions-footer-media'))
                <div class="sions-footercard sions-footer-media">
                    <h2 class="s-h2"> {{ config('settings::theme:sions-footer-media-text') }} </h2>
                    <div>
                        @if(isset($settings))
                            <ul>
                                @foreach ($settings as $setting)
                                    @if (str_contains($setting->key, "social") && $setting->value)
                                        @php
                                            $value = last(explode('-', $setting->key))
                                        @endphp
                                        <li>
                                            <i class="ri-{{ $value }}-line"></i>
                                            <a class="s-footerlinks hover:text-secondary-800 duration-300"
                                                href="{{ $setting->value }}">{{ ucfirst($value) }}</a>
                                        </li>
                                    @endif
                                @endforeach
                            </ul>
                        @endif
                    </div>
                </div>
            @endif

            @if(config('settings::theme:sions-footer-categories'))
                <div class="sions-footercard sions-footer-categories">
                    <h2 class="s-h2"> {{ __('Categories') }} </h2>
                    <div>
                        @if($categories->isNotEmpty())
                            <ul>
                                @foreach($categories as $category)
                                    <li>
                                        <a class="s-footerlinks hover:text-secondary-800 duration-300"
                                            href="{{ route('products', $category->slug) }}">{{ $category->name }}</a>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                </div>
            @endif

            @if(config('settings::theme:sions-footer-products'))
                <div class="sions-footercard sions-footer-products">
                    <h2 class="s-h2"> {{ __('Products') }} </h2>
                    <div>
                        @if($products->isNotEmpty())
                            <ul>
                                @foreach($products as $product)
                                    <li>
                                        <a class="s-footerlinks hover:text-secondary-800 duration-300"
                                            href="{{ route('checkout.config', $product->id) }}">{{ $product->name }}</a>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                </div>
            @endif

            @if(config('settings::theme:sions-footer-refer'))
                <div class="sions-footercard sions-footer-refer">
                    <h2 class="s-h2">
                        {{ config('settings::theme:sions-footer-refer-text') }}
                    </h2>
                    <div>
                        @if(isset($settings))
                            <ul>
                                @foreach ($settings as $setting)
                                    @if (str_contains($setting->key, "link") && !str_contains($setting->key, "text") && $setting->value)
                                        @php
                                            $displayTextKey = str_replace('link', 'link-text', $setting->key);
                                            $link = $setting->value;
                                            $displayText = config('settings::' . $displayTextKey);
                                        @endphp

                                        @if ($displayText && $link)
                                            <li>
                                                <a class="s-footerlinks hover:text-secondary-800 duration-300"
                                                    href="{{ $link }}">{{ ucfirst($displayText) }}</a>
                                            </li>
                                        @endif
                                    @endif
                                @endforeach
                            </ul>
                        @endif


                    </div>
                </div>
            @endif
        </div>
    @endif

    @if(config('settings::theme:sions-footer-second'))
        <div class="sions-footer-second text-sm text-center text-secondary-600">
            <a href="https://paymenter.org" target="_blank">
                @if(config('settings::theme:sions-footer-second-text'))
                    {{ config('settings::theme:sions-footer-second-text') }}
                @else
                    Sions-Host.de ❤️ Paymenter &copy; 2022 - {{ date('Y') }}
                @endif
            </a>
        </div>
    @endif
</footer>