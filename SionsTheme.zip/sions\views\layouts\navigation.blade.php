@if(Route::currentRouteName() == 'index')
    <div class="sions-navigation-header">
@else
    <div class="sions-navigation-header-small">
@endif
        <div class="sions-nocontent"></div>

        <nav
            class="sions-navigation-nav bg-secondary-50 dark:bg-secondary-100 dark:border-0 border-b-2 border-secondary-200">
            <div class="max-w-[1650px] mx-auto block md:flex items-center gap-x-10 px-5">
                <div class="flex justify-between md:w-auto w-full items-center">
                    <a href="{{ route('index') }}"
                        class="flex items-center text-secondary-900 font-semibold text-lg py-2 gap-x-2 w-max">
                        <x-application-logo class="w-10" />
                        {{ config('app.name', 'Paymenter') }}
                    </a>
                    <!-- Mobile menu button -->
                    <div class="flex md:hidden">
                        <button type="button" class="button button-secondary-outline" onclick="openMobileMenu()">
                            <i class="ri-menu-line"></i>
                        </button>
                    </div>
                    <script>
                        function openMobileMenu() {
                            document.getElementById("mobile-menu").classList.toggle("hidden");
                            document.getElementById("clientsNavBar").classList.toggle("hidden");
                        }
                    </script>
                </div>
                <div class="w-full justify-between gap-x-10 md:px-5 md:flex hidden" id="mobile-menu">
                    <a href="{{ route('index') }}"
                        class="md:px-2 py-3 flex items-center gap-x-1 hover:text-secondary-800 duration-300">
                        {{ __('Home') }}
                    </a>
                    @if (config('settings::theme:sions-general-catnav') == true)
                                    <div class="flex flex-wrap gap-2">
                                        @foreach (App\Models\Category::whereNull('category_id')->orderBy('order')->get() as $category)
                                                            <div class="relative group">
                                                                <button type="button" aria-expanded="true"
                                                                    class="h-full md:px-2 py-3 flex items-center gap-x-1 hover:text-secondary-800 duration-300">
                                                                    <a href="{{ route('products', $category->slug) }}">{{ $category->name }}</a>
                                                                    @php
                                                                        $children = $category->children()->get();
                                                                    @endphp
                                                                    @if ($children->count() > 0)
                                                                        <i class="ri-arrow-down-s-line"></i>
                                                                    @endif
                                                                </button>

                                                                @if ($children->count() > 0)
                                                                    <div
                                                                        class="absolute left-0 hidden w-56 origin-top-right bg-secondary-200 border border-secondary-300 rounded-md z-10 group-hover:block">
                                                                        @foreach ($children as $childCategory)
                                                                            <a href="{{ route('products', $childCategory->slug) }}"
                                                                                class="flex px-4 py-2 rounded text-secondary-700 hover:bg-secondary-100 hover:text-secondary-900">
                                                                                {{ $childCategory->name }}
                                                                            </a>
                                                                        @endforeach
                                                                    </div>
                                                                @endif
                                                            </div>
                                        @endforeach
                                    </div>
                    @else
                        <button type="button" aria-expanded="true" data-dropdown-placement="bottom-start"
                            aria-haspopup="true" data-dropdown-toggle="orders"
                            class="relative md:px-2 py-3 flex items-center gap-x-1 hover:text-secondary-800 duration-300">
                            {{ __('Shop') }} <i class="ri-arrow-down-s-line"></i>

                            <div class="absolute left-0 hidden w-56 mt-2 origin-top-right bg-secondary-200 border border-secondary-300 rounded-md z-10"
                                role="menu" aria-orientation="vertical" aria-labelledby="product" tabindex="-1" id="orders">
                                @foreach (App\Models\Category::whereNull('category_id')->orderBy('order')->get() as $category)
                                    @if ($category->products()->where('hidden', false)->count() > 0 || $category->children->count() > 0)
                                        <a href="{{ route('products', $category->slug) }}"
                                            class="flex px-4 py-2 rounded text-secondary-700 hover:bg-secondary-100 hover:text-secondary-900"
                                            role="menuitem" tabindex="-1" id="menu-item-0">{{ $category->name }}</a>
                                    @endif
                                @endforeach
                            </div>
                        </button>
                    @endif
                    <a href="{{ route('announcements.index') }}"
                        class="md:px-2 py-3 flex items-center gap-x-1 hover:text-secondary-800 duration-300">
                        {{ __('Announcements') }}
                    </a>
                    <div class="ml-auto flex items-center gap-x-1 justify-center md:pb-0 pb-4">
                        <livewire:cart-count />

                        @auth
                            <button type="button" aria-expanded="true" aria-haspopup="true"
                                data-dropdown-placement="bottom-end" data-dropdown-toggle="account"
                                class="relative md:flex-none flex-1">
                                <div class="inline-flex items-center justify-center">
                                    <img class="w-8 h-8 rounded-md"
                                        src="https://www.gravatar.com/avatar/{{md5(Auth::user()->email)}}?s=200&d=mp"
                                        alt="Avatar" />
                                    <p class="p-2 font-bold">
                                        {{ Auth::user()->first_name }}
                                    </p>
                                </div>
                                <div class="absolute left-0 hidden w-60 mt-2 origin-top-right bg-secondary-200 border border-secondary-300 rounded-md text-secondary-700 font-normal text-start z-10"
                                    role="menu" aria-orientation="vertical" aria-labelledby="product" tabindex="-1"
                                    id="account">
                                    <div class="px-2 py-2">
                                        @if (Auth::user()->has('ADMINISTRATOR'))
                                            <a href="{{ route('admin.index') }}"
                                                class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded transition-all ease-in-out">
                                                <i class="ri-key-2-line"></i> {{ __('Admin area') }}
                                            </a>
                                            <a href="{{ route('clients.api.index') }}"
                                                class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded transition-all ease-in-out">
                                                <i class="ri-code-s-slash-line"></i> {{ __('API') }}
                                            </a>
                                        @endif

                                        <a href="{{ route('clients.home') }}"
                                            class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded transition-all ease-in-out">
                                            <i class="ri-account-circle-line"></i> {{ __('Customer Area') }}
                                        </a>

                                        @if (config('settings::credits'))
                                            <a href="{{ route('clients.credits') }}"
                                                class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded transition-all ease-in-out">
                                                <i class="ri-wallet-3-line"></i> {{ __('Your Balance:') }} <span
                                                    class="font-semibold">
                                                    <x-money :amount="Auth::user()->credits" />
                                                </span>
                                            </a>
                                        @endif
                                        {{-- <a href="#"
                                            class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded"><i
                                                class="ri-instance-line"></i> {{ __('Services') }}</a> --}}

                                        <hr class="mx-2 my-1 border-secondary-400" />

                                        <a type="button" href="{{ route('logout') }}"
                                            onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                                            class="px-2 py-2 hover:bg-secondary-300 flex items-center gap-x-2 rounded transition-all ease-in-out">
                                            <i class="ri-logout-box-line"></i> {{ __('Log Out') }}
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                                            @csrf
                                        </form>
                                    </div>
                                </div>
                            </button>
                        @else
                            <a href="{{ route('login') }}" class="button button-primary md:flex-none flex-1">
                                {{ __('Log In') }}
                            </a>
                        @endauth
                        <button class="m-1.5 button button-secondary-outline !font-normal" id="theme-toggle">
                            <i class="ri-sun-line hidden dark:block"></i>
                            <i class="ri-moon-line dark:hidden"></i>
                        </button>
                        <script>
                            // Change the icons inside the button based on previous settings
                            if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia(
                                '(prefers-color-scheme: dark)').matches));

                            var themeToggleBtn = document.getElementById('theme-toggle');
                            themeToggleBtn.addEventListener('click', function () {
                                // if set via local storage previously
                                if (localStorage.getItem('theme')) {
                                    if (localStorage.getItem('theme') === 'light') {
                                        document.documentElement.classList.add('dark');
                                        localStorage.setItem('theme', 'dark');
                                    } else {
                                        document.documentElement.classList.remove('dark');
                                        localStorage.setItem('theme', 'light');
                                    }
                                    // if NOT set via local storage previously
                                } else {
                                    if (document.documentElement.classList.contains('dark')) {
                                        document.documentElement.classList.remove('dark');
                                        localStorage.setItem('theme', 'light');
                                    } else {
                                        document.documentElement.classList.add('dark');
                                        localStorage.setItem('theme', 'dark');
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </nav>

        @if(Route::currentRouteName() == 'index')
            <div class="sions-navigation-headercontent">
                <div class="sions-navigation-headercontent-left">
                    <div>
                        <h1 class="s-textcolor s-fadein s-h1">{{ config('settings::theme:sions-header-text') }}</h1>
                        <p class="text-lg s-fadein">
                            {{ config('settings::theme:sions-header-subtext') }}
                        </p>
                    </div>
                </div>
                <div class="sions-navigation-headercontent-right">
                    @if($product = App\Models\Product::where('name', config('settings::theme:sions-header-product'))->first())
                                <div class="sions-navigation-product s-glas">
                                    <div class="sions-navigation-pdiv">
                                        <div class="sions-navigation-ptitle s-h2">
                                            <h2 class="">{{ $product->name }}</h2>
                                        </div>
                                    </div>
                                    <div>
                                        @php
                                            $price = App\Models\ProductPrice::where('product_id', $product->id)->first()
                                        @endphp
                                        <p class="sions-navigation-ptext">
                                            {{ config('settings::theme:sions-header-productprice') . " "}}
                                            <span>{{ $price->monthly . " " . config('settings::currency_sign') }}</span>

                                        </p>
                                    </div>

                                    <div>
                                        <button class="button button-primary"
                                            onclick="window.location.href='{{ route('checkout.config', $product->id) }}'">Konfigurieren</button>
                                    </div>
                                </div>
                    @endif
                </div>
            </div>
        @endif
    </div>