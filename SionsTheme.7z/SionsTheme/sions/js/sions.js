document.addEventListener("DOMContentLoaded", function () {
    const nav = document.querySelector('nav');
    const headerDiv = document.querySelector('.sions-nocontent');

    window.onscroll = function () {
        if (window.scrollY > 31) {
            nav.classList.add('sions-navigation-nav-fixed');
            if (headerDiv) {
                headerDiv.classList.add('sions-nocontent-div');
            }
        } else {
            nav.classList.remove('sions-navigation-nav-fixed');
            if (headerDiv) {
                headerDiv.classList.remove('sions-nocontent-div');
            }
        }
    };

    const swiper = new Swiper('.sions-welcome-announcements-swiper-container', {
        slidesPerView: 1, // Start with 1 slide for mobile
        spaceBetween: 20, // Space between slides
        loop: true, // Infinite loop for slider
        autoplay: {
            delay: 4000, // Auto-slide every 4 seconds
            disableOnInteraction: false, // Keep autoplaying even after interaction
        },
        pagination: {
            el: '.sions-welcome-announcements-swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.sions-welcome-announcements-swiper-button-next',
            prevEl: '.sions-welcome-announcements-swiper-button-prev',
        },
        breakpoints: {
            640: {
                slidesPerView: 1, // For mobile devices
            },
            768: {
                slidesPerView: 2, // For tablets
            },
            1024: {
                slidesPerView: 3, // For desktops and larger screens
            },
        },
    });
});