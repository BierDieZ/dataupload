<x-app-layout title="{{ __('Announcements') }}">
    @php
        $query = request('query');

        $announcementsQuery = \App\Models\Announcement::query();

        if ($query) {
            $query = strtolower($query);
            $announcementsQuery->where(function ($subQuery) use ($query) {
                $subQuery->whereRaw('LOWER(title) LIKE ?', ["%{$query}%"])
                    ->orWhereRaw('LOWER(announcement) LIKE ?', ["%{$query}%"]);
            });
        }

        $announcements = $announcementsQuery->orderBy('created_at', 'desc')->paginate(15);
    @endphp

    <div class="content">
        <h2 class="font-semibold text-4xl mb-8 text-primary-400">
            {{ __('Announcements') }}
        </h2>

        <div class="mb-4">
            <form method="GET">
                <input type="text" name="query" placeholder="{{ config('settings::theme:sions-announcements-search') }}"
                    class="border border-gray-300 rounded-md p-2 w-full" required />
                <button type="submit" class="bg-primary-400 text-white rounded-md px-4 py-2 mt-2">
                    {{ config('settings::theme:sions-announcements-search') }}
                </button>
                <a href="{{ route('announcements.index') }}"
                    class="bg-secondary-500 text-white rounded-md px-4 py-2 mb-4 inline-block">
                    {{ config('settings::theme:sions-announcements-back') }}
                </a>
                @if ($query)
                    <p class="mt-2 text-sm text-secondary-600">
                        {{ config('settings::theme:sions-announcements-searched') . " " . $query }}
                    </p>
                @endif
            </form>
        </div>

        @if ($announcements->count() > 0)
            <ul class="space-y-4">
                @foreach ($announcements as $announcement)
                        @php
                            $isNew = $announcement->created_at >= now()->subHours(48);
                        @endphp
                        <li>
                            <div class="content-box p-4 border rounded-md shadow-md relative">
                                @if ($isNew)
                                    <span class="bg-primary-400 text-white rounded-full px-2 py-1 text-xs absolute top-2 right-2">
                                        {{ config('settings::theme:sions-announcements-published') }}</span>
                                @endif
                                <h3 class="font-semibold text-lg">{{ $announcement->title }}</h3>
                                <p class="overflow-hidden text-ellipsis"
                                    style="-webkit-box-orient: vertical; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2;">
                                    {{$announcement->announcement}}
                                </p>
                                <div class="flex justify-between items-center mt-3">
                                    <span class="text-sm text-secondary-600">{{ __('Published') }}
                                        {{ $announcement->created_at->diffForHumans() }}</span>
                                    <a href="{{ route('announcements.view', $announcement->id) }}"
                                        class="button button-secondary">{{ __('Read More') }}</a>
                                </div>
                            </div>
                        </li>
                @endforeach
            </ul>

            <div class="mt-4 flex justify-center">
                {{ $announcements->links() }}
            </div>

        @else
            <p class="text-center py-3">{{ __('Announcement not found!') }}</p>
        @endif
    </div>
</x-app-layout>